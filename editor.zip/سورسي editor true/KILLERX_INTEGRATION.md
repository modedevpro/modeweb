# KillerX Integration

تم دمج مشروع `ApkSignatureKillerX` داخل EditorTrue كوحدة Gradle مستقلة باسم `:killerx`.

## ما تمت إضافته

- `killerx/`: مكتبة Kotlin وNative C الأصلية.
- `killerx/src/main/assets/killerx/origin.apk`: أصل APK المطلوب لمسار إعادة توجيه القراءة.
- `host/killerx/`: أدوات ADB الأصلية الخاصة بالمشروع.
- `docs/killerx/`: README وSTUDY وLICENSE للمشروع الأصلي.
- اعتماد `implementation(project(":killerx"))` في التطبيق.
- دعم ByteHook وملفات native لكل من `arm64-v8a` و`armeabi-v7a`.
- إصلاح توافق ARM32 بإضافة stub يعطّل seccomp redirect غير المدعوم على ARM32 بدل فشل الربط.
- إضافة `pickFirst` لمنع تكرار مكتبات ByteHook عند الدمج.

## التشغيل

الوحدة مدمجة ومبنية داخل التطبيق، لكنها **غير مفعّلة تلقائيًا** داخل EditorTrue حتى لا يتغير سلوك التعديل الحالي. نقطة الدخول الاختيارية هي:

```kotlin
com.killerx.SignatureKillerX.install(
    context = context,
    originalCertBase64 = originalCertBase64,
    trapSyscalls = false,
)
```

يجب استخدام هذه الوظيفة فقط في بيئة اختبار تملك التطبيقات والملفات الأصلية، مع توفير الشهادة الأصلية و`origin.apk` المطابقين.

## البناء

```bash
export ANDROID_HOME=/home/ubuntu/android-sdk
./gradlew :app:assembleDebug
```

تم اختبار البناء النهائي بنجاح بعد دمج الوحدة.
