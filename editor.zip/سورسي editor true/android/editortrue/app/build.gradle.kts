plugins {
    id("com.android.library")
    alias(libs.plugins.kotlinx.serialization)
}

android {
    namespace = "com.rktechno.apkpatcher"
    compileSdk = 37

    defaultConfig {
        minSdk = 24

    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        compilerOptions {
            jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
        }
    }

    buildFeatures {
        buildConfig = true
        viewBinding = false
    }

    packaging {
        jniLibs {
            pickFirsts += "**/libbytehook.so"
            pickFirsts += "**/libshadowhook.so"
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            pickFirsts += "org/bouncycastle/pqc/crypto/picnic/lowmcL3.bin.properties"
            pickFirsts += "org/bouncycastle/pqc/crypto/picnic/lowmcL1.bin.properties"
            pickFirsts += "org/bouncycastle/pqc/crypto/picnic/lowmcL5.bin.properties"
            pickFirsts += "META-INF/versions/9/OSGI-INF/MANIFEST.MF"
        }
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    // Optional KillerX research module; no automatic installation is performed.
    implementation(project(":editortrue-killerx"))
    // The app's native patch/signing flow imports apksig directly; keep one canonical copy.
    implementation(project(":editortrue-signaturekill"))

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.fragment:fragment-ktx:1.6.2")

    // الأداة الأصلية APKPatcher-1.0.0.jar (dexlib2 + ARSCLib + apksig + الباتشات المضمّنة + assets/hooks)
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))

    // Shared storage paths and complete Universal Installer features.
    implementation(project(":editortrue-core"))
    implementation(project(":editortrue-installer"))
    implementation(libs.shizuku.api)

    // APK analysis: read manifest / package name without JVM tools
    implementation("net.dongliu:apk-parser:2.6.10")

    // APK signing (V1/V2/V3) مضمّنة داخل apkpatcher-tool.jar (نفس apksig)
    // ملاحظة: لا تُفعّل com.android.tools.build:apksig هنا لتفادي تعارض classes مزدوجة

    // ZIP: zip4j supports split/xapk extraction utilities
    implementation("net.lingala.zip4j:zip4j:2.11.5")

    // Regex engine identical behavior on Android
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    testImplementation(libs.junit)

    // SRPatch-X native APK builder and JSON configuration support.
    implementation("com.android.tools.build:apkzlib:9.1.0") {
        exclude(group = "com.android.tools.build", module = "apksig")
    }
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")

    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")


}
