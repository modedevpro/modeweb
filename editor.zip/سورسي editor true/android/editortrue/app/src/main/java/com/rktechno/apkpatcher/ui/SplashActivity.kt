package com.rktechno.apkpatcher.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.rktechno.apkpatcher.R

/** Startup and storage setup only. Shizuku is optional and is managed from the drawer. */
class SplashActivity : AppCompatActivity() {
    private var permissionDialog: AlertDialog? = null
    private var didNavigate = false
    private var welcomeDisplayed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (!didNavigate) continueIntoApp()
    }

    @Deprecated("Use Activity Result APIs for new permissions")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_REQUEST) {
            if (hasStoragePermission()) continueIntoApp() else showStoragePermissionDialog()
        }
    }

    override fun onDestroy() {
        permissionDialog = null
        super.onDestroy()
    }

    private fun hasStoragePermission(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        androidx.core.content.ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun showStoragePermissionDialog() {
        if (permissionDialog?.isShowing == true) return
        permissionDialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.storage_title)
            .setMessage(R.string.storage_message)
            .setCancelable(false)
            .setPositiveButton(R.string.enable_permission) { _, _ ->
                permissionDialog = null
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val appSettings = Intent(
                        android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName"),
                    )
                    try {
                        startActivity(appSettings)
                    } catch (_: Throwable) {
                        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    }
                } else {
                    requestPermissions(
                        arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),
                        STORAGE_PERMISSION_REQUEST,
                    )
                }
            }
            .setNegativeButton(R.string.close_app) { _, _ -> finish() }
            .create()
            .also { it.show() }
    }

    private fun continueIntoApp() {
        if (didNavigate || isFinishing || isDestroyed) return
        if (!hasStoragePermission()) {
            showStoragePermissionDialog()
            return
        }
        @Suppress("DEPRECATION")
        val pendingExternalIntent = intent.getParcelableExtra<Intent>(EXTRA_PENDING_EXTERNAL_INTENT)
        if (pendingExternalIntent != null) {
            didNavigate = true
            startActivity(pendingExternalIntent)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            return
        }
        val preferences = getSharedPreferences("editor_true_onboarding", MODE_PRIVATE)
        if (preferences.getBoolean("welcome_seen", false)) {
            openMain()
        } else {
            showWelcome(preferences)
        }
    }

    private fun showWelcome(preferences: android.content.SharedPreferences) {
        if (welcomeDisplayed || didNavigate) return
        welcomeDisplayed = true
        setContentView(R.layout.activity_splash)
        val logo = findViewById<View>(R.id.welcomeLogo)
        val eyebrow = findViewById<View>(R.id.welcomeEyebrow)
        val title = findViewById<View>(R.id.welcomeTitle)
        val subtitle = findViewById<View>(R.id.welcomeSubtitle)
        val features = findViewById<View>(R.id.welcomeFeatures)
        val action = findViewById<MaterialButton>(R.id.btnWelcomeStart)
        listOf(logo, eyebrow, title, subtitle, features, action).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 28f
            view.postDelayed({
                view.animate().alpha(1f).translationY(0f).setDuration(520L).start()
            }, 100L + index * 90L)
        }
        action.setOnClickListener {
            preferences.edit().putBoolean("welcome_seen", true).apply()
            action.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90L).withEndAction {
                openMain()
            }.start()
        }
    }

    private fun openMain() {
        if (didNavigate || isFinishing) return
        didNavigate = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    companion object {
        const val EXTRA_PENDING_EXTERNAL_INTENT = "editortrue.pending_external_intent"
        private const val STORAGE_PERMISSION_REQUEST = 7302
    }
}
