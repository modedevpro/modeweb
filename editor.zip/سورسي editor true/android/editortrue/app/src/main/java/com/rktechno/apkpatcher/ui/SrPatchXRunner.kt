package com.rktechno.apkpatcher.ui

import app.pwhs.core.util.EditorTrueStorage

import android.content.Context
import com.htetz.core.ApkPatchOptions
import com.htetz.core.ApkPatcher
import com.htetz.core.KeystoreConfig
import com.htetz.core.KeyStoreSource
import com.htetz.core.PMSProxyMethod
import com.htetz.core.SignatureStrength
import java.io.File
import java.util.zip.ZipFile

/** Runs the actual Editor X core, not the legacy Editor True patcher. */
object SrPatchXRunner {
    data class Result(val output: File?, val error: String?)

    fun run(
        context: Context,
        input: File,
        level: Int,
        pathRedirection: Boolean,
        onStep: (String, Int) -> Unit
    ): Result {
        return try {
            require(input.exists() && input.length() > 0) { "ملف الإدخال غير موجود أو فارغ" }
            onStep("Validate input: ${input.name}", 4)
            val nativePatchEnabled = android.os.Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }
            if (!nativePatchEnabled) {
                onStep("WARNING: هذا الهاتف 32-bit؛ the native Editor X library supports ARM64 only", 4)
            }
            val sourceApk = prepareSourceApk(input, context.cacheDir, onStep)
            val packageInfo = context.packageManager.getPackageArchiveInfo(sourceApk.absolutePath, 0)
            val realAppName = packageInfo?.applicationInfo?.loadLabel(context.packageManager)?.toString()
                ?.trim()?.takeIf { it.isNotEmpty() }
                ?: packageInfo?.packageName
                ?: sourceApk.nameWithoutExtension
            val safeAppName = realAppName.replace(Regex("[^\\p{L}\\p{N}._-]"), "_").take(80)
            onStep("Application: $realAppName", 12)
            val keyFile = File(context.cacheDir, "srpatch_keystore.jks")
            if (!keyFile.exists()) context.assets.open("srpatch/keystore.jks").use { source -> keyFile.outputStream().use(source::copyTo) }
            val outDir = EditorTrueStorage.modifiedApks()
            val base = "${safeAppName}_EditorTrue"
            var output = File(outDir, "$base.apk")
            var index = 1
            while (output.exists()) output = File(outDir, "${base}(${index++}).apk")
            val options = ApkPatchOptions(
                pathRedirectionEnabled = pathRedirection,
                pmsProxyMethod = PMSProxyMethod.BINDER_PROXY,
                signatureStrength = SignatureStrength.fromLevel(level),
                keystoreConfig = KeystoreConfig(
                    storeSource = KeyStoreSource.FromFile(keyFile.absolutePath),
                    keystorePassword = "12345678",
                    keyAlias = "patcher",
                    keyPassword = "12345678"
                )
            )
            var lastProgress = 12
            val engineProgress: (String) -> Unit = { message ->
                val reported = Regex("@([0-9]{1,3})%").find(message)?.groupValues?.get(1)?.toIntOrNull()
                val progress = when {
                    reported != null -> reported
                    message.startsWith("Validating") -> 8
                    message.startsWith("Extracting") -> 16
                    message.startsWith("Signature:") -> 22
                    message.startsWith("Setting up") -> 28
                    message.startsWith("Registering") -> 36
                    message.startsWith("Processing") -> 45
                    message.startsWith("Copy plan") -> 45
                    message.startsWith("Copy complete") -> 75
                    message.startsWith("packageName:") || message.startsWith("applicationName") -> 54
                    message.startsWith("Copying") -> 45
                    message.startsWith("Adding") -> 78
                    message.startsWith("Added filter") -> 82
                    message.startsWith("Added original") -> 84
                    message.startsWith("Added native") -> 88
                    message.startsWith("Added dex") -> 92
                    message.startsWith("Finalizing") -> 94
                    else -> lastProgress
                }.coerceAtLeast(lastProgress).coerceAtMost(99)
                lastProgress = progress
                onStep(message, progress)
            }
            ApkPatcher(sourceApk, output, options, engineProgress, { name -> context.assets.open("srpatch/$name") }, nativePatchEnabled).patch()
            require(output.exists() && output.length() > 0) { "Editor X did not create an output APK" }
            onStep("SUCCESS: Editor X output ${output.name}", 100)
            Result(output, null)
        } catch (t: Throwable) {
            onStep("ERROR: ${t.message ?: t.javaClass.simpleName}", 0)
            Result(null, t.message ?: "Editor X processing failed")
        }
    }

    private fun prepareSourceApk(input: File, cacheDir: File, onStep: (String, Int) -> Unit): File {
        val ext = input.extension.lowercase()
        if (ext == "apk") return input
        onStep("Extracting base APK from .$ext package…", 8)
        val extracted = File(cacheDir, "editorx_base_${System.currentTimeMillis()}.apk")
        ZipFile(input).use { zip ->
            val entry = zip.entries().asSequence().firstOrNull { candidate ->
                val name = candidate.name.lowercase()
                !candidate.isDirectory && (name == "base.apk" || name.endsWith("/base.apk") || name.endsWith("base-master.apk"))
            } ?: zip.entries().asSequence().firstOrNull { candidate ->
                !candidate.isDirectory && candidate.name.lowercase().endsWith(".apk")
            } ?: throw IllegalArgumentException("No base APK found inside the package")
            zip.getInputStream(entry).use { source -> extracted.outputStream().use(source::copyTo) }
        }
        require(extracted.length() > 0) { "Base APK is empty" }
        onStep("Base APK extracted: ${extracted.name}", 11)
        return extracted
    }
}
