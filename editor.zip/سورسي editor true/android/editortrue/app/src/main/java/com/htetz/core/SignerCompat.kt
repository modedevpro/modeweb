package com.htetz.core

import com.rktechno.apkpatcher.internal.apksig.ApkVerifier
import com.rktechno.apkpatcher.internal.apksig.util.DataSource
import java.security.cert.X509Certificate

internal object SignerCompat {
    fun findAnySign(source: DataSource): String? {
        return try {
            val result = ApkVerifier.Builder(source)
                .build()
                .verify()
            result.v1SchemeSigners.firstOrNull()?.let {
                return it.certificate.toHexString()
            }

            result.v2SchemeSigners.firstOrNull()?.let {
                return it.certificate.toHexString()
            }

            result.v3SchemeSigners.firstOrNull()?.let {
                return it.certificate.toHexString()
            }
            // The bundled Android apksig implementation exposes v1/v2/v3;
            // v3 also covers APKs using the modern signer lineage metadata.
            null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private fun X509Certificate.toHexString(): String = this.encoded.toHexString()
}
