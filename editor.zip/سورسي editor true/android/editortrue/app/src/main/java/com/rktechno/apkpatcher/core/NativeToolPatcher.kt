package com.rktechno.apkpatcher.core

import android.util.Log
import com.apkpatcher.cli.Args
import com.apkpatcher.merge.Merger
import com.apkpatcher.dex.Patcher
import com.apkpatcher.dex.hook.DexHook
import com.apkpatcher.xml.XMLPatcher
import com.apkpatcher.helper.Detector
import com.apkpatcher.util.FileUtils
import com.rktechno.apkpatcher.internal.apksig.ApkSigner
import com.rktechno.apkpatcher.internal.apksig.util.DataSinks
import com.rktechno.apkpatcher.internal.apksig.util.DataSources
import java.io.FileInputStream
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Collections
import com.reandroid.apk.ApkModule
import com.reandroid.archive.writer.ZipAligner
import java.io.File
import java.io.BufferedInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import com.rktechno.apkpatcher.internal.apksig.ApkVerifier

/**
 * المشغل الأصلي لأداة APKPatcher-1.0.0.jar المضمّنة داخل التطبيق.
 */
object NativeToolPatcher {

    private const val TAG = "NativeToolPatcher"
    private const val NATIVE_LIBRARY_ALIGNMENT = 16 * 1024

    data class NativePatchResult(
        val success: Boolean,
        val outputFile: File?,
        val appliedFlags: List<String>,
        val elapsedMs: Long,
        val error: String?
    )

    fun runPatch(
        inputFile: File,
        activeFlags: Set<String>,
        caCertificate: File?,
        customId: String?,
        onLog: (String) -> Unit
    ): NativePatchResult {
        if (SplitBundlePatcher.isBundleFile(inputFile)) {
            return SplitBundlePatcher.run(inputFile, activeFlags, caCertificate, customId, onLog)
        }
        return runPatchComponent(inputFile, activeFlags, caCertificate, customId, true, false, onLog)
    }

    internal fun runPatchComponent(
        inputFile: File,
        activeFlags: Set<String>,
        caCertificate: File?,
        customId: String?,
        applyManifestFix: Boolean,
        allowNoDex: Boolean,
        onLog: (String) -> Unit,
    ): NativePatchResult {
        val startTime = System.currentTimeMillis()
        var outputOnFailure: File? = null
        var mergedTemporaryFile: File? = null
        var loadedModule: ApkModule? = null
        return try {
            // 1. تحليل الفلاجات
            Args.isSSL = false; Args.isALG = false; Args.isTG = false; Args.isPaid = false
            Args.isPine = false; Args.isPine2 = false; Args.isMerge = false; Args.isUnSign = false
            Args.isAds = false; Args.isCERT = false; Args.isID = false; Args.isFix = false
            Args.isLoad = false; Args.isPKG = false; Args.isSS = false; Args.isUSB = false; Args.isVPN = false
            
            try {
                val field = Args::class.java.getDeclaredField("isSigKill")
                field.isAccessible = true
                field.set(null, false)
            } catch (_: Throwable) {}
            
            val cliArgs = buildArgs(activeFlags, inputFile, caCertificate, customId)
            Args.parse(cliArgs.toTypedArray())
            
            Args.isSSL = activeFlags.contains("-ssl")
            Args.isALG = activeFlags.contains("-a")
            Args.isTG = activeFlags.contains("-tg")
            Args.isPaid = activeFlags.contains("-paid")
            Args.isPine = activeFlags.contains("-pine")
            Args.isPine2 = activeFlags.contains("-pine2")
            Args.isUnSign = activeFlags.contains("-u")

            val flagsLog = cliArgs.filter { it.startsWith("-") && it != "-i" && it != "-m" && it != "-c" && it != "-id" }
                .joinToString(", ")
            onLog("[JAR] FLAGS: ${flagsLog.ifEmpty { "none" }}")

            var apkFile = inputFile
            var elapsed = System.currentTimeMillis() - startTime

            // 2. دمج splits إن لزم
            if (Args.isMerge) {
                onLog("[JAR] Merging split package")
                try {
                    compactHeapIfNeeded(onLog)
                    val merger = Merger()
                    merger.mergeApkFile(inputFile)
                    apkFile = merger.generateOutputFromInput(inputFile)
                    if (apkFile.absolutePath != inputFile.absolutePath) mergedTemporaryFile = apkFile
                    onLog("[JAR] Merge complete: ${apkFile.name}")
                } catch (mergeErr: Throwable) {
                    throw Exception("فشل دمج ملفات splits: ${mergeErr.message}", mergeErr)
                }
            }

            // 3. تحميل APK: لا نوقف الخيوط بـ GC إلا عند انخفاض الذاكرة فعليًا.
            compactHeapIfNeeded(onLog)
            onLog("[JAR] Loading APK for analysis")
            val module = ApkModule.loadApkFile(apkFile)
            loadedModule = module
            val pkgName = try { module.packageName ?: "unknown.pkg" } catch (_: Throwable) { "unknown.pkg" }
            onLog("[JAR] Package: $pkgName")
            onLog("[JAR] Scanning DEX and resources")

            // 4. إضافة NSC لملف base فقط؛ قد يكون كود Flutter داخل feature split.
            if ((Args.isSSL || activeFlags.contains("-ssl")) && applyManifestFix) {
                onLog("[JAR] Applying SSL pinning bypass")
                try {
                    XMLPatcher.addNSC(module)
                    onLog("[JAR] Network security config injected")
                } catch (t: Throwable) { onLog("[JAR] SSL bypass warning: ${t.message}") }
            }
            if (activeFlags.contains("-f")) {
                onLog("[JAR] Applying Flutter native SSL patch")
                val flutterSources = module.listNativeLibraryFiles()
                    .filter { it.alias.startsWith("lib/") && it.alias.endsWith("/libflutter.so") }
                if (flutterSources.isEmpty()) {
                    onLog("[JAR] Flutter SSL patch not applied: libflutter.so was not found")
                } else {
                    val originalSources = flutterSources.associate { it.alias to it }
                    try {
                        Detector.isFlutter(module)
                        val patchedAliases = originalSources.keys.filter { alias ->
                            module.getInputSource(alias) !== originalSources[alias]
                        }
                        if (patchedAliases.isEmpty()) {
                            onLog("[JAR] Flutter SSL patch not applied: no compatible libflutter.so pattern matched")
                        } else {
                            onLog("[JAR] Flutter SSL patch applied to: ${patchedAliases.joinToString()}")
                        }
                    } catch (t: Throwable) {
                        onLog("[JAR] Flutter SSL patch warning: ${t.message}")
                    }
                }
            }

            if (activeFlags.contains("-shield")) {
                onLog("[JAR] Applying protection compatibility patch")
            }

            // 5. APKPatcher.jar's full patch stage is required for every selected
            // flag: several flags have both manifest and DEX work. Do not skip it.
            val dexRequired = activeFlags.any { it in DEX_FLAGS }
            val hasDex = hasDexEntries(apkFile)
            // Never skip a requested DEX patch: -fix must modify DEX as requested.
            // The preflight only skips DEX when no -fix target is present.
            val selectiveDexNeeded = dexRequired && hasDex &&
                    (!activeFlags.contains("-fix") || hasFixTargets(apkFile))
            if (dexRequired && !hasDex) {
                onLog("[JAR] This split contains no DEX; DEX-only patches are skipped for this component")
            }
            if (dexRequired && !selectiveDexNeeded) {
                if (hasDex) onLog("[JAR] TURBO SELECTIVE: no -fix targets found; skipping full DEX rebuild")
            }
            if (selectiveDexNeeded) {
                try {
                    tuneDexWorkers(apkFile, onLog)
                    compactHeapIfNeeded(onLog)
                    Patcher.setProgressCallback { message -> onLog(message) }
                    Patcher.patch(module)
                    Patcher.setProgressCallback(null)
                } catch (oom: OutOfMemoryError) {
                    Patcher.setProgressCallback(null)
                    onLog("[JAR] DEX patch stopped: device memory limit reached; partial output will be discarded")
                    throw IllegalStateException(
                        "نفدت الذاكرة المؤقتة أثناء تعديل DEX. أُلغيت النتيجة غير المكتملة؛ أغلق التطبيقات الأخرى وأعد المحاولة.",
                        oom
                    )
                } catch (t: Throwable) {
                    Patcher.setProgressCallback(null)
                    onLog("[JAR] DEX patch error: ${t.message ?: t.javaClass.simpleName}")
                    throw IllegalStateException("فشل تعديل DEX؛ لم يتم إنشاء APK ناقص", t)
                }
            } else if (activeFlags.isNotEmpty()) {
                onLog("[JAR] FAST PATH: no DEX patch requested; skipping DEX analysis")
            }

            // 6. إصلاح التطبيق
            if (activeFlags.contains("-fix") && applyManifestFix) {
                onLog("[JAR] Applying install compatibility fix")
                try {
                    XMLPatcher.patchManifest(module)
                    onLog("[JAR] Install compatibility fix complete")
                } catch (t: Throwable) { onLog("[JAR] Install fix warning: ${t.message}") }
            } else if (activeFlags.contains("-fix")) {
                onLog("[JAR] Manifest compatibility edits are limited to the base APK")
            }

            // 7. حقن dex hooks
            if (Args.isALG || Args.isPine || Args.isPine2 || Args.isTG) {
                onLog("[JAR] Injecting DEX files")
                try {
                    DexHook.hook(module)
                    onLog("[JAR] Injection complete")
                } catch (t: Throwable) { onLog("[JAR] Injection warning: ${t.message}") }
            }

            // 8. تنظيف Manifest لحل مشكلة "غير متوافق مع الجهاز" و "تعارض الأذونات"
            try {
                onLog("[JAR] Scanning AndroidManifest.xml")
                val manifestBlock = module.androidManifest
                val manifestElement = manifestBlock.manifestElement
                var splitRemoved = 0
                
                                // لا نحذف permission declarations؛ فقد تكون مطلوبة من التطبيق أو من مكتباته.
                onLog("[JAR] Checking permissions while preserving original declarations")



                // نحافظ على سمات split وABI الأصلية؛ حذفها يكسر بعض التطبيقات متعددة الحزم.
                onLog("[JAR] Preserving split and ABI constraints")

                // لا نحذف split/ABI/native-library constraints؛ فهي جزء من بنية الحزمة.
                onLog("[JAR] Split, ABI and native library constraints preserved")
                onLog("[JAR] Manifest scan complete")
            } catch (t: Throwable) { onLog("[JAR] Manifest warning: ${t.message}") }

            // 9. كتابة APK بدون GC قسري؛ الكتابة نفسها تعتمد على I/O streaming.
            onLog("[JAR] Building output APK")
            val outName = apkFile.nameWithoutExtension + "_Patched.apk"
            val outputFile = File(apkFile.parentFile ?: File("."), outName)
            outputOnFailure = outputFile
            writeCleanAlignedApk(module, outputFile, onLog)
            onLog("[JAR] Output written: ${outputFile.name}")

            // فحص الحاوية قبل التوقيع حتى لا نوقع APK ناقصاً أو غير صالح.
            validateApkContainer(outputFile, requireDex = !allowNoDex)

            // 10. التوقيع مع إدارة الذاكرة لمنع OOM
            if (!Args.isUnSign) {
                onLog("[JAR] Signing APK (V1+V2+V3)")
                try {
                    compactHeapIfNeeded(onLog)
                    signApkSafely(outputFile, outputFile, onLog, inputAlreadyClean = true)
                    onLog("[JAR] Signature verified")
                } catch (t: Throwable) {
                    outputFile.delete()
                    onLog("[JAR] Signing failed: ${t.message ?: t.javaClass.simpleName}")
                    throw IllegalStateException("لم يتم إنشاء APK صالح للتثبيت بعد فشل التوقيع", t)
                }
            } else {
                onLog("[JAR] Native libraries stored and 16KB-aligned in APK writer (unsigned output)")
            }

            // Re-validate after signing, and refuse to publish output that lost any source ABI.
            validateApkContainer(outputFile, requireDex = !allowNoDex)
            validateNativeAbisPreserved(apkFile, outputFile, onLog)
            validateNativeLibraryPackaging(outputFile, onLog)
            elapsed = System.currentTimeMillis() - startTime
            onLog("[JAR] PROCESS COMPLETE (${elapsed}ms)")
            module.close()
            loadedModule = null
            mergedTemporaryFile?.delete()
            outputOnFailure = null
            NativePatchResult(true, outputFile, flagsLog.split(", ").filter { it.isNotEmpty() }, elapsed, null)
        } catch (e: Throwable) {
            outputOnFailure?.delete()
            mergedTemporaryFile?.delete()
            try { loadedModule?.close() } catch (closeError: Throwable) {
                Log.w(TAG, "Could not close failed APK module cleanly", closeError)
            }
            Log.e(TAG, "Native patch failed", e)
            NativePatchResult(false, null, emptyList(), System.currentTimeMillis() - startTime, e.message)
        }
    }

    private fun compactHeapIfNeeded(onLog: (String) -> Unit) {
        val runtime = Runtime.getRuntime()
        val free = runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory())
        val threshold = maxOf(64L * 1024L * 1024L, runtime.maxMemory() / 8L)
        if (free < threshold) {
            onLog("[JAR] Low memory detected; compacting heap before next stage")
            System.gc()
            Runtime.getRuntime().let { System.runFinalization() }
        }
    }

    /** Configure one DEX worker to prevent parallel DexPool allocations exhausting Android's heap. */
    private fun tuneDexWorkers(apk: File, onLog: (String) -> Unit) {
        val dexBytes = try {
            ZipFile(apk).use { zip ->
                zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.matches(Regex("classes(\\d+)?\\.dex")) }
                    .sumOf { it.size.coerceAtLeast(0L) }
            }
        } catch (_: Throwable) { 0L }
        val dexMb = dexBytes / (1024L * 1024L)
        val workers = 1
        try {
            val field = Patcher::class.java.getDeclaredField("jobs")
            field.isAccessible = true
            field.setInt(null, workers)
            val runtime = Runtime.getRuntime()
            val maxHeapMb = runtime.maxMemory() / (1024L * 1024L)
            val freeHeapMb = (runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory())) / (1024L * 1024L)
            onLog("[JAR] DEX memory-safe mode: ${dexMb}MB across DEX, workers=$workers, heap=${freeHeapMb}/${maxHeapMb}MB")
        } catch (_: Throwable) {
            onLog("[JAR] DEX memory-safe mode requested for ${dexMb}MB; using JAR worker limit")
        }
    }

    private val DEX_FLAGS = setOf(
        // -fix contains the Policy/Location/PackageManager instruction patch.
        "-a", "-fix", "-id", "-l", "-paid", "-pine", "-pine2", "-pkg",
        "-rmads", "-rmss", "-rmusb", "-tg", "-v"
    )

    /**
     * Cheap streaming preflight for -fix. It avoids DexBacked/DexPool allocation
     * when a large APK cannot contain any of the three supported fix targets.
     */
    private fun hasFixTargets(apk: File): Boolean {
        val targets = arrayOf(
            "allowAccess", "isFromMockProvider", "isMock", "getInstallerPackageName",
            "com/google/android/vending/licensing/Policy", "android/location/Location",
            "android/content/pm/PackageManager"
        ).map { it.toByteArray(Charsets.UTF_8) }
        return try {
            ZipFile(apk).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory || !entry.name.matches(Regex("classes(\\d+)?\\.dex"))) continue
                    BufferedInputStream(zip.getInputStream(entry), 4 * 1024 * 1024).use { input ->
                        // 4MiB is a good mobile I/O balance; do not allocate a
                        // second full-size window for every chunk.
                        val chunk = ByteArray(4 * 1024 * 1024)
                        val carry = ByteArray(128)
                        var carrySize = 0
                        while (true) {
                            val count = input.read(chunk)
                            if (count <= 0) break
                            if (targets.any { target -> containsBytes(chunk, count, target) }) return true
                            val boundary = ByteArray(carrySize + minOf(count, carry.size))
                            System.arraycopy(carry, 0, boundary, 0, carrySize)
                            System.arraycopy(chunk, 0, boundary, carrySize, minOf(count, carry.size))
                            if (targets.any { target -> containsBytes(boundary, boundary.size, target) }) return true
                            val keep = minOf(carry.size, count)
                            System.arraycopy(chunk, count - keep, carry, 0, keep)
                            carrySize = keep
                        }
                    }
                }
            }
            false
        } catch (t: Throwable) {
            onSafeLog("[JAR] selective preflight skipped: ${t.message}")
            true
        }
    }

    private fun hasDexEntries(apk: File): Boolean = try {
        ZipFile(apk).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (!entry.isDirectory && entry.name.matches(Regex("classes(\\d+)?\\.dex"))) return true
            }
            false
        }
    } catch (_: Throwable) { false }

    private fun onSafeLog(message: String) {
        Log.w(TAG, message)
    }

    private fun containsBytes(haystack: ByteArray, length: Int, needle: ByteArray): Boolean {
        if (needle.isEmpty() || needle.size > length) return false
        outer@ for (start in 0..length - needle.size) {
            for (offset in needle.indices) {
                if (haystack[start + offset] != needle[offset]) continue@outer
            }
            return true
        }
        return false
    }

    private fun buildArgs(activeFlags: Set<String>, inputFile: File, caCertificate: File?, customId: String?): List<String> {
        val isSplit = inputFile.name.lowercase().let { it.endsWith(".apks") || it.endsWith(".apkm") || it.endsWith(".xapk") }
        val args = mutableListOf<String>()
        if (isSplit) { args.add("-m"); args.add(inputFile.absolutePath) }
        else { args.add("-i"); args.add(inputFile.absolutePath) }
        // مرّر الفلاجات الأصلية كما هي، خصوصاً -a و -f.
        activeFlags.forEach { args.add(it) }
        caCertificate?.let { if (it.exists()) { args.add("-c"); args.add(it.absolutePath) } }
        customId?.let { args.add("-id"); args.add(it) }
        return args
    }



    fun signFileOnly(file: File, onLog: (String) -> Unit): File? {
        val startTime = System.currentTimeMillis()
        onLog("[JAR] Signing started: ${file.name}")
        val outputFile = uniqueSignedOutputFile(file)
        return try {
            signApkSafely(file, outputFile, onLog)
            validateNativeLibraryPackaging(outputFile, onLog)
            val elapsed = System.currentTimeMillis() - startTime
            onLog("[JAR] Signing complete and verified (${elapsed}ms)")
            outputFile
        } catch (t: Throwable) {
            outputFile.delete()
            onLog("[JAR] Signing failed: ${t.message ?: t.javaClass.simpleName}")
            null
        }
    }

    private fun uniqueSignedOutputFile(input: File): File {
        val parent = input.absoluteFile.parentFile ?: File(".").absoluteFile
        val base = input.nameWithoutExtension + "_Signed"
        var candidate = File(parent, "$base.apk")
        var index = 1
        while (candidate.exists()) {
            candidate = File(parent, "${base}($index).apk")
            index++
        }
        return candidate
    }

    /**
     * Removes old META-INF signatures, signs a fresh copy, and verifies it.
     * The input and output are intentionally kept separate so a failed sign
     * operation never destroys the user's APK.
     */
    private fun validateApkContainer(file: File, requireDex: Boolean = true) {
        require(file.exists() && file.length() > 0) { "ملف APK الناتج غير موجود أو فارغ" }
        ZipFile(file).use { zip ->
            val names = HashSet<String>()
            var hasManifest = false
            var dexCount = 0
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                require(names.add(entry.name)) { "ملف APK يحتوي على مدخل ZIP مكرر: ${entry.name}" }
                require(!entry.name.startsWith("/") && !entry.name.contains("../")) { "مسار ZIP غير آمن: ${entry.name}" }
                if (entry.name == "AndroidManifest.xml") hasManifest = true
                if (entry.name.matches(Regex("classes(\\d+)?\\.dex"))) dexCount++
            }
            require(hasManifest) { "AndroidManifest.xml غير موجود داخل APK" }
            if (requireDex) require(dexCount > 0) { "لا يوجد classes.dex داخل APK" }
        }
    }

    private fun validateNativeAbisPreserved(input: File, output: File, onLog: (String) -> Unit) {
        if (!input.extension.equals("apk", ignoreCase = true)) return
        fun abis(file: File): Set<String> = ZipFile(file).use { zip ->
            val result = mutableSetOf<String>()
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.isDirectory || !entry.name.endsWith(".so", ignoreCase = true)) continue
                val parts = entry.name.split('/')
                if (parts.size >= 3 && parts[0] == "lib") result += parts[1]
            }
            result
        }
        val sourceAbis = abis(input)
        val outputAbis = abis(output)
        val missing = sourceAbis - outputAbis
        if (missing.isNotEmpty()) {
            throw IllegalStateException(
                "رُفض APK المعدل لأنه فقد مكتبات ABI الموجودة في الأصل: ${missing.sorted().joinToString()}. لم يتم نشر الملف الناقص."
            )
        }
        if (sourceAbis.isNotEmpty()) {
            onLog("[JAR] Native ABI check passed: ${sourceAbis.sorted().joinToString()}")
        }
    }

    internal fun validateNativeLibraryPackaging(file: File, onLog: (String) -> Unit = {}) {
        val nativeNames = ZipFile(file).use { zip ->
            val entries = zip.entries()
            val names = linkedSetOf<String>()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (isNativeLibraryEntry(entry.name)) {
                    require(entry.method == ZipEntry.STORED) {
                        "مكتبة native مضغوطة داخل APK (${entry.name})؛ رُفض الملف لمنع INSTALL_FAILED_INVALID_APK"
                    }
                    names += entry.name
                }
            }
            names
        }
        if (nativeNames.isEmpty()) return

        val dataOffsets = findNativeLibraryDataOffsets(file, nativeNames)
        if (dataOffsets == null) {
            onLog("[JAR] ZIP64 archive: stored native libraries retained; local-offset validation skipped")
            return
        }
        nativeNames.forEach { name ->
            val offset = dataOffsets[name]
                ?: throw IllegalStateException("تعذر التحقق من موضع مكتبة native: $name")
            require(offset % NATIVE_LIBRARY_ALIGNMENT == 0L) {
                "مكتبة native غير محاذاة إلى 16KB داخل APK ($name، offset=$offset)؛ رُفض الملف لمنع INSTALL_FAILED_INVALID_APK"
            }
        }
        onLog("[JAR] Native libraries are uncompressed and 16KB-aligned: ${nativeNames.size} file(s)")
    }

    private fun isNativeLibraryEntry(name: String): Boolean =
        name.startsWith("lib/") && name.count { it == '/' } >= 2 && name.endsWith(".so", ignoreCase = true)

    /** Returns null only for ZIP64 central directories, which Android APKs rarely use. */
    private fun findNativeLibraryDataOffsets(file: File, names: Set<String>): Map<String, Long>? {
        java.io.RandomAccessFile(file, "r").use { raf ->
            val fileLength = raf.length()
            val tailLength = minOf(fileLength, 22L + 65535L).toInt()
            if (tailLength < 22) throw IllegalStateException("APK ZIP directory is truncated")
            val tail = ByteArray(tailLength)
            raf.seek(fileLength - tailLength)
            raf.readFully(tail)

            var eocdIndex = -1
            for (index in tail.size - 22 downTo 0) {
                if (readU32(tail, index) == 0x06054b50L &&
                    index + 22 + readU16(tail, index + 20) == tail.size
                ) {
                    eocdIndex = index
                    break
                }
            }
            if (eocdIndex < 0) throw IllegalStateException("APK ZIP end-of-directory record is missing")

            val entryCount = readU16(tail, eocdIndex + 10)
            val centralDirectoryOffset = readU32(tail, eocdIndex + 16)
            if (entryCount == 0xFFFF || centralDirectoryOffset == 0xFFFFFFFFL) return null

            val offsets = HashMap<String, Long>()
            var cursor = centralDirectoryOffset
            repeat(entryCount) {
                raf.seek(cursor)
                val header = ByteArray(46)
                raf.readFully(header)
                require(readU32(header, 0) == 0x02014b50L) { "APK ZIP central directory is malformed" }

                val nameLength = readU16(header, 28)
                val extraLength = readU16(header, 30)
                val commentLength = readU16(header, 32)
                val localHeaderOffset = readU32(header, 42)
                if (localHeaderOffset == 0xFFFFFFFFL) return null
                val nameBytes = ByteArray(nameLength)
                raf.readFully(nameBytes)
                val name = String(nameBytes, Charsets.UTF_8)

                if (name in names) {
                    raf.seek(localHeaderOffset)
                    val localHeader = ByteArray(30)
                    raf.readFully(localHeader)
                    require(readU32(localHeader, 0) == 0x04034b50L) { "APK ZIP local header is malformed for $name" }
                    val localNameLength = readU16(localHeader, 26)
                    val localExtraLength = readU16(localHeader, 28)
                    offsets[name] = localHeaderOffset + 30L + localNameLength + localExtraLength
                }
                cursor += 46L + nameLength + extraLength + commentLength
            }
            return offsets
        }
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun readU32(bytes: ByteArray, offset: Int): Long =
        readU16(bytes, offset).toLong() or (readU16(bytes, offset + 2).toLong() shl 16)

    private fun signApkSafely(
        input: File,
        output: File,
        onLog: (String) -> Unit,
        inputAlreadyClean: Boolean = false,
    ) {
        require(input.exists() && input.length() > 0) { "ملف APK غير موجود أو فارغ" }
        val parent = output.parentFile ?: File(".")
        if (!parent.exists()) parent.mkdirs()
        val unsigned = File(parent, ".${output.nameWithoutExtension}_${System.nanoTime()}_unsigned.apk")
        val signed = File(parent, ".${output.nameWithoutExtension}_${System.nanoTime()}_signed.apk")
        try {
            onLog("[JAR] Removing old signature and preparing clean APK")
            if (inputAlreadyClean) input.copyTo(unsigned, overwrite = true)
            else stripOldSignatures(input, unsigned)
            onLog("[JAR] Signing V1 + V2 + V3")
            signStreaming(unsigned, signed)
            val verification = ApkVerifier.Builder(signed).build().verify()
            if (!verification.isVerified) throw IllegalStateException("فشل تحقق APK Signature Scheme")
            if (output.exists() && output.canonicalPath != signed.canonicalPath) output.delete()
            signed.copyTo(output, overwrite = true)
            onLog("[JAR] Signature verified before install")
        } finally {
            unsigned.delete()
            signed.delete()
        }
    }

    private fun signStreaming(inputFile: File, outputFile: File) {
        val keyBytes = NativeToolPatcher::class.java.getResourceAsStream("/assets/testkey.pk8")?.use { it.readBytes() }
            ?: error("مفتاح التوقيع غير موجود داخل التطبيق")
        val certStream = NativeToolPatcher::class.java.getResourceAsStream("/assets/testkey.x509.pem")
            ?: error("شهادة التوقيع غير موجودة داخل التطبيق")
        val privateKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val certificate = certStream.use {
            CertificateFactory.getInstance("X.509").generateCertificate(it) as java.security.cert.X509Certificate
        }
        val signerConfig = ApkSigner.SignerConfig.Builder("EDITOR_TRUE", privateKey, Collections.singletonList(certificate)).build()
        FileInputStream(inputFile).channel.use { inputChannel ->
            java.io.RandomAccessFile(outputFile, "rw").use { outputRaf ->
                outputRaf.seek(0)
                outputRaf.setLength(0)
                val input = DataSources.asDataSource(inputChannel)
                val sink = DataSinks.asDataSink(outputRaf)
                val outputSource = DataSources.asDataSource(outputRaf)
                ApkSigner.Builder(Collections.singletonList(signerConfig))
                    .setInputApk(input)
                    .setOutputApk(sink, outputSource)
                    .setCreatedBy("EDITOR TRUE")
                    .setV1SigningEnabled(true)
                    .setV2SigningEnabled(true)
                    .setV3SigningEnabled(true)
                    .setV4SigningEnabled(false)
                    .build()
                    .sign()
            }
        }
    }

    internal fun stripOldSignatures(input: File, output: File) {
        require(input.exists() && input.length() > 0) { "ملف APK غير موجود أو فارغ" }
        val module = ApkModule.loadApkFile(input)
        try {
            writeCleanAlignedApk(module, output) { }
        } finally {
            module.close()
        }
    }

    internal fun writeCleanAlignedApk(module: ApkModule, output: File, onLog: (String) -> Unit) {
        val oldSignatureEntries = module.listInputSources()
            .map { it.alias }
            .filter(::isOldSignatureMetadata)
        oldSignatureEntries.forEach { module.removeInputSource(it) }

        val writer = module.createApkFileWriter(output)
        writer.use { apkWriter ->
            val aligner = apkWriter.zipAligner ?: ZipAligner.apkAligner()
            aligner.setFileAlignment(ZipAligner.PREDICATE_NATIVE_LIBS, NATIVE_LIBRARY_ALIGNMENT)
            apkWriter.zipAligner = aligner
            apkWriter.setApkSignatureBlock(null)
            module.listInputSources()
                .filter { isNativeLibraryEntry(it.alias) }
                .forEach { it.method = ZipEntry.STORED }
            apkWriter.write()
        }
        onLog("[JAR] APK writer configured: native libraries stored and aligned to 16KB; old signatures removed")
    }

    private fun isOldSignatureMetadata(name: String): Boolean {
        val upper = name.uppercase()
        if (!upper.startsWith("META-INF/")) return false
        val leaf = upper.substringAfterLast('/')
        return leaf == "MANIFEST.MF" || leaf.startsWith("SIG-") ||
            leaf.endsWith(".SF") || leaf.endsWith(".RSA") || leaf.endsWith(".DSA") || leaf.endsWith(".EC")
    }


}
