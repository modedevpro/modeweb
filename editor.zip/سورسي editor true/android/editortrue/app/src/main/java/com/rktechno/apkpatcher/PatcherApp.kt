package com.rktechno.apkpatcher

/** Hosts EditorTrue and initializes the complete embedded Universal Installer stack. */
class PatcherApp : app.pwhs.universalinstaller.App()
