package com.rktechno.apkpatcher.ui

import app.pwhs.core.util.EditorTrueStorage
import app.pwhs.core.install.ApkExtractor

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.graphics.drawable.Drawable
import android.view.WindowManager
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.rktechno.apkpatcher.BuildConfig
import com.rktechno.apkpatcher.R
import android.content.BroadcastReceiver
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ApplicationInfo
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.documentfile.provider.DocumentFile
import com.rktechno.apkpatcher.core.PatchService
import com.rktechno.apkpatcher.core.PatcherFlags
import com.rktechno.apkpatcher.core.ApkSignatureInspector
import com.rktechno.apkpatcher.core.NativeToolPatcher
import com.rktechno.apkpatcher.core.SplitBundlePatcher
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.navigation.NavigationView
import rikka.shizuku.Shizuku
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File


/**
 * الشاشة الرئيسية للتطبيق - نظير أوامر /start و /flags ومعالجة المستندات في البوت.
 *
 * تدفق العمل:
 * 1. المستخدم يختار ملف APK/APKS/XAPK/APKM
 * 2. يفعّل الفلاجات المطلوبة من القائمة (تماماً كبوت تيليجرام)
 * 3. يضغط "بدء المعالجة" فتبدأ مراحل الفك → الباتش → إعادة التجميع → التوقيع
 * 4. تظهر النتيجة مع خيار التثبيت أو المشاركة
 */
class MainActivity : AppCompatActivity() {

    private val viewModel: PatcherViewModel by viewModels()
    
    private val toolbar by lazy { findViewById<MaterialToolbar>(R.id.toolbar) }
    private val drawerLayout by lazy { findViewById<DrawerLayout>(R.id.drawerLayout) }
    private val navView by lazy { findViewById<NavigationView>(R.id.navView) }
    private val rvFlags by lazy { findViewById<RecyclerView>(R.id.rvFlags) }
    private val rvLogs by lazy { findViewById<RecyclerView>(R.id.rvLogs) }
    private val btnCopyLogs by lazy { findViewById<MaterialButton>(R.id.btnCopyLogs) }
    private val btnSelectFile by lazy { findViewById<MaterialButton>(R.id.btnSelectFile) }
    private val btnSelectInstalledApp by lazy { findViewById<MaterialButton>(R.id.btnSelectInstalledApp) }
    private val btnResetFlags by lazy { findViewById<MaterialButton>(R.id.btnResetFlags) }
    private val btnShowCmd by lazy { findViewById<MaterialButton>(R.id.btnShowCmd) }
    private val btnSelectCert by lazy { findViewById<MaterialButton>(R.id.btnSelectCert) }
    private val btnSetModule by lazy { findViewById<MaterialButton>(R.id.btnSetModule) }
    private val btnStart by lazy { findViewById<MaterialButton>(R.id.btnStart) }
    private val btnStop by lazy { findViewById<MaterialButton>(R.id.btnStop) }
    private val btnModifiedApps by lazy { findViewById<MaterialButton>(R.id.btnModifiedApps) }
    private val btnInstall by lazy { findViewById<MaterialButton>(R.id.btnInstall) }
    private val btnShare by lazy { findViewById<MaterialButton>(R.id.btnShare) }
    private val tvFileName by lazy { findViewById<TextView>(R.id.tvFileName) }
    private val tvFileSize by lazy { findViewById<TextView>(R.id.tvFileSize) }
    private val tvCurrentStep by lazy { findViewById<TextView>(R.id.tvCurrentStep) }
    private val progressBar by lazy { findViewById<LinearProgressIndicator>(R.id.progressBar) }
    private val tvProgressPercent by lazy { findViewById<TextView>(R.id.tvProgressPercent) }
    private val cardProgress by lazy { findViewById<MaterialCardView>(R.id.cardProgress) }
    private val cardResult by lazy { findViewById<MaterialCardView>(R.id.cardResult) }
    private val cardFile by lazy { findViewById<MaterialCardView>(R.id.cardFile) }
    private val cardWorkflow by lazy { findViewById<MaterialCardView>(R.id.cardWorkflow) }
    private val tvResultTitle by lazy { findViewById<TextView>(R.id.tvResultTitle) }
    private val tvOutputFile by lazy { findViewById<TextView>(R.id.tvOutputFile) }
    private val tvAppliedFlags by lazy { findViewById<TextView>(R.id.tvAppliedFlags) }
    private val tvTimeSpent by lazy { findViewById<TextView>(R.id.tvTimeSpent) }

    // Minimal adapter definitions to avoid missing class errors
    private lateinit var flagsAdapter: FlagsAdapter
    private lateinit var logsAdapter: LogsAdapter
    private var patchStartedAt = 0L
    private var mainExitWarning: android.app.AlertDialog? = null
    private var renderedLogCount = 0
    private var lastProcessingState = false

    private data class InstalledAppChoice(
        val packageName: String,
        val label: String,
        val splitCount: Int,
        val icon: Drawable?,
    )

    private inner class InstalledAppsAdapter(
        private val choices: List<InstalledAppChoice>,
    ) : ArrayAdapter<InstalledAppChoice>(this@MainActivity, R.layout.installed_app_choice_row, choices) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView ?: layoutInflater.inflate(R.layout.installed_app_choice_row, parent, false)
            val choice = choices[position]
            row.findViewById<ImageView>(R.id.installedAppIcon)
                .setImageDrawable(choice.icon ?: packageManager.defaultActivityIcon)
            row.findViewById<TextView>(R.id.installedAppLabel).text = choice.label
            row.findViewById<TextView>(R.id.installedAppPackage).text = choice.packageName
            row.findViewById<TextView>(R.id.installedAppSplitCount).apply {
                visibility = if (choice.splitCount > 0) View.VISIBLE else View.GONE
                if (choice.splitCount > 0) {
                    text = getString(R.string.installed_app_split_count, choice.splitCount)
                }
            }
            return row
        }
    }

    private enum class ShizukuState { ENABLED, PERMISSION_REQUIRED, NOT_RUNNING, NOT_INSTALLED }

    private val shizukuPermissionListener = object : Shizuku.OnRequestPermissionResultListener {
        override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
            if (requestCode != SHIZUKU_PERMISSION_REQUEST) return
            runOnUiThread {
                refreshShizukuMenuStatus()
                val granted = grantResult == PackageManager.PERMISSION_GRANTED && hasShizukuPermission()
                Toast.makeText(
                    this@MainActivity,
                    getString(if (granted) R.string.shizuku_permission_enabled else R.string.shizuku_permission_not_enabled),
                    Toast.LENGTH_LONG,
                ).show()
            }
        }
    }

    // منتقي الملفات - يدعم APK | APKS | XAPK | APKM
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) handleSelectedUris(uris)
    }

    // استقبال نتائج وسجلات الخدمة لحظياً
    private val resultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            when (intent.action) {
                PatchService.ACTION_LOG -> {
                    val progress = intent.getFloatExtra(PatchService.EXTRA_PROGRESS, -1f)
                    val batch = intent.getStringArrayListExtra(PatchService.EXTRA_LOG_BATCH)
                    if (!batch.isNullOrEmpty()) {
                        viewModel.updateLiveLogs(batch, progress)
                    } else {
                        val msg = intent.getStringExtra(PatchService.EXTRA_LOG_MSG) ?: return
                        viewModel.updateLiveLog(msg, progress)
                    }
                }
                PatchService.ACTION_RESULT -> {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    mainExitWarning?.dismiss()
                    mainExitWarning = null
                    val success = intent.getBooleanExtra(PatchService.EXTRA_SUCCESS, false)
                    val outputPath = intent.getStringExtra(PatchService.EXTRA_OUTPUT_PATH)
                    val error = intent.getStringExtra(PatchService.EXTRA_ERROR)
                    val apkName = intent.getStringExtra(PatchService.EXTRA_APK_NAME) ?: ""
                    val elapsed = intent.getLongExtra(PatchService.EXTRA_ELAPSED, 0L)
                    if (success && outputPath != null) {
                        viewModel.patchFinished(success = true, outputFile = File(outputPath), apkName = apkName, error = null, elapsedMs = elapsed)
                    } else {
                        viewModel.patchFinished(success = false, outputFile = null, apkName = apkName, error = error, elapsedMs = elapsed)
                    }
                }
            }
        }
    }

    // منتقي شهادة CA
    private val certPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleSelectedCert(it) }
    }

    override fun attachBaseContext(newBase: Context) {
        val langCode = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE)
            .getString("lang", "ar") ?: "ar"
        val locale = java.util.Locale(langCode)
        java.util.Locale.setDefault(locale)
        val config = android.content.res.Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupEditorTrueBottomNavigation()
        setupToolbar()
        runCatching { Shizuku.addRequestPermissionResultListener(shizukuPermissionListener) }
        setupFlagsRecyclerView()
        setupLogsRecyclerView()
        setupClickListeners()
        observeState()
        playRoyalEntrance()
        addPressAnimation(btnSelectFile)
        addPressAnimation(btnSelectInstalledApp)
        addPressAnimation(btnStart)
        addPressAnimation(btnModifiedApps)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
            }
        })
        
        try {
            val filter = android.content.IntentFilter().apply {
                addAction(PatchService.ACTION_RESULT)
                addAction(PatchService.ACTION_LOG)
            }
            registerReceiver(
                resultReceiver,
                filter,
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) Context.RECEIVER_NOT_EXPORTED else 0
            )
        } catch (e: Exception) {
            android.util.Log.w("APKPatcher", "تعذر تسجيل مستقبل البث: ${e.message}")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshShizukuMenuStatus()
        // فحص صلاحية التخزين عند كل عودة للتطبيق
        if (!hasStoragePermission()) {
            showMandatoryPermissionDialog()
        }
        pendingInstallFile?.let { file ->
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || packageManager.canRequestPackageInstalls()) {
                pendingInstallFile = null
                lifecycleScope.launch(Dispatchers.Main) {
                    kotlinx.coroutines.delay(300)
                    executeSystemInstall(file)
                }
            }
        }
    }

    override fun onDestroy() {
        runCatching { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener) }
        super.onDestroy()
        try {
            unregisterReceiver(resultReceiver)
        } catch (_: Exception) {}
    }

    private fun setupEditorTrueBottomNavigation() {
        val bottomNavigation = findViewById<LinearLayout>(R.id.editorTrueBottomNav)
        val itemsRow = findViewById<LinearLayout>(R.id.editorTrueBottomNavItems)
        val gold = Color.rgb(242, 195, 91)
        val muted = Color.rgb(185, 173, 146)
        val titles = intArrayOf(
            R.string.bottom_nav_traffic,
            R.string.bottom_nav_tools,
            R.string.bottom_nav_editortrue,
            R.string.bottom_nav_more,
            R.string.bottom_nav_settings,
        )
        val iconCodes = intArrayOf(0xF4D6, 0xF0E0, 0, 0xF7C4, 0xF36E)
        val fallbackIcons = intArrayOf(
            R.drawable.nav_traffic,
            R.drawable.nav_tools,
            0,
            R.drawable.nav_more,
            R.drawable.nav_settings,
        )
        val iconTypeface = runCatching {
            Typeface.createFromAsset(assets, "flutter_assets/fonts/MaterialIcons-Regular.otf")
        }.getOrNull()
        val editorTrueLogo = runCatching {
            assets.open("flutter_assets/assets/editortrue_icon.png").use { BitmapFactory.decodeStream(it) }
        }.getOrNull()

        itemsRow.removeAllViews()
        titles.indices.forEach { index ->
            val isEditorTrue = index == 2
            val label = getString(titles[index])
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                contentDescription = label
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.editortrue_bottom_nav_item_ripple)
                setPadding(dp(2), dp(3), dp(2), dp(3))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) tooltipText = label
            }

            if (isEditorTrue) {
                item.addView(createEditorTrueNavIcon(editorTrueLogo, gold))
            } else if (iconTypeface != null) {
                item.addView(TextView(this).apply {
                    text = String(Character.toChars(iconCodes[index]))
                    typeface = iconTypeface
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                    setTextColor(muted)
                    gravity = Gravity.CENTER
                    includeFontPadding = false
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }, LinearLayout.LayoutParams(dp(22), dp(22)))
            } else {
                item.addView(ImageView(this).apply {
                    setImageResource(fallbackIcons[index])
                    setColorFilter(muted)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }, LinearLayout.LayoutParams(dp(22), dp(22)))
            }

            item.addView(TextView(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
                setLineSpacing(0f, 1.1f)
                setTextColor(if (isEditorTrue) gold else muted)
                typeface = Typeface.create(if (isEditorTrue) "sans-serif" else "sans-serif-medium", Typeface.NORMAL)
                    .let { if (isEditorTrue) Typeface.create(it, Typeface.BOLD) else it }
                gravity = Gravity.CENTER
                includeFontPadding = false
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(3)
            })

            item.setOnClickListener {
                val targetTab = when (index) {
                    0 -> 0
                    1 -> 1
                    3 -> 2
                    4 -> 3
                    else -> -1
                }
                if (targetTab >= 0) returnToProxyPinTab(targetTab)
            }
            itemsRow.addView(item)
        }

        val originalBottomPadding = bottomNavigation.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(bottomNavigation) { view, insets ->
            val safeBottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, maxOf(originalBottomPadding, safeBottom))
            insets
        }
        ViewCompat.requestApplyInsets(bottomNavigation)
    }

    private fun createEditorTrueNavIcon(logo: Bitmap?, gold: Int): View {
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val image = ImageView(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(Color.rgb(18, 20, 22))
                cornerRadius = dp(10).toFloat()
            }
            clipToOutline = true
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (logo != null) setImageBitmap(logo) else setImageResource(R.mipmap.ic_launcher)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        frame.addView(image, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        frame.addView(View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1.2f).coerceAtLeast(1), gold)
            }
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        return frame
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun returnToProxyPinTab(tabIndex: Int) {
        val hostIntent = Intent().setClassName(packageName, "com.network.proxy.MainActivity").apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("com.network.proxy.selectedTab", tabIndex)
        }
        startActivity(hostIntent)
        finish()
        overridePendingTransition(0, 0)
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(R.string.app_name)
        toolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }
        setupDrawerNavigation()
    }

    private fun setupDrawerNavigation() {
        navView.setNavigationItemSelectedListener { menuItem ->
            drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    // الصفحة الرئيسية نشطة بالفعل
                }
                R.id.nav_modified_apps -> {
                    showModifiedAppsDialog()
                }
                R.id.nav_editor_x -> {
                    startActivity(Intent(this, EditorXActivity::class.java))
                }
                R.id.nav_universal_installer -> {
                    startActivity(Intent(this, app.pwhs.universalinstaller.presentation.install.InstallActivity::class.java))
                }
                R.id.nav_ui_manage -> {
                    startActivity(Intent(this, app.pwhs.universalinstaller.presentation.manage.ManageActivity::class.java))
                }
                R.id.nav_ui_sync -> {
                    startActivity(Intent(this, app.pwhs.universalinstaller.presentation.sync.SyncActivity::class.java))
                }
                R.id.nav_ui_downloads -> {
                    startActivity(Intent(this, app.pwhs.universalinstaller.presentation.download.DownloadHistoryActivity::class.java))
                }
                R.id.nav_ui_backups -> {
                    startActivity(Intent(this, app.pwhs.universalinstaller.presentation.manage.BackupsActivity::class.java))
                }
                R.id.nav_ui_settings -> {
                    startActivity(Intent(this, app.pwhs.universalinstaller.presentation.setting.SettingActivity::class.java))
                }
                R.id.nav_shizuku -> {
                    showShizukuStatusDialog()
                }
                R.id.nav_language -> {
                    showLanguageChoiceDialog()
                }
                R.id.nav_telegram -> {
                    openUrl("https://t.me/editortrue")
                }
                R.id.nav_youtube -> {
                    openUrl("https://youtube.com/@editortrue")
                }

            }
            true
        }
    }


    private fun shizukuState(): ShizukuState = when {
        !isShizukuInstalled() -> ShizukuState.NOT_INSTALLED
        !isShizukuRunning() -> ShizukuState.NOT_RUNNING
        hasShizukuPermission() -> ShizukuState.ENABLED
        else -> ShizukuState.PERMISSION_REQUIRED
    }

    private fun refreshShizukuMenuStatus() {
        val item = runCatching { navView.menu.findItem(R.id.nav_shizuku) }.getOrNull() ?: return
        val label = when (shizukuState()) {
            ShizukuState.ENABLED -> R.string.nav_shizuku_enabled
            ShizukuState.PERMISSION_REQUIRED -> R.string.nav_shizuku_disabled
            ShizukuState.NOT_RUNNING -> R.string.nav_shizuku_not_running
            ShizukuState.NOT_INSTALLED -> R.string.nav_shizuku_not_installed
        }
        item.title = getString(label)
    }

    private fun isShizukuInstalled(): Boolean {
        @Suppress("DEPRECATION")
        return runCatching { packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0) }.isSuccess
    }

    private fun isShizukuRunning(): Boolean =
        runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    private fun hasShizukuPermission(): Boolean = runCatching {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    private fun showShizukuStatusDialog() {
        val builder = MaterialAlertDialogBuilder(this).setTitle(R.string.shizuku_status_title)
        when (shizukuState()) {
            ShizukuState.NOT_INSTALLED -> builder
                .setMessage(R.string.shizuku_status_not_installed)
                .setPositiveButton(R.string.shizuku_install_play_store) { _, _ -> openShizukuStore() }
                .setNegativeButton(R.string.cancel, null)
            ShizukuState.NOT_RUNNING -> builder
                .setMessage(R.string.shizuku_status_not_running)
                .setPositiveButton(R.string.shizuku_open_app) { _, _ -> openShizukuManager() }
                .setNegativeButton(R.string.cancel, null)
            ShizukuState.PERMISSION_REQUIRED -> builder
                .setMessage(R.string.shizuku_status_no_permission)
                .setPositiveButton(R.string.shizuku_enable) { _, _ -> requestOptionalShizukuPermission() }
                .setNegativeButton(R.string.cancel, null)
            ShizukuState.ENABLED -> builder
                .setMessage(R.string.shizuku_status_enabled)
                .setPositiveButton(R.string.shizuku_open_app) { _, _ -> openShizukuManager() }
                .setNegativeButton(R.string.cancel, null)
        }
        builder.show()
    }

    private fun requestOptionalShizukuPermission() {
        if (!isShizukuRunning()) {
            showShizukuStatusDialog()
            return
        }
        try {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST)
        } catch (error: Throwable) {
            Toast.makeText(this, error.message ?: getString(R.string.shizuku_status_not_running), Toast.LENGTH_LONG).show()
        }
    }

    private fun openShizukuManager() {
        val launchIntent = runCatching { packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) }.getOrNull()
        if (launchIntent != null) {
            startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        } else {
            openShizukuStore()
        }
    }

    private fun openShizukuStore() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PACKAGE")))
        } catch (_: Throwable) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PACKAGE")))
        }
    }

    private fun showInstalledAppsPicker() {
        lifecycleScope.launch {
            val apps = withContext(Dispatchers.IO) { loadInstalledAppChoices() }
            if (apps.isEmpty()) {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.installed_apps_title)
                    .setMessage(R.string.installed_apps_none)
                    .setPositiveButton(R.string.ok, null)
                    .show()
                return@launch
            }
            MaterialAlertDialogBuilder(this@MainActivity)
                .setTitle(R.string.installed_apps_title)
                .setAdapter(InstalledAppsAdapter(apps)) { _, index -> importInstalledApp(apps[index]) }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    @Suppress("DEPRECATION")
    private fun loadInstalledAppChoices(): List<InstalledAppChoice> =
        packageManager.getInstalledApplications(0)
            .asSequence()
            .filter { app ->
                app.packageName != packageName &&
                    ((app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0)
            }
            .mapNotNull { app ->
                val sourcePath = app.sourceDir
                if (sourcePath.isNullOrBlank() || !File(sourcePath).canRead()) return@mapNotNull null
                val label = runCatching { app.loadLabel(packageManager).toString() }
                    .getOrDefault(app.packageName)
                val icon = runCatching { app.loadIcon(packageManager) }.getOrNull()
                InstalledAppChoice(app.packageName, label, app.splitSourceDirs?.size ?: 0, icon)
            }
            .sortedBy { it.label.lowercase(java.util.Locale.ROOT) }
            .toList()

    private fun importInstalledApp(choice: InstalledAppChoice) {
        val density = resources.displayMetrics.density
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((22 * density).toInt(), (16 * density).toInt(), (22 * density).toInt(), (16 * density).toInt())
            addView(ProgressBar(this@MainActivity).apply { isIndeterminate = true })
            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.installed_app_extracting)
                setPadding((16 * density).toInt(), 0, 0, 0)
            })
        }
        val progressDialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.installed_apps_title)
            .setView(content)
            .setCancelable(false)
            .create()
        progressDialog.show()
        lifecycleScope.launch {
            try {
                val extractedFile = withContext(Dispatchers.IO) {
                    val outputDir = File(filesDir, "input_apks").also { it.mkdirs() }
                    val extraction = ApkExtractor.extract(
                        context = this@MainActivity,
                        packageName = choice.packageName,
                        outputDir = DocumentFile.fromFile(outputDir),
                        filenameTemplate = "{name}-{version}",
                        splitFormat = ApkExtractor.SplitFormat.APKS,
                        includeObb = false,
                    )
                    when (extraction) {
                        is ApkExtractor.Result.Failure -> throw IllegalStateException(extraction.message)
                        is ApkExtractor.Result.Success -> {
                            val path = extraction.uri.path
                                ?: throw IllegalStateException("The extracted APK has no file path")
                            File(path).takeIf { it.isFile && it.length() > 0L }
                                ?: throw IllegalStateException("The extracted APK file is missing or empty")
                        }
                    }
                }
                getSharedPreferences("patcher_batch", MODE_PRIVATE).edit().remove("paths").apply()
                viewModel.selectApk(extractedFile)
                Toast.makeText(this@MainActivity, getString(R.string.installed_app_imported, choice.label), Toast.LENGTH_LONG).show()
            } catch (error: Throwable) {
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.installed_app_extract_failed, error.message ?: error.javaClass.simpleName),
                    Toast.LENGTH_LONG,
                ).show()
            } finally {
                progressDialog.dismiss()
            }
        }
    }

    /** Editor X profile integrated with EDITOR TRUE's existing safe background pipeline. */
    private fun showEditorXDialog() {
        val levels = getString(R.string.editor_x_levels).split("|").toTypedArray()
        var selected = 3
        MaterialAlertDialogBuilder(this)
            .setTitle("Editor X")
            .setMessage(getString(R.string.editor_x_message))
            .setSingleChoiceItems(levels, selected) { _, which -> selected = which }
            .setPositiveButton(getString(R.string.editor_x_enable)) { _, _ ->
                // Reuse the existing tested pipeline; the original APK remains untouched.
                viewModel.resetFlags()
                viewModel.toggleFlag("-fix")
                if (selected >= 1) viewModel.toggleFlag("-pkg")
                if (selected >= 2) viewModel.toggleFlag("-shield")
                Snackbar.make(drawerLayout, getString(R.string.editor_enabled, selected + 1), Snackbar.LENGTH_LONG).show()
                toolbar.title = "Editor X"
            }
            .setNeutralButton(getString(R.string.editor_x_about)) { _, _ ->
                MaterialAlertDialogBuilder(this)
                    .setTitle(getString(R.string.editor_x_about_title))
                    .setMessage(getString(R.string.editor_x_about_message))
                    .setPositiveButton(getString(R.string.ok), null)
                    .show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showLanguageChoiceDialog() {
        val langs = arrayOf(getString(R.string.language_arabic), getString(R.string.language_english))
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.language_dialog_title))
            .setItems(langs) { _, which ->
                val langCode = if (which == 0) "ar" else "en"
                setAppLanguage(langCode)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun setAppLanguage(langCode: String) {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        prefs.edit().putString("lang", langCode).apply()
        val locale = java.util.Locale(langCode)
        java.util.Locale.setDefault(locale)
        val config = android.content.res.Configuration(resources.configuration)
        config.setLocale(locale)
        createConfigurationContext(config)
        resources.updateConfiguration(config, resources.displayMetrics)
        
        // إعادة تشغيل التطبيق بالكامل من النشاط الرئيسي لضمان تحديث كل النصوص والقوائم فوراً
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
    }

    private fun setupFlagsRecyclerView() {
        flagsAdapter = FlagsAdapter { flagKey -> viewModel.toggleFlag(flagKey) }
        rvFlags.layoutManager = LinearLayoutManager(this)
        rvFlags.adapter = flagsAdapter
        refreshFlagsList()
    }

    private fun setupLogsRecyclerView() {
        logsAdapter = LogsAdapter()
        rvLogs.layoutManager = LinearLayoutManager(this)
        rvLogs.adapter = logsAdapter
    }

    private fun setupClickListeners() {
        // اختيار ملف APK - من الملفات أو التطبيقات المثبتة
        btnSelectFile.setOnClickListener {
            showSourceChoiceDialog()
        }
        btnSelectInstalledApp.setOnClickListener {
            showInstalledAppsPicker()
        }

        // إعادة ضبط الفلاجات
        btnResetFlags.setOnClickListener {
            try {
                viewModel.resetFlags()
                if (::flagsAdapter.isInitialized) refreshFlagsList()
                Snackbar.make(drawerLayout, getString(R.string.reset_done), Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.util.Log.e("APKPatcher", "فشل إعادة ضبط الباتشات", e)
                Toast.makeText(this, getString(R.string.reset_failed), Toast.LENGTH_SHORT).show()
            }
        }

        // معاينة الأمر النهائي (نظير show_cmd في البوت)
        btnShowCmd.setOnClickListener {
            val s = viewModel.state.value
            val flagsStr = s.activeFlags.sorted().joinToString(" ")
            val activeText = if (flagsStr.isBlank()) getString(R.string.no_flags) else flagsStr
            val cmd = getString(R.string.input_file_command, s.apkName.ifEmpty { "<app_name>" }) + "\n" + getString(R.string.active_flags_command, activeText) + "\n\n" + getString(R.string.command_label, s.apkName.ifEmpty { "<app_name>" }, if (flagsStr.isBlank()) "" else " $flagsStr")
            MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.current_command))
                .setMessage(cmd)
                .setPositiveButton(getString(R.string.ok), null)
                .show()
        }

        btnCopyLogs.setOnClickListener {
            val logs = viewModel.state.value.logs.joinToString("\n")
            if (logs.isBlank()) {
                Toast.makeText(this, getString(R.string.nothing_to_copy), Toast.LENGTH_SHORT).show()
            } else {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("EditorTrue operations", logs))
                Toast.makeText(this, getString(R.string.logs_copied), Toast.LENGTH_SHORT).show()
            }
        }

        // اختيار شهادة CA (-c)
        btnSelectCert.setOnClickListener {
            certPickerLauncher.launch("*/*")
        }

        // إدخال مسار موديول (-l)
        btnSetModule.setOnClickListener {
            val input = android.widget.EditText(this).apply {
                hint = getString(R.string.enter_module_path)
                setPadding(48, 32, 48, 32)
            }
            MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.module_path))
                .setView(input)
                .setPositiveButton(getString(R.string.set)) { _, _ ->
                    val path = input.text.toString().trim()
                    if (path.isNotEmpty()) {
                        viewModel.setModulePath(path)
                        Snackbar.make(drawerLayout, "${getString(R.string.module_set)}: $path", Snackbar.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }

        // بدء المعالجة (في الخدمة الخلفية)
        btnStart.setOnClickListener {
            val s = viewModel.state.value
            if (s.isProcessing) {
                Toast.makeText(this, getString(R.string.processing_already_running), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (s.selectedApk == null) {
                Snackbar.make(drawerLayout, getString(R.string.no_file_selected), Snackbar.LENGTH_LONG).show()
                return@setOnClickListener
            }
            
            // التحقق من الصلاحية إجبارياً قبل البدء
            if (!hasStoragePermission()) {
                showMandatoryPermissionDialog()
                return@setOnClickListener
            }

            if (!ensureNotificationPermission()) return@setOnClickListener
            
            // التحقق من اختيار باتش واحد على الأقل
            if (viewModel.state.value.activeFlags.isEmpty()) {
                Toast.makeText(this, getString(R.string.at_least_one), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // بدء المعالجة - الزر سيبقى متاحاً لعمليات أخرى
            patchStartedAt = System.currentTimeMillis()
            viewModel.startPatching()
            Toast.makeText(this, getString(R.string.started_processing), Toast.LENGTH_SHORT).show()
        }

        btnStop.setOnClickListener {
            viewModel.cancelPatching(force = true)
            Toast.makeText(this, getString(R.string.stop_requested), Toast.LENGTH_SHORT).show()
        }

        // عن التطبيق والحقوق
// إدارة التطبيقات المعدلة
        btnModifiedApps.setOnClickListener {
            showModifiedAppsDialog()
        }

        // تثبيت الملف الناتج
        btnInstall.setOnClickListener {
            val file = viewModel.state.value.result?.outputFile ?: return@setOnClickListener
            installApk(file)
        }

        // مشاركة الملف الناتج
        btnShare.setOnClickListener {
            val file = viewModel.state.value.result?.outputFile ?: return@setOnClickListener
            shareApk(file)
        }
    }

    private fun playRoyalEntrance() {
        val views = listOf<View>(cardFile, btnSelectInstalledApp, cardWorkflow, btnStart, btnModifiedApps)
        views.forEachIndexed { index, view ->
            view.postDelayed({
                view.startAnimation(AnimationUtils.loadAnimation(this, R.anim.royal_fade_up))
            }, index * 90L)
        }
    }

    private fun addPressAnimation(view: View) {
        view.setOnTouchListener { pressedView, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> pressedView.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressedView.animate().scaleX(1f).scaleY(1f).setDuration(140L).start()
            }
            false
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                // تجميع تحديثات الخدمة كل 200ms يمنع إعادة رسم الواجهة لكل سطر سجل.
                viewModel.state.sample(200L).collect { state ->
                    try {
                    // تحديث بطاقة الملف
                    if (state.selectedApk != null) {
                        val name = if (state.apkName.isNotEmpty()) state.apkName else (state.selectedApk?.name ?: getString(R.string.unknown))
                        val size = if (state.apkSize > 0) viewModel.humanBytes(state.apkSize) else (state.selectedApk?.length()?.let { viewModel.humanBytes(it) } ?: "0 B")
                        
                        tvFileName.text = getString(R.string.selected_file_label, name)
                        tvFileSize.apply {
                            visibility = View.VISIBLE
                            text = getString(R.string.size_label, size)
                        }
                        btnSelectFile.text = getString(R.string.change_file)
                    } else {
                        tvFileName.text = getString(R.string.no_file_selected_main)
                        tvFileSize.visibility = View.GONE
                        btnSelectFile.text = getString(R.string.select_apk_btn)
                    }

                    // تحديث قائمة الفلاجات
                    refreshFlagsList()

                    // حالة المعالجة (نجعل كرت التقدم يظهر دائماً إذا كان هناك تقدم أو خطوة مسجلة لكي لا يختفي)
                    val showProgressCard = state.isProcessing || state.result != null
                    val progressWasHidden = cardProgress.visibility != View.VISIBLE
                    cardProgress.visibility = if (showProgressCard) View.VISIBLE else View.GONE
                    if (showProgressCard && progressWasHidden) {
                        cardProgress.alpha = 0f
                        cardProgress.animate().alpha(1f).translationY(0f).setDuration(380L).start()
                    }
                    btnStart.isEnabled = !state.isProcessing && state.selectedApk != null
                    btnStop.visibility = if (state.isProcessing) View.VISIBLE else View.GONE
                    btnStop.isEnabled = state.isProcessing
                    btnStart.text = getString(R.string.start_patching)
                    if (state.isProcessing != lastProcessingState) {
                        lastProcessingState = state.isProcessing
                        if (state.isProcessing) {
                            btnStart.startAnimation(AnimationUtils.loadAnimation(this@MainActivity, R.anim.royal_pulse))
                        } else {
                            btnStart.clearAnimation()
                            btnStart.animate().scaleX(1f).scaleY(1f).setDuration(180L).start()
                        }
                    }
                    tvCurrentStep.text = if (state.currentStep.isNotEmpty()) state.currentStep else getString(R.string.ready_to_use)
                    progressBar.progress = (state.progress * 100).toInt().coerceIn(0, 100)
                    tvProgressPercent.text = "${(state.progress * 100).toInt().coerceIn(0, 100)}%"

                    // تحديث السجل
                    if (state.logs.isNotEmpty()) {
                        if (state.logs.size < renderedLogCount) {
                            logsAdapter.clear()
                            renderedLogCount = 0
                        }
                        val newLogs = state.logs.drop(renderedLogCount)
                        logsAdapter.addLogs(newLogs)
                        val shouldScroll = newLogs.isNotEmpty()
                        renderedLogCount = state.logs.size
                        if (shouldScroll) rvLogs.scrollToPosition(state.logs.size - 1)
                    }

                    // النتيجة
                    state.result?.let { result ->
                        val outputFile = result.outputFile?.takeIf { it.isFile && it.length() > 0L }
                        val outputReady = result.success && outputFile != null
                        val wasHidden = cardResult.visibility != View.VISIBLE
                        cardResult.visibility = View.VISIBLE
                        if (wasHidden) {
                            cardResult.alpha = 0f
                            cardResult.translationY = 24f
                            cardResult.animate().alpha(1f).translationY(0f).setDuration(520L).start()
                        }
                        tvResultTitle.text = if (outputReady) {
                            "✅ ${getString(R.string.success)}"
                        } else {
                            "❌ ${getString(R.string.failed)}"
                        }
                        tvResultTitle.setTextColor(
                            getColor(if (outputReady) R.color.success else R.color.error)
                        )
                        tvOutputFile.text = when {
                            outputReady -> "${getString(R.string.output_file)} ${outputFile!!.name}"
                            result.success -> "تعذر العثور على ملف الناتج المحفوظ داخل EditorTrue/Modified"
                            else -> getString(R.string.reason_label, result.errorMessage)
                        }
                        tvAppliedFlags.text = "${getString(R.string.applied_flags)} ${result.appliedFlags.joinToString(", ")}"
                        tvTimeSpent.text = getString(R.string.time_spent) + " " + getString(R.string.seconds_suffix, result.elapsedMs / 1000.0)
                        btnInstall.visibility = if (outputReady) View.VISIBLE else View.GONE
                        btnShare.visibility = if (outputReady) View.VISIBLE else View.GONE
                    } ?: run {
                        cardResult.visibility = View.GONE
                        btnInstall.visibility = View.GONE
                        btnShare.visibility = View.GONE
                    }
                    } catch (e: Exception) {
                        // أي خطأ في تحديث الواجهة (مثل مورد نص ناقص) لا يسبب كراش
                        android.util.Log.e("APKPatcher", "خطأ في تحديث الواجهة", e)
                    }
                }
            }
        }
    }

    private fun refreshFlagsList() {
        val activeFlags = viewModel.state.value.activeFlags
        flagsAdapter.updateData(activeFlags)
    }

    // ---------------------------------------------------------
    // اختيار من التطبيقات المثبتة أو من الملفات
    // ---------------------------------------------------------
    private fun showSourceChoiceDialog() {
        // اختيار الملفات فقط بناءً على طلب المستخدم
        filePickerLauncher.launch("*/*")
    }

    private fun ensureNotificationPermission(): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
                return false
            }
        }
        return true
    }

    // ---------------------------------------------------------
    // معالجة الملف المختار
    // ---------------------------------------------------------
    private fun handleSelectedUri(uri: Uri) {
        val fileName = getFileName(uri) ?: run {
            Toast.makeText(this, getString(R.string.file_name_failed), Toast.LENGTH_SHORT).show()
            return
        }

        // التحقق من الامتداد
        val lowerName = fileName.lowercase()
        val isValid = lowerName.endsWith(".apk") || lowerName.endsWith(".apks") ||
                lowerName.endsWith(".xapk") || lowerName.endsWith(".apkm")
        if (!isValid) {
            Toast.makeText(
                this,
                getString(R.string.unsupported_file),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        // نسخ الملف إلى مجلد التطبيق الخاص باستخدام مخزن كبير للملفات الضخمة
        lifecycleScope.launch {
            try {
                val destDir = File(filesDir, "input_apks").also { it.mkdirs() }
                val destFile = File(destDir, fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().buffered(1024 * 1024).use { output ->
                        input.copyTo(output, 1024 * 1024)
                    }
                }
                viewModel.selectApk(destFile)
                Toast.makeText(this@MainActivity, getString(R.string.file_selected, fileName), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, getString(R.string.read_file_failed, e.message), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleSelectedUris(uris: List<Uri>) {
        lifecycleScope.launch {
            try {
                val destDir = File(filesDir, "input_apks").also { it.mkdirs() }
                val paths = uris.mapNotNull { uri ->
                    val name = getFileName(uri) ?: return@mapNotNull null
                    val lower = name.lowercase()
                    if (!lower.endsWith(".apk") && !lower.endsWith(".apks") && !lower.endsWith(".xapk") && !lower.endsWith(".apkm")) return@mapNotNull null
                    val safe = File(destDir, name)
                    contentResolver.openInputStream(uri)?.use { input ->
                        safe.outputStream().buffered(1024 * 1024).use { output -> input.copyTo(output, 1024 * 1024) }
                    }
                    safe.absolutePath
                }
                if (paths.isEmpty()) {
                    Toast.makeText(this@MainActivity, getString(R.string.no_valid_apks), Toast.LENGTH_LONG).show()
                } else {
                    getSharedPreferences("patcher_batch", MODE_PRIVATE).edit()
                        .putString("paths", paths.joinToString("|||"))
                        .apply()
                    viewModel.selectApk(File(paths.first()))
                    Toast.makeText(this@MainActivity, getString(R.string.batch_selected, paths.size), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, getString(R.string.read_file_failed, e.message), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleSelectedCert(uri: Uri) {
        val fileName = getFileName(uri) ?: return
        val lower = fileName.lowercase()
        if (!lower.endsWith(".pem") && !lower.endsWith(".crt") && !lower.endsWith(".cert") && !lower.endsWith(".cer")) {
            Toast.makeText(this, getString(R.string.certificate_unsupported), Toast.LENGTH_LONG).show()
            return
        }
        lifecycleScope.launch {
            try {
                val destDir = File(filesDir, "certs").also { it.mkdirs() }
                val destFile = File(destDir, fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().buffered(1024 * 1024).use { output ->
                        input.copyTo(output, 1024 * 1024)
                    }
                }
                viewModel.setCaCertificate(destFile)
                Snackbar.make(drawerLayout, getString(R.string.certificate_saved), Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, getString(R.string.certificate_failed, e.message), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getFileName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        if (name == null) {
            name = uri.lastPathSegment?.substringAfterLast("/")
        }
        return name
    }

    // ---------------------------------------------------------
    // تثبيت ومشاركة APK
    // ---------------------------------------------------------
    private var pendingInstallFile: File? = null

    private val uninstallLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        // بعد محاولة إلغاء التثبيت عبر النظام، نتابع التثبيت فوراً
        pendingInstallFile?.let { file ->
            val f = file
            pendingInstallFile = null
            // تأخير بسيطة لضمان تحديث النظام
            lifecycleScope.launch(Dispatchers.Main) {
                kotlinx.coroutines.delay(500)
                executeSystemInstall(f)
            }
        }
    }

    private fun installApk(file: File) {
        if (!file.exists() || file.length() == 0L) {
            Toast.makeText(this, getString(R.string.file_empty), Toast.LENGTH_LONG).show()
            return
        }
        val checkDialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.signature_checking_title)
            .setMessage(R.string.signature_checking_message)
            .setView(ProgressBar(this).apply { isIndeterminate = true })
            .setCancelable(false)
            .create()
        checkDialog.show()
        lifecycleScope.launch {
            val inspection = withContext(Dispatchers.IO) {
                ApkSignatureInspector.inspect(file, File(cacheDir, "signature-checks"))
            }
            checkDialog.dismiss()
            if (inspection.error != null) {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.signature_check_failed_title)
                    .setMessage(getString(R.string.signature_check_failed_message, inspection.error))
                    .setPositiveButton(R.string.ok, null)
                    .show()
                return@launch
            }
            if (inspection.isSigned) {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.signature_valid_title)
                    .setMessage(getString(R.string.signature_valid_message, file.name, inspection.componentCount))
                    .setPositiveButton(R.string.install_action) { _, _ -> launchUniversalInstaller(file) }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            } else {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.unsigned_title)
                    .setMessage(
                        getString(
                            R.string.unsigned_message,
                            file.name,
                            inspection.unsignedComponent ?: file.name,
                        ),
                    )
                    .setPositiveButton(R.string.sign_file) { _, _ -> signUnsignedFileAndInstall(file) }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        }
    }

    private fun signUnsignedFileAndInstall(file: File) {
        val progressDialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.signing_title)
            .setMessage(R.string.signing_now)
            .setView(ProgressBar(this).apply { isIndeterminate = true })
            .setCancelable(false)
            .create()
        progressDialog.show()
        lifecycleScope.launch {
            try {
                val signedFile = withContext(Dispatchers.IO) {
                    val onLog: (String) -> Unit = { line -> viewModel.appendLog(line) }
                    if (SplitBundlePatcher.isBundleFile(file)) {
                        SplitBundlePatcher.signBundleComponents(file, onLog)
                    } else {
                        NativeToolPatcher.signFileOnly(file, onLog)
                    }
                } ?: throw IllegalStateException(getString(R.string.signing_failed))

                val verification = withContext(Dispatchers.IO) {
                    ApkSignatureInspector.inspect(signedFile, File(cacheDir, "signature-checks"))
                }
                if (verification.error != null || !verification.isSigned) {
                    throw IllegalStateException(
                        verification.error ?: getString(R.string.signing_verification_failed),
                    )
                }
                progressDialog.dismiss()
                Toast.makeText(this@MainActivity, getString(R.string.signing_success), Toast.LENGTH_LONG).show()
                launchUniversalInstaller(signedFile)
            } catch (error: Throwable) {
                progressDialog.dismiss()
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.signature_sign_failed_title)
                    .setMessage(getString(R.string.signature_sign_failed_message, error.message ?: error.javaClass.simpleName))
                    .setPositiveButton(R.string.ok, null)
                    .show()
            }
        }
    }

    private fun launchUniversalInstaller(file: File) {
        try {
        // All generated APK/APKS/XAPK/APKM files use the full upstream installer UI.
        val uri = FileProvider.getUriForFile(
            this,
            "$packageName.installer.fileprovider",
            file,
        )
        val mimeType = if (file.extension.equals("apk", ignoreCase = true)) {
            "application/vnd.android.package-archive"
        } else {
            "application/octet-stream"
        }
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setClassName(
                packageName,
                "app.pwhs.universalinstaller.presentation.install.DialogInstallActivity",
            )
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
        } catch (error: Exception) {
            Toast.makeText(this, getString(R.string.install_window_failed, error.message), Toast.LENGTH_LONG).show()
        }
    }
    // تم إلغاء كود الروت بناءً على طلب المستخدم والاعتماد كلياً على Shizuku والتثبيت النظامي



    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun showMandatoryPermissionDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.storage_title))
            .setMessage(getString(R.string.storage_message))
            .setCancelable(false)
            .setPositiveButton(getString(R.string.enable_permission)) { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        val intent = Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        intent.data = Uri.parse("package:$packageName")
                        startActivity(intent)
                    } else {
                        ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 100)
                    }
                } catch (e: Exception) {
                    val intent = Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivity(intent)
                }
            }
            .setNegativeButton(getString(R.string.close_app)) { _, _ -> finish() }
            .show()
    }

    private fun checkStoragePermission() {
        if (!hasStoragePermission()) {
            showMandatoryPermissionDialog()
        }
    }

    private fun launchNormalUninstall(targetPkgName: String) {
        val uninstallIntent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$targetPkgName")).apply {
            putExtra(Intent.EXTRA_RETURN_RESULT, true)
        }
        try {
            uninstallLauncher.launch(uninstallIntent)
        } catch (_: Throwable) {
            val fallbackIntent = Intent(Intent.ACTION_UNINSTALL_PACKAGE).apply {
                data = Uri.parse("package:$targetPkgName")
                putExtra(Intent.EXTRA_RETURN_RESULT, true)
            }
            uninstallLauncher.launch(fallbackIntent)
        }
    }

    private fun executeSystemInstall(file: File) {
        installApk(file)
    }

    private fun shareApk(file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (file.extension.equals("apk", ignoreCase = true)) {
                    "application/vnd.android.package-archive"
                } else {
                    "application/zip"
                }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, getString(R.string.share_apk_chooser)))
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.share_failed, e.message), Toast.LENGTH_SHORT).show()
        }
    }
    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.open_url_failed), Toast.LENGTH_SHORT).show()
        }
    }

    private fun showModifiedAppsDialog() {
        // الفحص من نفس المسار الذي تحفظ فيه الخدمة، خارج Download تماماً.
        val editorTrueFolder = EditorTrueStorage.modifiedApks()
        val files = editorTrueFolder.listFiles()
            ?.asSequence()
            ?.filter {
                it.isFile && it.extension.lowercase() in setOf("apk", "apks", "xapk", "apkm")
            }
            ?.distinctBy { it.absolutePath }
            ?.sortedByDescending { it.lastModified() }
            ?.toList()
            ?: emptyList()

        if (files.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("📂 ${getString(R.string.modified_apps_title)}")
                .setMessage(getString(R.string.modified_apps_empty))
                .setPositiveButton(getString(R.string.close_dialog), null)
                .show()
            return
        }

        val names = files.map { "${it.name}\n(${viewModel.humanBytes(it.length())} — ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(it.lastModified()))})" }.toTypedArray()

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.modified_apps_count, files.size))
            .setItems(names) { _, which ->
                val selectedFile = files[which]
                showSelectedModifiedAppActionDialog(selectedFile)
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    private fun showSelectedModifiedAppActionDialog(file: File) {
        val options = arrayOf("📥 ${getString(R.string.install_action)}", "📤 ${getString(R.string.share_action)}", "🗑️ ${getString(R.string.delete_action)}")
        MaterialAlertDialogBuilder(this)
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> installApk(file)
                    1 -> shareApk(file)
                    2 -> {
                        MaterialAlertDialogBuilder(this)
                            .setTitle(getString(R.string.delete_confirm_title))
                            .setMessage(getString(R.string.delete_confirm_message, file.name))
                            .setPositiveButton(getString(R.string.delete_action)) { _, _ ->
                                if (file.delete()) {
                                    Toast.makeText(this, "✔ ${getString(R.string.delete_success)}", Toast.LENGTH_SHORT).show()
                                    // إعادة فتح القائمة المحدثة
                                    showModifiedAppsDialog()
                                } else {
                                    Toast.makeText(this, "❌ ${getString(R.string.delete_failed)}", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .setNegativeButton(getString(R.string.cancel), null)
                            .show()
                    }
                }
            }
            .setNegativeButton(getString(R.string.back), null)
            .show()
    }


    companion object {
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        private const val SHIZUKU_PERMISSION_REQUEST = 7431
    }
}
