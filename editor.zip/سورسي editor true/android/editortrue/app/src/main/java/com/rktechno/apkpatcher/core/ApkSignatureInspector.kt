package com.rktechno.apkpatcher.core

import com.rktechno.apkpatcher.internal.apksig.ApkVerifier
import java.io.File
import java.util.zip.ZipFile

internal data class ApkSignatureInspection(
    val isSigned: Boolean,
    val componentCount: Int,
    val unsignedComponent: String? = null,
    val error: String? = null,
)

/** Verifies cryptographic APK signatures rather than merely looking for signature filenames. */
internal object ApkSignatureInspector {
    private val bundleExtensions = setOf("apks", "apkm", "xapk")

    fun inspect(file: File, scratchRoot: File): ApkSignatureInspection {
        if (!file.isFile || file.length() <= 0L) {
            return ApkSignatureInspection(false, 0, error = "ملف التثبيت غير موجود أو فارغ")
        }
        return when (file.extension.lowercase()) {
            "apk" -> ApkSignatureInspection(isApkSignatureValid(file), 1)
            in bundleExtensions -> inspectBundle(file, scratchRoot)
            else -> ApkSignatureInspection(false, 0, error = "امتداد الملف غير مدعوم")
        }
    }

    private fun inspectBundle(file: File, scratchRoot: File): ApkSignatureInspection {
        val workDir = File(scratchRoot, "signature_check_${System.nanoTime()}")
        if (!workDir.mkdirs()) {
            return ApkSignatureInspection(false, 0, error = "تعذر إنشاء مساحة تحقق مؤقتة")
        }
        return try {
            ZipFile(file).use { zip ->
                val apkEntries = zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.endsWith(".apk", ignoreCase = true) }
                    .toList()
                if (apkEntries.isEmpty()) {
                    return ApkSignatureInspection(false, 0, error = "لم يتم العثور على ملفات APK داخل الحزمة")
                }
                apkEntries.forEachIndexed { index, entry ->
                    val component = File(workDir, "component_$index.apk")
                    zip.getInputStream(entry).buffered().use { input ->
                        component.outputStream().buffered().use { output -> input.copyTo(output) }
                    }
                    if (!isApkSignatureValid(component)) {
                        return ApkSignatureInspection(false, apkEntries.size, unsignedComponent = entry.name)
                    }
                    component.delete()
                }
                ApkSignatureInspection(true, apkEntries.size)
            }
        } catch (error: Exception) {
            ApkSignatureInspection(false, 0, error = error.message ?: error.javaClass.simpleName)
        } finally {
            workDir.deleteRecursively()
        }
    }

    internal fun isApkSignatureValid(file: File): Boolean = try {
        ApkVerifier.Builder(file).build().verify().isVerified
    } catch (_: Exception) {
        false
    }
}
