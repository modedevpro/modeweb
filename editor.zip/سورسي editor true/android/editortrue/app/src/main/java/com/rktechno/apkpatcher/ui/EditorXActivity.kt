package com.rktechno.apkpatcher.ui

import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.provider.OpenableColumns
import android.widget.RadioGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.materialswitch.MaterialSwitch
import com.rktechno.apkpatcher.R
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Dedicated Editor X page. It deliberately does not show a dialog from navigation. */
class EditorXActivity : AppCompatActivity() {
    private val viewModel: PatcherViewModel by viewModels()
    private val toolbar by lazy { findViewById<MaterialToolbar>(R.id.editorXToolbar) }
    private val fileName by lazy { findViewById<TextView>(R.id.editorXFileName) }
    private val status by lazy { findViewById<TextView>(R.id.editorXStatus) }
    private val progress by lazy { findViewById<LinearProgressIndicator>(R.id.editorXProgress) }
    private val terminal by lazy { findViewById<ScrollView>(R.id.editorXTerminal) }
    private val logContainer by lazy { findViewById<LinearLayout>(R.id.editorXLogContainer) }
    private val start by lazy { findViewById<MaterialButton>(R.id.editorXStart) }
    private val select by lazy { findViewById<MaterialButton>(R.id.editorXSelect) }
    private val copyTerminal by lazy { findViewById<MaterialButton>(R.id.editorXCopyTerminal) }
    private val pms by lazy { findViewById<MaterialSwitch>(R.id.editorXPms) }
    private val io by lazy { findViewById<MaterialSwitch>(R.id.editorXIo) }
    private val svc by lazy { findViewById<MaterialSwitch>(R.id.editorXSvc) }
    private val levels by lazy { findViewById<RadioGroup>(R.id.editorXLevels) }
    private val terminalLines = mutableListOf<String>()
    @Volatile private var editorXRunning = false
    private var lastRenderedLogAt = 0L
    private var patchStartedAt = 0L
    private var exitWarning: android.app.AlertDialog? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { importApk(it) }
    }

    override fun attachBaseContext(newBase: Context) {
        val code = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE)
            .getString("lang", "ar") ?: "ar"
        val locale = java.util.Locale(code)
        java.util.Locale.setDefault(locale)
        val config = android.content.res.Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor_x)
        terminal.setBackgroundColor(Color.rgb(8, 12, 8))
        toolbar.alpha = 0f
        toolbar.translationY = -18f
        toolbar.animate().alpha(1f).translationY(0f).setDuration(420L).start()
        toolbar.setNavigationOnClickListener { requestExit() }
        select.setOnClickListener { picker.launch("*/*") }
        start.setOnClickListener { startPatch() }
        copyTerminal.setOnClickListener {
            getSystemService(ClipboardManager::class.java).setPrimaryClip(
                ClipData.newPlainText("Editor X Terminal", terminalLines.joinToString("\n"))
            )
            Toast.makeText(this, getString(R.string.copied), Toast.LENGTH_SHORT).show()
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = requestExit()
        })
        observeState()
    }

    private fun importApk(uri: Uri) {
        try {
            val originalName = queryDisplayName(uri)
            val extension = originalName.substringAfterLast('.', "apk").lowercase()
            require(extension in setOf("apk", "apks", "xapk", "apkm")) {
                getString(R.string.editor_choose_type)
            }
            val name = "editor_x_${System.currentTimeMillis()}.$extension"
            val target = File(cacheDir, name)
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { getString(R.string.file_open_failed) }
                target.outputStream().use { output -> input.copyTo(output) }
            }
            require(target.length() >= 4) { getString(R.string.file_empty) }
            target.inputStream().use { stream ->
                val header = ByteArray(4)
                require(stream.read(header) == 4 && header[0] == 'P'.code.toByte() && header[1] == 'K'.code.toByte()) {
                    getString(R.string.invalid_android_archive)
                }
            }
            viewModel.selectApk(target)
            fileName.text = getString(R.string.editor_file_selected, target.name, viewModel.humanBytes(target.length()))
            appendTerminal(getString(R.string.editor_copied_input, target.name))
            // لا نستخدم Snackbar هنا لأن بعض إصدارات Material القديمة تفشل
            // في تضخيم mtrl_layout_snackbar وتحوّل نجاح القراءة إلى رسالة خطأ.
            Toast.makeText(this, getString(R.string.selected_success, extension.uppercase()), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            appendTerminal("[ERROR] فشل قراءة الملف: ${e.message}")
            Toast.makeText(this, getString(R.string.read_apk_failed, e.message), Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index) ?: "input.apk"
            }
        }
        return uri.lastPathSegment ?: "input.apk"
    }

    private fun startPatch() {
        val state = viewModel.state.value
        if (state.selectedApk == null) {
            Toast.makeText(this, getString(R.string.choose_apk_first), Toast.LENGTH_SHORT).show()
            return
        }
        appendTerminal(getString(R.string.editor_started))
        val pmsEnabled = pms.isChecked
        val ioEnabled = io.isChecked
        val svcEnabled = svc.isChecked
        val selectedLevel = when (levels.checkedRadioButtonId) {
            R.id.editorXLevel1 -> 1
            R.id.editorXLevel2 -> 2
            R.id.editorXLevel3 -> 3
            else -> 4
        }
        start.isEnabled = false
        editorXRunning = true
        patchStartedAt = System.currentTimeMillis()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        exitWarning = android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.editing_title))
            .setMessage(getString(R.string.editing_message))
            .setCancelable(false)
            .setPositiveButton(getString(R.string.wait_button), null)
            .create()
            .also { it.show() }
        status.text = getString(R.string.editor_processing)
        appendTerminal("[CONFIG] PMS=${if (pmsEnabled) "ON" else "OFF"}, IO=${if (ioEnabled) "ON" else "OFF"}, SVC=${if (svcEnabled) "ON" else "OFF"}")
        val input = state.selectedApk
        lifecycleScope.launch(Dispatchers.IO) {
            val result = SrPatchXRunner.run(
                context = this@EditorXActivity,
                input = input,
                level = selectedLevel,
                pathRedirection = svcEnabled || ioEnabled,
                onStep = { message, percent ->
                    runOnUiThread {
                        appendTerminal(message)
                        status.text = if (percent in 1..99) {
                            getString(R.string.eta, formatEta(percent)).let { "$message\n$it" }
                        } else message
                        progress.progress = percent.coerceIn(0, 100)
                    }
                }
            )
            withContext(Dispatchers.Main) {
                editorXRunning = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                exitWarning?.dismiss()
                exitWarning = null
                start.isEnabled = true
                if (result.output != null) {
                    progress.progress = 100
                    status.text = getString(R.string.editor_complete, result.output.absolutePath)
                } else {
                    status.text = getString(R.string.editor_failed, result.error)
                }
            }
        }
    }

    private fun formatEta(percent: Int): String {
        if (patchStartedAt == 0L || percent <= 0) return getString(R.string.calculating)
        val elapsed = System.currentTimeMillis() - patchStartedAt
        val remaining = ((elapsed * (100 - percent).toLong()) / percent).coerceAtLeast(0L)
        val seconds = (remaining / 1000L).coerceAtLeast(1L)
        return if (seconds < 60) getString(R.string.seconds, seconds) else getString(R.string.minutes_seconds, seconds / 60, seconds % 60)
    }

    private fun requestExit() {
        if (!editorXRunning) {
            finish()
            return
        }
        Toast.makeText(this, getString(R.string.exit_processing), Toast.LENGTH_LONG).show()
        exitWarning?.show()
    }

    private fun appendTerminal(message: String) {
        terminalLines += "[${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}] $message"
        if (terminalLines.size > 10000) terminalLines.removeAt(0)
        val now = System.currentTimeMillis()
        val isCopyProgress = message.startsWith("Copied [") || message.startsWith("Skipped:")
        if (isCopyProgress && now - lastRenderedLogAt < 40L) return
        lastRenderedLogAt = now
        val line = TextView(this).apply {
            text = terminalLines.last()
            setTextColor(Color.rgb(210, 255, 210))
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, 4, 0, 4)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        logContainer.addView(line)
        if (logContainer.childCount > 500) logContainer.removeViewAt(0)
        terminal.post { terminal.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect { state ->
                    state.selectedApk?.let { fileName.text = getString(R.string.editor_file_selected, it.name, viewModel.humanBytes(it.length())) }
                    if (!editorXRunning) {
                        if (state.currentStep.isNotEmpty()) status.text = state.currentStep
                        progress.progress = (state.progress * 100).toInt().coerceIn(0, 100)
                    }
                }
            }
        }
    }
}
