package com.rktechno.apkpatcher.core

import java.io.File
import java.util.LinkedHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Patches split packages without flattening them into one APK.
 * Every APK component is signed with EditorTrue's common certificate so Android can install
 * the base and its feature/configuration splits in a single PackageInstaller session.
 */
internal object SplitBundlePatcher {
    private val bundleExtensions = setOf("apks", "apkm", "xapk")
    private val dexName = Regex("classes(\\d+)?\\.dex")
    private const val COPY_BUFFER = 1024 * 1024

    fun isBundleFile(file: File): Boolean = file.extension.lowercase() in bundleExtensions

    fun run(
        input: File,
        activeFlags: Set<String>,
        caCertificate: File?,
        customId: String?,
        onLog: (String) -> Unit,
    ): NativeToolPatcher.NativePatchResult {
        val startedAt = System.currentTimeMillis()
        var output: File? = null
        var workDir: File? = null
        val unsignedOutput = "-u" in activeFlags

        return try {
            require(input.isFile && input.length() > 0L) { "ملف الحزمة غير موجود أو فارغ" }
            val parent = input.absoluteFile.parentFile ?: File(".").absoluteFile
            workDir = File(parent, ".${input.nameWithoutExtension}_split_work_${System.nanoTime()}")
                .also { if (!it.mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد عمل مؤقت للحزمة") }

            val replacements = LinkedHashMap<String, File>()
            ZipFile(input).use { sourceZip ->
                val entries = sourceZip.entries().asSequence().toList()
                require(entries.isNotEmpty()) { "أرشيف الحزمة فارغ" }
                val names = HashSet<String>()
                entries.forEach { entry ->
                    require(names.add(entry.name)) { "الحزمة تحتوي على مسار ZIP مكرر: ${entry.name}" }
                    require(isSafeZipPath(entry.name)) { "مسار غير آمن داخل الحزمة: ${entry.name}" }
                }

                val apkEntries = entries.filter { !it.isDirectory && it.name.endsWith(".apk", ignoreCase = true) }
                require(apkEntries.isNotEmpty()) { "لم يتم العثور على ملفات APK داخل حزمة split" }

                val baseEntries = apkEntries.filter { isBaseEntryName(it.name) }.toMutableSet()
                if (baseEntries.isEmpty()) {
                    // Most APKS/XAPK/APKM exporters name the base explicitly. For uncommon
                    // archives, keep the first component as the base rather than dropping it.
                    baseEntries += apkEntries.first()
                    onLog("[SPLIT] لم يُعرف اسم base.apk؛ اعتُبر أول APK هو الملف الأساسي")
                }
                onLog(
                    if (unsignedOutput) {
                        "[SPLIT] وضع -u: إنشاء كل أجزاء APK بلا توقيع مع إبقاء بنية الحزمة"
                    } else {
                        "[SPLIT] حفظ بنية الحزمة: ${apkEntries.size} ملف APK، وتعديل الأجزاء البرمجية فقط"
                    },
                )

                apkEntries.forEachIndexed { index, entry ->
                    val component = File(workDir, "component_${index}.apk")
                    sourceZip.getInputStream(entry).buffered().use { inputStream ->
                        component.outputStream().buffered(COPY_BUFFER).use { outputStream ->
                            inputStream.copyTo(outputStream, COPY_BUFFER)
                        }
                    }
                    require(component.length() > 0L) { "ملف split فارغ: ${entry.name}" }
                    require(isValidApkZip(component)) { "ملف split تالف أو لا يحتوي AndroidManifest.xml: ${entry.name}" }

                    val isBase = entry in baseEntries
                    val hasDex = containsDex(component)
                    val patchThisComponent = isBase || hasDex || unsignedOutput
                    val writtenComponent = if (patchThisComponent) {
                        onLog("[SPLIT ${index + 1}/${apkEntries.size}] ${entry.name}: ${if (isBase) "base" else "feature/code split"}")
                        val result = NativeToolPatcher.runPatchComponent(
                            inputFile = component,
                            activeFlags = activeFlags,
                            caCertificate = caCertificate,
                            customId = customId,
                            applyManifestFix = isBase,
                            allowNoDex = true,
                            onLog = { line -> onLog("[SPLIT ${index + 1}/${apkEntries.size}] $line") },
                        )
                        if (!result.success || result.outputFile == null) {
                            throw IllegalStateException("فشل تعديل الجزء ${entry.name}: ${result.error ?: "خطأ غير معروف"}")
                        }
                        result.outputFile
                    } else {
                        onLog("[SPLIT ${index + 1}/${apkEntries.size}] ${entry.name}: جزء موارد/ABI بلا DEX؛ إعادة توقيعه للحفاظ على توافق التوقيع")
                        NativeToolPatcher.signFileOnly(component) { line ->
                            onLog("[SPLIT ${index + 1}/${apkEntries.size}] $line")
                        } ?: throw IllegalStateException("تعذّر إعادة توقيع الجزء ${entry.name}")
                    }
                    if (unsignedOutput && ApkSignatureInspector.isApkSignatureValid(writtenComponent)) {
                        throw IllegalStateException("بقي توقيع في الجزء ${entry.name} رغم تفعيل -u")
                    }
                    replacements[entry.name] = writtenComponent
                }

                output = uniqueOutputFile(input)
                ZipOutputStream(output.outputStream().buffered(COPY_BUFFER)).use { outputZip ->
                    outputZip.setLevel(0)
                    for (entry in entries) {
                        val writtenEntry = ZipEntry(entry.name).apply {
                            time = entry.time
                            comment = entry.comment
                        }
                        outputZip.putNextEntry(writtenEntry)
                        if (!entry.isDirectory) {
                            val replacement = replacements[entry.name]
                            if (replacement != null) {
                                replacement.inputStream().buffered(COPY_BUFFER).use { it.copyTo(outputZip, COPY_BUFFER) }
                            } else {
                                sourceZip.getInputStream(entry).buffered().use { it.copyTo(outputZip, COPY_BUFFER) }
                            }
                        }
                        outputZip.closeEntry()
                    }
                }
            }

            validateBundle(output!!, replacements.size)
            if (unsignedOutput) {
                onLog("[SPLIT] تم التحقق: كل مكوّنات APK بلا توقيع؛ سيعرض التثبيت خيار توقيعها جميعًا لاحقًا")
            }
            onLog("[SPLIT] اكتمل التعديل مع الاحتفاظ بجميع ملفات split والبيانات المرافقة: ${output!!.name}")
            NativeToolPatcher.NativePatchResult(
                success = true,
                outputFile = output,
                appliedFlags = activeFlags.toList(),
                elapsedMs = System.currentTimeMillis() - startedAt,
                error = null,
            )
        } catch (t: Throwable) {
            output?.delete()
            onLog("[SPLIT] فشل تجهيز الحزمة متعددة الأجزاء: ${t.message ?: t.javaClass.simpleName}")
            failure(startedAt, t.message ?: t.javaClass.simpleName)
        } finally {
            workDir?.deleteRecursively()
        }
    }

    /** Re-sign every APK component when an unsigned split bundle is sent to installation. */
    fun signBundleComponents(bundle: File, onLog: (String) -> Unit): File? =
        signBundleComponents(bundle, onLog) { component, logger ->
            NativeToolPatcher.signFileOnly(component, logger)
        }

    internal fun signBundleComponents(
        bundle: File,
        onLog: (String) -> Unit,
        signComponent: (File, (String) -> Unit) -> File?,
    ): File? {
        if (!isBundleFile(bundle)) return null
        val parent = bundle.absoluteFile.parentFile ?: File(".").absoluteFile
        val workDir = File(parent, ".${bundle.nameWithoutExtension}_sign_work_${System.nanoTime()}")
        var output: File? = null
        var componentCount = 0
        return try {
            require(workDir.mkdirs()) { "تعذر إنشاء مساحة عمل لتوقيع الحزمة" }
            ZipFile(bundle).use { sourceZip ->
                val entries = sourceZip.entries().asSequence().toList()
                entries.forEach { entry ->
                    require(isSafeZipPath(entry.name)) { "مسار غير آمن داخل الحزمة: ${entry.name}" }
                }
                val apkEntries = entries.filter { !it.isDirectory && it.name.endsWith(".apk", ignoreCase = true) }
                require(apkEntries.isNotEmpty()) { "لم يتم العثور على ملفات APK داخل الحزمة" }
                componentCount = apkEntries.size

                val replacements = LinkedHashMap<String, File>()
                apkEntries.forEachIndexed { index, entry ->
                    val component = File(workDir, "component_$index.apk")
                    sourceZip.getInputStream(entry).buffered().use { input ->
                        component.outputStream().buffered(COPY_BUFFER).use { out -> input.copyTo(out, COPY_BUFFER) }
                    }
                    require(component.length() > 0L) { "ملف APK فارغ داخل الحزمة: ${entry.name}" }
                    replacements[entry.name] = signComponent(component) { line ->
                        onLog("[SIGN ${index + 1}/${apkEntries.size}] ${entry.name}: $line")
                    } ?: throw IllegalStateException("تعذر توقيع الجزء ${entry.name}")
                }

                val outputFile = uniqueOutputFile(bundle, "_Signed")
                output = outputFile
                ZipOutputStream(outputFile.outputStream().buffered(COPY_BUFFER)).use { outputZip ->
                    outputZip.setLevel(0)
                    entries.forEach { entry ->
                        val rewritten = ZipEntry(entry.name).apply {
                            time = entry.time
                            comment = entry.comment
                        }
                        outputZip.putNextEntry(rewritten)
                        if (!entry.isDirectory) {
                            val replacement = replacements[entry.name]
                            if (replacement != null) {
                                replacement.inputStream().buffered(COPY_BUFFER).use { it.copyTo(outputZip, COPY_BUFFER) }
                            } else {
                                sourceZip.getInputStream(entry).buffered().use { it.copyTo(outputZip, COPY_BUFFER) }
                            }
                        }
                        outputZip.closeEntry()
                    }
                }
            }
            val signedBundle = output ?: throw IllegalStateException("لم يتم إنشاء ملف الحزمة الموقعة")
            validateBundle(signedBundle, componentCount)
            onLog("[SIGN] تم توقيع كل الأجزاء وحفظ بنية الحزمة: ${signedBundle.name}")
            signedBundle
        } catch (error: Throwable) {
            output?.delete()
            onLog("[SIGN] فشل توقيع الحزمة: ${error.message ?: error.javaClass.simpleName}")
            null
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun containsDex(apk: File): Boolean = ZipFile(apk).use { zip ->
        zip.entries().asSequence().any { !it.isDirectory && dexName.matches(it.name) }
    }

    private fun isValidApkZip(apk: File): Boolean = runCatching {
        ZipFile(apk).use { zip -> zip.getEntry("AndroidManifest.xml") != null }
    }.getOrDefault(false)

    private fun isBaseEntryName(path: String): Boolean {
        val name = path.substringAfterLast('/').lowercase()
        return name == "base.apk" || name.startsWith("base-") || name.startsWith("base_")
    }

    private fun isSafeZipPath(path: String): Boolean {
        val normalized = path.replace('\\', '/')
        return normalized.isNotBlank() && !normalized.startsWith('/') &&
            normalized.split('/').none { it == ".." || it == "." }
    }

    private fun uniqueOutputFile(input: File, suffix: String = "_Patched"): File {
        val parent = input.absoluteFile.parentFile ?: File(".").absoluteFile
        val extension = input.extension.lowercase()
        val base = input.nameWithoutExtension
        var candidate = File(parent, "${base}${suffix}.$extension")
        var index = 1
        while (candidate.exists()) {
            candidate = File(parent, "${base}${suffix}($index).$extension")
            index++
        }
        return candidate
    }

    private fun validateBundle(file: File, expectedApkCount: Int) {
        require(file.isFile && file.length() > 0L) { "لم يتم إنشاء ملف الحزمة الناتج" }
        ZipFile(file).use { zip ->
            val apkEntries = zip.entries().asSequence()
                .filter { !it.isDirectory && it.name.endsWith(".apk", ignoreCase = true) }
                .toList()
            require(apkEntries.size == expectedApkCount && apkEntries.isNotEmpty()) {
                "تغيّر عدد ملفات APK داخل الحزمة أثناء إعادة بنائها"
            }
            apkEntries.forEach { entry ->
                require(entry.size > 0L) { "ملف split الناتج فارغ: ${entry.name}" }
            }
        }
    }

    private fun failure(startedAt: Long, message: String) =
        NativeToolPatcher.NativePatchResult(
            success = false,
            outputFile = null,
            appliedFlags = emptyList(),
            elapsedMs = System.currentTimeMillis() - startedAt,
            error = message,
        )
}
