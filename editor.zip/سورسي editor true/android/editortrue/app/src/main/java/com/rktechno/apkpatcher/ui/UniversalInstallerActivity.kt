package com.rktechno.apkpatcher.ui

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.button.MaterialButton
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipFile

/**
 * Universal Installer المدمج داخل Editor True.
 * يستخدم جلسة PackageInstaller واحدة حتى تُثبت APKS/XAPK/APKM بكل أجزائها
 * بدل فتح نافذة النظام لملف APK واحد فقط.
 */
class UniversalInstallerActivity : AppCompatActivity() {
    private var selectedFile: File? = null
    private lateinit var selectedLabel: TextView
    private lateinit var installButton: MaterialButton
    private val resultAction = "com.rktechno.apkpatcher.INSTALL_RESULT_${System.identityHashCode(this)}"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) { }
            val file = copyUriToCache(uri)
            if (file != null) setSelectedFile(file) else showError("تعذر نسخ الملف إلى مساحة التثبيت")
        }
    }

    private val installResultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
            val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE).orEmpty()
            if (status == PackageInstaller.STATUS_SUCCESS) {
                Toast.makeText(context, "تم تثبيت التطبيق بنجاح", Toast.LENGTH_LONG).show()
                statusLabel("تم التثبيت بنجاح")
            } else {
                showInstallFailure(status, message)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Universal Installer"
        setContentView(buildContent())
        val incoming = intent.getStringExtra(EXTRA_FILE_PATH)?.let { File(it) }
            ?: intent.data?.let { copyUriToCache(it) }
        if (incoming != null && incoming.exists()) setSelectedFile(incoming)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(resultAction)
        ContextCompat.registerReceiver(this, installResultReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        runCatching { unregisterReceiver(installResultReceiver) }
        super.onStop()
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(0xFF11100F.toInt())
        }
        val title = TextView(this).apply {
            text = "Universal Installer"
            textSize = 25f
            setTextColor(0xFFFFD277.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val subtitle = TextView(this).apply {
            text = "تثبيت التطبيقات المعدلة والحزم المقسّمة بأمان"
            textSize = 14f
            setTextColor(0xFFDDD6C8.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(6), 0, dp(18))
        }
        selectedLabel = TextView(this).apply {
            text = "لم يتم اختيار ملف\nيدعم APK • APKS • XAPK • APKM"
            textSize = 15f
            setTextColor(0xFFEDE7DA.toInt())
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(0xFF26221C.toInt())
        }
        val chooseButton = MaterialButton(this).apply {
            text = "اختيار ملف تثبيت"
            setOnClickListener { picker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "application/zip", "*/*")) }
        }
        installButton = MaterialButton(this).apply {
            text = "تثبيت الآن"
            isEnabled = false
            setOnClickListener { selectedFile?.let { installPackage(it) } }
        }
        val diagnostic = MaterialButton(this).apply {
            text = "فحص التوافق قبل التثبيت"
            setOnClickListener { selectedFile?.let { showCompatibility(it) } ?: showError("اختر ملفًا أولاً") }
        }
        root.addView(title, lp())
        root.addView(subtitle, lp())
        root.addView(selectedLabel, lp(0, 8, 0, 8))
        root.addView(chooseButton, lp())
        root.addView(installButton, lp())
        root.addView(diagnostic, lp())
        val note = TextView(this).apply {
            text = "المثبت يرسل كل أجزاء APKS/XAPK/APKM في جلسة واحدة. إذا ظهر خطأ عدم توافق سيعرض سبب المشكلة والمعمارية المطلوبة بدل رسالة عامة."
            textSize = 12f
            setTextColor(0xFFBDB5A8.toInt())
            setPadding(dp(4), dp(18), dp(4), 0)
        }
        root.addView(note, lp())
        return ScrollView(this).apply { addView(root) }
    }

    private fun setSelectedFile(file: File) {
        selectedFile = file
        selectedLabel.text = "الملف المحدد: ${file.name}\nالحجم: ${humanBytes(file.length())}"
        installButton.isEnabled = isSupported(file)
    }

    private fun installPackage(file: File) {
        if (!isSupported(file)) {
            showError("الصيغة غير مدعومة. اختر APK أو APKS أو XAPK أو APKM")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("إذن التثبيت مطلوب")
                .setMessage("اسمح لـ EDITOR TRUE بالتثبيت من هذا المصدر ثم اضغط تثبيت مرة أخرى.")
                .setPositiveButton("فتح الإعدادات") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("إلغاء", null)
                .show()
            return
        }
        installButton.isEnabled = false
        statusLabel("جاري تجهيز جلسة التثبيت…")
        Thread {
            try {
                val installer = packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
                    setSize(estimateInstallSize(file))
                }
                val sessionId = installer.createSession(params)
                installer.openSession(sessionId).use { session ->
                    writePackageParts(session, file)
                    val callback = Intent(resultAction).setPackage(packageName)
                    val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                        if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
                    val pending = PendingIntent.getBroadcast(this, sessionId, callback, pendingFlags)
                    session.commit(pending.intentSender)
                }
                runOnUiThread { statusLabel("تم إرسال الحزمة للنظام، انتظر النتيجة…") }
            } catch (t: Throwable) {
                runOnUiThread {
                    installButton.isEnabled = true
                    showError("تعذر إنشاء جلسة التثبيت: ${t.message ?: "خطأ غير معروف"}")
                }
            }
        }.start()
    }

    private fun writePackageParts(session: PackageInstaller.Session, file: File) {
        if (file.extension.lowercase(Locale.US) == "apk") {
            FileInputStream(file).use { input -> session.openWrite(file.name, 0, file.length()).use { output -> input.copyTo(output); session.fsync(output) } }
            return
        }
        ZipFile(file).use { zip ->
            val entries = zip.entries().asSequence()
                .filter { !it.isDirectory && it.name.lowercase(Locale.US).endsWith(".apk") }
                .sortedWith(compareByDescending<java.util.zip.ZipEntry> { it.name.substringAfterLast('/').equals("base.apk", true) }.thenBy { it.name })
                .toList()
            if (entries.isEmpty()) throw IllegalArgumentException("لم يتم العثور على ملفات APK داخل الحزمة")
            entries.forEachIndexed { index, entry ->
                val name = entry.name.substringAfterLast('/').ifBlank { "part_$index.apk" }
                zip.getInputStream(entry).use { input -> session.openWrite(name, 0, entry.size).use { output -> input.copyTo(output); session.fsync(output) } }
            }
        }
    }

    private fun showCompatibility(file: File) {
        Thread {
            val abis = linkedSetOf<String>()
            try {
                if (file.extension.lowercase(Locale.US) == "apk") collectAbis(ZipFile(file), abis)
                else ZipFile(file).use { zip -> zip.entries().asSequence().filter { it.name.endsWith(".apk", true) }.forEach { entry ->
                    val temp = File(cacheDir, "compat_${System.nanoTime()}.apk")
                    zip.getInputStream(entry).use { input -> temp.outputStream().use { input.copyTo(it) } }
                    runCatching { ZipFile(temp).use { nested -> collectAbis(nested, abis) } }
                    temp.delete()
                } }
            } catch (_: Throwable) { }
            val device = Build.SUPPORTED_ABIS.joinToString(", ")
            val result = if (abis.isEmpty()) "لا توجد مكتبات Native؛ التطبيق يعمل على أي معمارية غالبًا." else "معمارية الملف: ${abis.joinToString(", ")}\nمعمارية الجهاز: $device\n${if (abis.any { abiMatches(it) }) "متوافق مبدئيًا" else "غير متوافق: اختر نسخة بمعمارية الجهاز"}"
            runOnUiThread { showError(result) }
        }.start()
    }

    private fun collectAbis(zip: ZipFile, out: MutableSet<String>) {
        zip.entries().asSequence().filter { it.name.startsWith("lib/") }.forEach { entry -> entry.name.split('/').getOrNull(1)?.let(out::add) }
    }

    private fun abiMatches(abi: String): Boolean {
        val a = abi.lowercase(Locale.US).replace('-', '_')
        return Build.SUPPORTED_ABIS.any { device ->
            val d = device.lowercase(Locale.US).replace('-', '_')
            a == d || (a == "armeabi_v7a" && d == "armeabi_v7a") || (a == "arm64_v8a" && d == "arm64_v8a")
        }
    }

    private fun showInstallFailure(status: Int, message: String) {
        installButton.isEnabled = true
        val reason = when (status) {
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "عدم توافق: غالبًا معمارية Native غير مناسبة أو حزمة Split ناقصة."
            PackageInstaller.STATUS_FAILURE_CONFLICT -> if (message.contains("VERSION", true) || message.contains("DOWNGRADE", true)) "الإصدار المعدل أقدم من الإصدار المثبت. احذف الإصدار القديم أو استخدم نسخة أحدث." else "تعارض توقيع أو تعارض مع نسخة مثبتة من نفس الحزمة."
            PackageInstaller.STATUS_FAILURE_INVALID -> "الحزمة غير صالحة أو توقيعها/Manifestها تالف."
            PackageInstaller.STATUS_FAILURE_BLOCKED -> "التثبيت محظور من إعدادات الجهاز أو سياسة النظام."
            else -> "فشل التثبيت."
        }
        showError("$reason\n\nتفاصيل النظام: ${message.ifBlank { "غير متوفرة" }}")
    }

    private fun copyUriToCache(uri: Uri): File? = try {
        val name = getDisplayName(uri) ?: "package_${System.currentTimeMillis()}.apk"
        val file = File(cacheDir, "installer_${System.currentTimeMillis()}_${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
        contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { input.copyTo(it) } }
        file.takeIf { it.exists() && it.length() > 0 }
    } catch (_: Throwable) { null }

    private fun getDisplayName(uri: Uri): String? = contentResolver.query(uri, arrayOf("_display_name"), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    private fun resolveInputFile(): File? = selectedFile
    private fun isSupported(file: File) = file.extension.lowercase(Locale.US) in setOf("apk", "apks", "xapk", "apkm", "zip")
    private fun estimateInstallSize(file: File): Long = if (file.extension.equals("apk", true)) file.length() else file.length() * 2
    private fun statusLabel(text: String) { runOnUiThread { selectedLabel.text = text } }
    private fun showError(text: String) { runOnUiThread { MaterialAlertDialogBuilder(this).setTitle("Universal Installer").setMessage(text).setPositiveButton("حسنًا", null).show() } }
    private fun humanBytes(bytes: Long): String { if (bytes < 1024) return "$bytes B"; val units = arrayOf("KB", "MB", "GB"); var value = bytes.toDouble(); var i = -1; do { value /= 1024; i++ } while (value >= 1024 && i < units.lastIndex); return String.format(Locale.US, "%.1f %s", value, units[i]) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun lp(l: Int = 0, t: Int = 6, r: Int = 0, b: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    companion object { const val EXTRA_FILE_PATH = "extra_file_path" }
}
