package com.rktechno.apkpatcher.core

import app.pwhs.core.util.EditorTrueStorage

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.rktechno.apkpatcher.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * خدمة الخلفية التي تنفذ معالجة APK بالكامل حتى لو خرج المستخدم من التطبيق.
 *
 * - تعرض إشعار تقدم دائم (foreground service)
 * - تحفظ الناتج في مجلد APKPatcher داخل الذاكرة الداخلية
 * - ترسل النتائج والسجلات لحظياً عبر Broadcast إلى MainActivity
 */
class PatchService : Service() {

    companion object {
        const val CHANNEL_ID = "patch_channel"
        const val ACTION_RESULT = "com.rktechno.apkpatcher.ACTION_PATCH_RESULT"
        const val ACTION_CANCEL = "com.rktechno.apkpatcher.ACTION_PATCH_CANCEL"
        const val ACTION_LOG = "com.rktechno.apkpatcher.ACTION_LOG"
        const val EXTRA_SUCCESS = "extra_success"
        const val EXTRA_OUTPUT_PATH = "extra_output_path"
        const val EXTRA_ERROR = "extra_error"
        const val EXTRA_APK_NAME = "extra_apk_name"
        const val EXTRA_FLAGS = "extra_flags"
        const val EXTRA_LOG_MSG = "extra_log_msg"
        const val EXTRA_LOG_BATCH = "extra_log_batch"
        const val EXTRA_PROGRESS = "extra_progress"
        const val EXTRA_ELAPSED = "extra_elapsed"

        // مفاتيح الإدخال
        const val INPUT_PATH = "input_path"
        const val INPUT_FLAGS = "input_flags"      // ArrayList<String>
        const val CA_CERT_PATH = "ca_cert_path"
        const val CUSTOM_ID = "custom_id"

        private const val NOTIF_ID = 4521
    }

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val logBuffer = mutableListOf<String>()
    private val cancelRequested = AtomicBoolean(false)
    @Volatile private var workerThread: Thread? = null
    private var processingWakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquireProcessingWakeLock() {
        if (processingWakeLock?.isHeld == true) return
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        processingWakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EditorTrue:Processing").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseProcessingWakeLock() {
        try {
            processingWakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {}
        processingWakeLock = null
    }

    override fun onDestroy() {
        releaseProcessingWakeLock()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            intent ?: return START_NOT_STICKY
            if (intent.action == ACTION_CANCEL) {
                cancelRequested.set(true)
                workerThread?.interrupt()
                updateNotification("Editor True", "جاري إيقاف العملية…", 0f)
                return START_NOT_STICKY
            }
            cancelRequested.set(false)
            acquireProcessingWakeLock()
            val inputPath = intent.getStringExtra(INPUT_PATH) ?: return START_NOT_STICKY
            val activeFlags = (intent.getStringArrayListExtra(INPUT_FLAGS) ?: arrayListOf())
            val caCertPath = intent.getStringExtra(CA_CERT_PATH)
            val customId = intent.getStringExtra(CUSTOM_ID)
            val batchPaths = intent.getStringArrayListExtra("batch_paths")?.map { File(it) }?.filter { it.exists() } ?: emptyList()
            if (batchPaths.size > 1) {
                getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                    .putBoolean("is_processing", true)
                    .putBoolean("saved_result_success", false)
                    .putString("saved_result_error", "")
                    .putString("last_step", "بدء معالجة دفعة من ${batchPaths.size} تطبيقات")
                    .apply()
                startForeground(NOTIF_ID, buildNotification("دفعة APK", "بدء ${batchPaths.size} تطبيقات…", 0f))
                scope.launch { runBatch(batchPaths, activeFlags.toSet(), caCertPath, customId) }
                return START_NOT_STICKY
            }

            val inputFile = File(inputPath)
            val apkName = inputFile.name
            getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                .putString("last_apk_path", inputPath)
                .putString("saved_flags", activeFlags.joinToString("|||"))
                .putBoolean("is_processing", true)
                .putFloat("last_progress", 0f)
                .putString("last_step", "بدء المعالجة: $apkName")
                .apply()

            try {
                startForeground(NOTIF_ID, buildNotification(apkName, "بدء المعالجة…", 0.05f))
            } catch (t: Throwable) {
                android.util.Log.e("PatchService", "فشل بدء الإشعار الأمامي", t)
            }

            scope.launch {
                workerThread = Thread.currentThread()
                try {
                    // لا نفرض GC هنا؛ إيقاف المعالج قسرًا يبطئ بدء الملفات الكبيرة.
                    // NativeToolPatcher يجري فحص الذاكرة قبل المراحل الثقيلة عند الحاجة.
                    logBuffer.clear()
                    val caCert = caCertPath?.let { File(it).takeIf { f -> f.exists() } }
                    var lastUiUpdate = 0L
                    val pendingLogs = ArrayList<String>(64)
                    val result = NativeToolPatcher.runPatch(
                        inputFile = inputFile,
                        activeFlags = activeFlags.toSet(),
                        caCertificate = caCert,
                        customId = customId?.takeIf { it.isNotBlank() },
                        onLog = { msg ->
                            if (cancelRequested.get()) throw IllegalStateException("تم إيقاف العملية بواسطة المستخدم")
                            logBuffer.add(msg)
                            // The UI receives every raw line; keep only a small service-side
                            // buffer so a long DEX run cannot retain the whole log in heap.
                            if (logBuffer.size > 256) logBuffer.removeAt(0)
                            val now = System.currentTimeMillis()
                            val terminal = msg.contains("COMPLETE") || msg.contains("ERROR") || msg.contains("failed", true)
                            pendingLogs.add(msg)
                            // نبث عددًا كبيرًا من السطور، لكن كدفعات؛ فلا ينتظر محرك الـJAR
                            // واجهة Android على كل سطر ولا تتراكم آلاف عمليات النسخ.
                            val p = estimateProgress(msg)
                            if (terminal || now - lastUiUpdate >= 50L || pendingLogs.size >= 64) {
                                lastUiUpdate = now
                                broadcastLogBatch(pendingLogs.toList(), p)
                                pendingLogs.clear()
                                updateNotification(apkName, msg, p)
                            }
                        }
                    )

                    if (cancelRequested.get()) {
                        result.outputFile?.delete()
                        throw IllegalStateException("تم إيقاف العملية بواسطة المستخدم")
                    }
                    if (result.success && result.outputFile != null) {
                        val saved = saveToAppFolder(result.outputFile, apkName)
                        result.outputFile.delete() // keep only the published copy under EditorTrue/
                        getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                            .putBoolean("is_processing", false)
                            .putBoolean("saved_result_success", true)
                            .putString("saved_result_path", saved.absolutePath)
                            .putString("saved_result_error", "")
                            .putLong("saved_result_elapsed", result.elapsedMs)
                            .putFloat("last_progress", 1f)
                            .putString("last_step", "✅ اكتملت المعالجة")
                            .apply()
                        broadcastResult(
                            success = true,
                            outputPath = saved.absolutePath,
                            error = null,
                            apkName = apkName,
                            elapsedMs = result.elapsedMs
                        )
                    } else {
                        getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                            .putBoolean("is_processing", false)
                            .putBoolean("saved_result_success", false)
                            .putString("saved_result_path", "")
                            .putString("saved_result_error", result.error ?: "فشلت المعالجة")
                            .putString("last_step", "❌ فشلت المعالجة")
                            .apply()
                        broadcastResult(
                            success = false,
                            outputPath = null,
                            error = result.error ?: "فشلت المعالجة دون رسالة خطأ",
                            apkName = apkName,
                            elapsedMs = result.elapsedMs
                        )
                    }
                } catch (e: Throwable) {
                    val message = if (cancelRequested.get()) "تم إيقاف العملية بواسطة المستخدم" else (e.message ?: "خطأ غير معروف في الخدمة")
                    getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                        .putBoolean("is_processing", false)
                        .putBoolean("saved_result_success", false)
                        .putString("saved_result_path", "")
                        .putString("saved_result_error", message)
                        .putString("last_step", "⏹ تم إيقاف العملية")
                        .apply()
                    broadcastResult(
                        success = false,
                        outputPath = null,
                        error = message,
                        apkName = apkName
                    )
                } finally {
                    workerThread = null
                    releaseProcessingWakeLock()
                    try {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                    } catch (_: Throwable) {}
                    stopSelf()
                }
            }
        } catch (t: Throwable) {
            android.util.Log.e("PatchService", "خطأ فادح في onStartCommand", t)
        }
        return START_REDELIVER_INTENT
    }

    private fun estimateProgress(msg: String): Float {
        val lower = msg.lowercase()
        return when {
            lower.contains("flags") || lower.contains(" -i ") || lower.contains(" -m ") -> 0.05f
            lower.contains("merging") || lower.contains("split") -> 0.15f
            lower.contains("loading apk") || lower.contains("analysis") -> 0.30f
            lower.contains("ssl") || lower.contains("network security") || lower.contains("flutter") -> 0.45f
            lower.contains("dex turbo") -> 0.60f
            lower.contains("patching dex") || lower.contains("processing dex") -> 0.64f
            lower.contains("building dex") || lower.contains("writing dex") -> 0.78f
            lower.contains("dex built") || lower.contains("dex complete") -> 0.83f
            lower.contains("scanning") || lower.contains("bytecode") -> 0.55f
            lower.contains("install") || lower.contains("manifest") -> 0.70f
            lower.contains("inject") || lower.contains("hook") -> 0.80f
            lower.contains("building") || lower.contains("output written") -> 0.88f
            lower.contains("توقيع") || lower.contains("sign") -> 0.95f
            lower.contains("complete") || lower.contains("completed") || lower.contains("اكتملت") -> 1.0f
            else -> -1f
        }
    }

    private fun broadcastLog(msg: String, progress: Float) {
        val intent = Intent(ACTION_LOG).apply {
            setPackage(packageName)
            putExtra(EXTRA_LOG_MSG, msg)
            if (progress >= 0f) putExtra(EXTRA_PROGRESS, progress)
        }
        sendBroadcast(intent)
    }

    private fun broadcastLogBatch(messages: List<String>, progress: Float) {
        if (messages.isEmpty()) return
        val intent = Intent(ACTION_LOG).apply {
            setPackage(packageName)
            putStringArrayListExtra(EXTRA_LOG_BATCH, ArrayList(messages))
            if (progress >= 0f) putExtra(EXTRA_PROGRESS, progress)
        }
        sendBroadcast(intent)
    }

    private suspend fun runBatch(files: List<File>, flags: Set<String>, certPath: String?, customId: String?) {
        var completed = 0
        var lastSaved: File? = null
        workerThread = Thread.currentThread()
        try {
            for (file in files) {
                val prefix = "[BATCH ${completed + 1}/${files.size}]"
                updateNotification("دفعة APK", "$prefix جاري تطبيق الباتشات: ${file.name}", completed.toFloat() / files.size)
                broadcastLog("$prefix START: ${file.name}", completed.toFloat() / files.size)
                val result = NativeToolPatcher.runPatch(file, flags, certPath?.let { File(it).takeIf { f -> f.exists() } }, customId?.takeIf { it.isNotBlank() }) { msg ->
                    if (cancelRequested.get()) throw IllegalStateException("تم إيقاف العملية بواسطة المستخدم")
                    broadcastLog("$prefix $msg", completed.toFloat() / files.size)
                }
                if (result.success && result.outputFile != null) {
                    lastSaved = saveToAppFolder(result.outputFile, file.name)
                    result.outputFile.delete() // keep only the published copy under EditorTrue/
                    completed++
                    broadcastLog("$prefix اكتمل: ${file.name}", completed.toFloat() / files.size)
                } else broadcastLog("$prefix فشل: ${result.error ?: "خطأ غير معروف"}", completed.toFloat() / files.size)
            }
            updateNotification("اكتملت دفعة APK", "تم إنهاء $completed من ${files.size} تطبيقات", 1f)
            broadcastLog("[BATCH] اكتملت الدفعة: $completed/${files.size}", 1f)
            getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                .putBoolean("is_processing", false)
                .putBoolean("saved_result_success", lastSaved != null)
                .putString("saved_result_path", lastSaved?.absolutePath ?: "")
                .putString("saved_result_error", if (completed == files.size) "" else "اكتملت الدفعة جزئيًا")
                .putString("last_step", "✅ اكتملت الدفعة: $completed/${files.size}")
                .putFloat("last_progress", 1f)
                .apply()
            broadcastResult(true, lastSaved?.absolutePath, null, "دفعة APK")
        } catch (t: Throwable) {
            updateNotification("فشلت دفعة APK", t.message ?: "خطأ غير معروف", completed.toFloat() / files.size)
            broadcastLog("[BATCH] خطأ: ${t.message}", completed.toFloat() / files.size)
            if (cancelRequested.get()) {
                broadcastResult(false, null, "تم إيقاف العملية بواسطة المستخدم", "دفعة APK")
            }
            getSharedPreferences("patcher_state", MODE_PRIVATE).edit()
                .putBoolean("is_processing", false)
                .putBoolean("saved_result_success", false)
                .putString("saved_result_path", "")
                .putString("saved_result_error", t.message ?: "فشلت الدفعة")
                .putString("last_step", if (cancelRequested.get()) "⏹ تم إيقاف الدفعة" else "❌ فشلت الدفعة")
                .apply()
        } finally {
            workerThread = null
            releaseProcessingWakeLock()
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    private fun saveToAppFolder(output: File, apkName: String): File {
        val base = apkName.removeSuffix(".apk")
            .removeSuffix(".apks")
            .removeSuffix(".xapk")
            .removeSuffix(".apkm")
        val editorTrueFolder = EditorTrueStorage.modifiedApks()
        if (!editorTrueFolder.exists() && !editorTrueFolder.mkdirs()) {
            throw java.io.IOException("تعذر إنشاء مجلد /storage/emulated/0/EditorTrue/Modified")
        }

        val outputExtension = output.extension.lowercase().takeIf { it in setOf("apk", "apks", "apkm", "xapk") } ?: "apk"
        var fileName = "${base}_Patched.$outputExtension"
        var dest = File(editorTrueFolder, fileName)
        var counter = 1
        while (dest.exists()) {
            fileName = "${base}_Patched($counter).$outputExtension"
            dest = File(editorTrueFolder, fileName)
            counter++
        }
        val temporary = File(editorTrueFolder, ".$fileName.${System.nanoTime()}.tmp")
        try {
            output.inputStream().buffered(1024 * 1024).use { input ->
                temporary.outputStream().buffered(1024 * 1024).use { target ->
                    input.copyTo(target, 1024 * 1024)
                }
            }
            if (temporary.length() != output.length()) {
                throw java.io.IOException("حجم النسخة المحفوظة لا يطابق ملف التعديل")
            }
            if (!temporary.renameTo(dest)) {
                throw java.io.IOException("تعذر نقل الناتج المؤقت إلى مجلد Modified")
            }
            android.media.MediaScannerConnection.scanFile(
                this,
                arrayOf(dest.absolutePath),
                arrayOf(if (outputExtension == "apk") "application/vnd.android.package-archive" else "application/zip"),
                null,
            )
        } catch (e: Throwable) {
            temporary.delete()
            dest.takeIf { it.exists() && it.length() != output.length() }?.delete()
            android.util.Log.w("PatchService", "فشل الحفظ داخل /storage/emulated/0/EditorTrue/Modified: ${e.message}")
            throw java.io.IOException("تعذر الحفظ داخل /storage/emulated/0/EditorTrue/Modified: ${e.message}", e)
        }
        if (!dest.isFile || dest.length() != output.length() || dest.length() <= 0L) {
            throw java.io.IOException("لم يتم إنشاء الملف في /storage/emulated/0/EditorTrue/Modified")
        }
        return dest
    }

    private fun buildNotification(title: String, text: String, progress: Float): android.app.Notification {
        createChannel()
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("APK Patcher — $title")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification_small)
            .setOngoing(progress < 1f)
            .setOnlyAlertOnce(true)
            .setProgress(100, (progress * 100).toInt(), progress <= 0f)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        updateNotification(title, text, -1f)
    }

    private fun updateNotification(title: String, text: String, progress: Float) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(title, text, if (progress < 0f) 0.5f else progress))
    }

    private fun broadcastResult(
        success: Boolean,
        outputPath: String?,
        error: String?,
        apkName: String,
        elapsedMs: Long = 0L
    ) {
        val intent = Intent(ACTION_RESULT).apply {
            setPackage(packageName)
            putExtra(EXTRA_SUCCESS, success)
            outputPath?.let { putExtra(EXTRA_OUTPUT_PATH, it) }
            error?.let { putExtra(EXTRA_ERROR, it) }
            putExtra(EXTRA_APK_NAME, apkName)
            putExtra(EXTRA_ELAPSED, elapsedMs)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "معالجة APK",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "إشعار تقدم معالجة APK في الخلفية"
                }
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .createNotificationChannel(channel)
            } catch (_: Throwable) {}
        }
    }
}
