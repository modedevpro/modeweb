package com.rktechno.apkpatcher.core

import java.util.Locale

/**
 * تعريف الفلاجات المتاحة في أداة APKPatcher.
 * هذا الملف هو الترجمة المباشرة لـ ALL_FLAGS من بوت تيليجرام الأصلي.
 * يدعم اللغتين العربية والإنجليزية حسب لغة التطبيق الحالية.
 *
 * -ssl: تجاوز فحص شهادات SSL
 * -f:   مسار Flutter SSL
 * -fix: إصلاح مشاكل التثبيت
 * -rmss: تجاوز منع لقطات الشاشة
 * -v:  تجاوز كشف الـ VPN
 * -rmusb: تجاوز كشف تصحيح USB
 * -rmads: إزالة الإعلانات
 * -id:  تجاوز تسجيل الدخول لجهاز واحد
 * -paid: فتح المحتوى المدفوع (معاينة)
 * -pine: حقن Pine Hook (Abhi Loader)
 * -pine2: حقن Pine Hook (My Loader)
 * -pkg: تجاوز كشف اسم الحزمة
 * -a:  حقن سجلات الخوارزميات (Logs)
 * -u:  الحفاظ على الملف بدون توقيع
 * -tg: باتش Telegram / Plus
 */
object PatcherFlags {

    data class FlagDef(
        val key: String,
        val title: String,
        val description: String,
        val titleEn: String,
        val descriptionEn: String,
        val icon: String,
        val enabledByDefault: Boolean = false
    ) {
        /**
         * يرجع الاسم حسب لغة التطبيق الحالية.
         * اللغة الإنجليزية تُطبَّق فقط إذا كانت محفوظة في إعدادات التطبيق
         * أو كانت لغة الجهاز الافتراضية ليست عربية.
         */
        fun localizedTitle(prefsLang: String? = null): String {
            return if (isEnglishActive(prefsLang)) titleEn else title
        }

        fun localizedDescription(prefsLang: String? = null): String {
            return if (isEnglishActive(prefsLang)) descriptionEn else description
        }

        companion object {
            fun isEnglishActive(prefsLang: String? = null): Boolean {
                // أولوية: اللغة المحفوظة في إعدادات التطبيق، ثم لغة الجهاز
                return when {
                    prefsLang != null -> prefsLang == "en"
                    Locale.getDefault().language == "ar" -> false
                    else -> true
                }
            }
        }
    }

    val ALL_FLAGS: List<FlagDef> = listOf(
        FlagDef(
            "-ssl",
            "تجاوز فحص SSL",
            "تجاوز فحص شهادات SSL / SSL Pinning عبر تعديل NetworkSecurityConfig و smali",
            "SSL Pinning Bypass",
            "Bypass SSL Certificate / SSL Pinning checks via NetworkSecurityConfig and smali modification",
            "🔓",
            false
        ),
        FlagDef(
            "-f",
            "تجاوز SSL لتطبيقات Flutter",
            "تفعيل مسار Flutter SSL مع تجاوز فحص الشهادات وSSL Pinning",
            "Flutter SSL Bypass",
            "Enable the Flutter SSL path together with certificate and SSL Pinning bypass",
            "🦋",
            false
        ),
        FlagDef(
            "-fix",
            "إصلاح التثبيت",
            "إصلاح مشاكل التثبيت وإعادة التوقيع بـ V2/V3",
            "Install Fix",
            "Fix installation issues and re-sign with V2/V3 signature schemes",
            "🔧",
            false
        ),
        FlagDef(
            "-rmss",
            "منع لقطات الشاشة",
            "تجاوز قيد FLAG_SECURE ومنع لقطات الشاشة",
            "Screenshot Block Bypass",
            "Bypass FLAG_SECURE restriction and prevent screenshot blocking",
            "📸",
            false
        ),
        FlagDef(
            "-v",
            "تجاوز كشف VPN",
            "تجاوز كشف VPN والبروكسي (NetworkCapabilities / NetworkInterface)",
            "VPN Detection Bypass",
            "Bypass VPN and proxy detection (NetworkCapabilities / NetworkInterface)",
            "🌐",
            false
        ),
        FlagDef(
            "-rmusb",
            "كشف تصحيح USB",
            "تجاوز كشف وضع تصحيح USB (adb_enabled)",
            "USB Debugging Detection Bypass",
            "Bypass USB debugging mode detection (adb_enabled)",
            "🔌",
            false
        ),
        FlagDef(
            "-rmads",
            "إزالة الإعلانات",
            "إزالة وإلغاء إعلانات AdMob / Unity / AppLovin",
            "Remove Ads",
            "Remove and disable AdMob / Unity / AppLovin advertisements",
            "🚫",
            false
        ),
        FlagDef(
            "-id",
            "تسجيل دخول جهاز واحد",
            "تجاوز ربط تسجيل الدخول بجهاز واحد (Android ID Spoof)",
            "Single Device Login Bypass",
            "Bypass single-device login binding (Android ID Spoof)",
            "🆔",
            false
        ),
        FlagDef(
            "-paid",
            "المحتوى المدفوع",
            "فتح المحتوى المدفوع - وضع معاينة تجريبي فقط",
            "Premium Content Unlock",
            "Unlock paid content - preview / experimental mode only",
            "💎",
            false
        ),
        FlagDef(
            "-pine",
            "Pine Hook (Abhi)",
            "حقن Pine Hook باستخدام Abhi Loader (Xposed/LSP)",
            "Pine Hook (Abhi)",
            "Inject Pine Hook using Abhi Loader (Xposed/LSP)",
            "🧪",
            false
        ),
        FlagDef(
            "-pine2",
            "Pine Hook (My)",
            "حقن Pine Hook باستخدام My Loader",
            "Pine Hook (My)",
            "Inject Pine Hook using My Loader",
            "🧫",
            false
        ),

        FlagDef(
            "-shield",
            "تجاوز Google Play Protect",
            "منع اكتشاف التطبيق المعدل عبر خدمات فحص الحماية ومتجر جوجل",
            "Play Protect Shield Bypass",
            "Prevent modified app detection by Google Play Protect security scans",
            "🛡️",
            false
        ),
        FlagDef(
            "-pkg",
            "كشف اسم الحزمة",
            "تجاوز كشف اسم الحزمة في Dex و Manifest و Resources",
            "Package Name Detection Bypass",
            "Bypass package name detection in Dex, Manifest and Resources",
            "📦",
            false
        ),
        FlagDef(
            "-a",
            "سجلات الخوارزميات",
            "حقن سجلات AES / Algorithm Logs داخل التطبيق",
            "Algorithm Logs Injection",
            "Inject AES / Algorithm Logs inside the application",
            "📊",
            false
        ),
        FlagDef(
            "-u",
            "بدون توقيع",
            "الحفاظ على الملف الناتج بدون توقيع (غير موصى به)",
            "Keep Unsigned",
            "Keep the output file unsigned (not recommended)",
            "⚠️",
            false
        ),
        FlagDef(
            "-tg",
            "باتش تيليجرام",
            "باتش خاص بتطبيق Telegram / Plus",
            "Telegram / Plus Patch",
            "Special patch for Telegram / Plus applications",
            "✈️",
            false
        )

    )
}
