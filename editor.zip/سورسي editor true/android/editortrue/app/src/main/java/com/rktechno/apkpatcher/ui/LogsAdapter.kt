package com.rktechno.apkpatcher.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import com.rktechno.apkpatcher.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LogEntry(val message: String, val type: LogType = LogType.INFO)
enum class LogType { INFO, ERROR, SUCCESS, WARNING }

class LogsAdapter : RecyclerView.Adapter<LogsAdapter.ViewHolder>() {
    private val logs = mutableListOf<LogEntry>()

    fun addLog(message: String, type: LogType = LogType.INFO) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        // Keep the engine's original message; do not prepend a fake shell prompt.
        logs.add(LogEntry("$stamp $message", type))
        notifyItemInserted(logs.size - 1)
    }

    /** Add a batch in one adapter update; this avoids one layout pass per log line. */
    fun addLogs(messages: List<String>) {
        if (messages.isEmpty()) return
        val now = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val start = logs.size
        logs.addAll(messages.map { LogEntry("$now $it") })
        notifyItemRangeInserted(start, messages.size)
    }

    fun clear() {
        logs.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_log, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val log = logs[position]
        holder.tvLogMessage.text = log.message
        val color = when (log.type) {
            LogType.INFO -> Color.WHITE
            LogType.ERROR -> Color.RED
            LogType.SUCCESS -> Color.GREEN
            LogType.WARNING -> Color.YELLOW
        }
        holder.tvLogMessage.setTextColor(color)
    }

    override fun getItemCount() = logs.size

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val tvLogMessage: TextView = view.findViewById(R.id.tvLogMessage)
    }
}
