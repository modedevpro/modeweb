package com.rktechno.apkpatcher.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.rktechno.apkpatcher.R
import com.rktechno.apkpatcher.core.PatcherFlags

class FlagsAdapter(private val onToggle: (String) -> Unit) : RecyclerView.Adapter<FlagsAdapter.ViewHolder>() {
    private val flags = PatcherFlags.ALL_FLAGS
    private var activeFlags: Set<String> = emptySet()
    private var prefsLang: String? = null

    fun updateData(newActiveFlags: Set<String>, lang: String? = null) {
        activeFlags = newActiveFlags.toSet()
        prefsLang = lang
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_flag, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (position !in flags.indices) return
        val flag = flags[position]
        holder.tvIcon.text = flag.icon
        holder.tvFlagTitle.text = flag.localizedTitle(prefsLang)
        holder.tvFlagDesc.text = flag.localizedDescription(prefsLang)

        // إزالة المستمع القديم قبل تغيير isChecked حتى لا يؤدي reset إلى toggle أو استدعاء متكرر.
        holder.switchFlag.setOnCheckedChangeListener(null)
        holder.switchFlag.isChecked = activeFlags.contains(flag.key)
        holder.switchFlag.setOnCheckedChangeListener { _, isChecked ->
            val currentlyActive = activeFlags.contains(flag.key)
            if (isChecked != currentlyActive) onToggle(flag.key)
        }

        holder.itemView.setOnClickListener {
            holder.switchFlag.toggle()
        }
    }

    override fun getItemCount(): Int = flags.size

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val tvIcon: TextView = view.findViewById(R.id.tvIcon)
        val tvFlagTitle: TextView = view.findViewById(R.id.tvFlagTitle)
        val tvFlagDesc: TextView = view.findViewById(R.id.tvFlagDesc)
        val switchFlag: MaterialSwitch = view.findViewById(R.id.switchFlag)
    }
}
