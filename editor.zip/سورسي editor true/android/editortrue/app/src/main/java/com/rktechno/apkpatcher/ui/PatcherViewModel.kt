package com.rktechno.apkpatcher.ui

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.content.Intent
import com.rktechno.apkpatcher.core.NativeToolPatcher
import com.rktechno.apkpatcher.core.PatchService
import com.rktechno.apkpatcher.core.PatcherFlags
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * ViewModel يدير حالة المعالجة الكاملة.
 * يماثل المنطق الموجود في handle_callbacks و process_document من البوت:
 * - إدارة حالة الفلاجات (user_flags)
 * - إدارة المدخلات الخاصة (-c, -l) (user_paths)
 * - إدارة جلسة المعالجة (session_dir)
 */
class PatcherViewModel(application: android.app.Application) : AndroidViewModel(application) {

    private companion object {
        // الاحتفاظ بآخر جزء من السجل يمنع نسخ قوائم ضخمة مع كل سطر DEX.
        const val MAX_LIVE_LOGS = 2000
    }

    data class UiState(
        val selectedApk: File? = null,
        val apkName: String = "",
        val apkSize: Long = 0L,
        val activeFlags: Set<String> = emptySet(),
        val caCertificate: File? = null,
        val modulePath: String? = null,
        val isProcessing: Boolean = false,
        val progress: Float = 0f,
        val currentStep: String = "",
        val logs: List<String> = emptyList(),
        val result: ResultInfo? = null
    )

    data class ResultInfo(
        val success: Boolean,
        val outputFile: File?,
        val appliedFlags: List<String>,
        val appliedPatches: List<String>,
        val elapsedMs: Long,
        val errorMessage: String?
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        // مسح حالة الفلاجات القديمة المحفوظة من النسخ السابقة (التي كانت تفعل -ssl و -fix تلقائياً)
        // لضمان أن كل الباتشات تبدأ غير مفعلة ويفعلها المستخدم بنفسه
        try {
            application.getSharedPreferences("patcher_state", android.content.Context.MODE_PRIVATE)
                .edit()
                .remove("saved_flags")
                .remove("saved_active_flags")
                .remove("active_flags")
                .apply()
        } catch (_: Throwable) {}

        // استرجاع آخر ملف تم اختياره وحالة السجلات والتقدم لضمان عدم اختفائها أبداً
        val prefs = application.getSharedPreferences("patcher_state", android.content.Context.MODE_PRIVATE)
        val lastPath = prefs.getString("last_apk_path", null)
        val savedStep = prefs.getString("last_step", "جاهز للبدء")
        val savedLogsString = prefs.getString("last_logs", "")
        val logsList = if (!savedLogsString.isNullOrEmpty()) savedLogsString.split("|||") else listOf("📂 جاهز للاستخدام — اختر ملف APK للبدء")

        val isProc = prefs.getBoolean("is_processing", false)
        val lastProg = prefs.getFloat("last_progress", 0f)
        val savedResultSuccess = prefs.getBoolean("saved_result_success", false)
        val savedResultPath = prefs.getString("saved_result_path", null)
        val savedResultError = prefs.getString("saved_result_error", null)
        val savedResultElapsed = prefs.getLong("saved_result_elapsed", 0L)
        val savedFlags = prefs.getString("saved_flags", "")
            ?.split("|||")?.filter { it.isNotBlank() } ?: emptyList()
        val savedOutput = savedResultPath?.let { File(it).takeIf { file -> file.exists() } }
        val restoredResult = if (savedResultSuccess && savedOutput != null) {
            ResultInfo(true, savedOutput, savedFlags, savedFlags, savedResultElapsed, null)
        } else if (!savedResultSuccess && !savedResultError.isNullOrBlank() && !isProc) {
            ResultInfo(false, null, savedFlags, savedFlags, savedResultElapsed, savedResultError)
        } else null

        if (lastPath != null) {
            val f = File(lastPath)
            if (f.exists()) {
                _state.update {
                    it.copy(
                        selectedApk = f,
                        apkName = f.name,
                        apkSize = f.length(),
                        currentStep = savedStep ?: "",
                        logs = logsList,
                        isProcessing = isProc,
                        progress = if (restoredResult?.success == true) 1f else lastProg,
                        activeFlags = savedFlags.toSet(),
                        result = restoredResult
                    )
                }
            }
        }
    }

    private fun savePersistentState(step: String, logs: List<String>) {
        try {
            val prefs = getApplication<android.app.Application>().getSharedPreferences("patcher_state", android.content.Context.MODE_PRIVATE)
            prefs.edit()
                .putString("last_step", step)
                .putString("last_logs", logs.takeLast(100).joinToString("|||"))
                .putBoolean("is_processing", _state.value.isProcessing)
                .putFloat("last_progress", _state.value.progress)
                .apply()
        } catch (_: Throwable) {}
    }

    override fun onCleared() {
        super.onCleared()
        savePersistentState(_state.value.currentStep, _state.value.logs)
    }

    fun selectApk(file: File) {
        val prefs = getApplication<android.app.Application>().getSharedPreferences("patcher_state", android.content.Context.MODE_PRIVATE)
        prefs.edit()
            .putString("last_apk_path", file.absolutePath)
            .putBoolean("is_processing", _state.value.isProcessing)
            .putBoolean("saved_result_success", false)
            .putString("saved_result_path", "")
            .putString("saved_result_error", "")
            .putFloat("last_progress", 0f)
            .apply()

        _state.update {
            it.copy(
                selectedApk = file,
                apkName = file.name,
                apkSize = file.length(),
                isProcessing = it.isProcessing,
                progress = if (it.isProcessing) it.progress else 0f,
                currentStep = if (it.isProcessing) it.currentStep else "جاهز لمعالجة ${file.name}",
                result = null,
                logs = mutableListOf("[INPUT] Selected file: ${file.name}"),
            )
        }
    }

    fun toggleFlag(flag: String) {
        _state.update { current ->
            val newFlags = current.activeFlags.toMutableSet()
            if (flag in newFlags) newFlags.remove(flag) else newFlags.add(flag)
            current.copy(activeFlags = newFlags)
        }
    }

    fun resetFlags() {
        _state.update {
            it.copy(
                activeFlags = emptySet(),
                caCertificate = null,
                modulePath = null,
                result = null
            )
        }
    }

    fun setCaCertificate(file: File) {
        _state.update { it.copy(caCertificate = file) }
    }

    fun setModulePath(path: String) {
        _state.update { it.copy(modulePath = path) }
    }

    fun appendLog(msg: String) {
        _state.update { current ->
            val newLogs = (current.logs + msg).let { if (it.size > MAX_LIVE_LOGS) it.takeLast(MAX_LIVE_LOGS) else it }
            // لا نكتب SharedPreferences مع كل سطر أثناء معالجة APK كبير.
            if (newLogs.size % 10 == 0 || msg.contains("COMPLETE") || msg.contains("ERROR")) {
                savePersistentState(current.currentStep, newLogs)
            }
            current.copy(logs = newLogs)
        }
    }

    fun updateLiveLog(msg: String, progress: Float) {
        _state.update { current ->
            val newLogs = (current.logs + msg).let { if (it.size > MAX_LIVE_LOGS) it.takeLast(MAX_LIVE_LOGS) else it }
            if (newLogs.size % 10 == 0 || msg.contains("COMPLETE") || msg.contains("ERROR")) {
                savePersistentState(msg, newLogs)
            }
            current.copy(
                logs = newLogs,
                progress = if (progress >= 0f) progress else current.progress,
                currentStep = msg
            )
        }
    }

    fun updateLiveLogs(messages: List<String>, progress: Float) {
        if (messages.isEmpty()) return
        _state.update { current ->
            val newLogs = (current.logs + messages).let {
                if (it.size > MAX_LIVE_LOGS) it.takeLast(MAX_LIVE_LOGS) else it
            }
            val last = messages.last()
            current.copy(
                logs = newLogs,
                progress = if (progress >= 0f) progress else current.progress,
                currentStep = last
            )
        }
    }

    /**
     * بدء المعالجة في خدمة الخلفية (PatchService).
     * المعالجة تستمر حتى لو خرج المستخدم من التطبيق.
     */
    fun startPatching() {
        val s = _state.value
        val input = s.selectedApk ?: return
        if (s.isProcessing) return

        _state.update {
            it.copy(
                isProcessing = true, // منع تشغيل عمليتين كبيرتين بالتوازي لتجنب نفاد الذاكرة
                progress = 0f,
                currentStep = "⚙️ بدأت معالجة ${input.name}…",
                logs = listOf("[JAR] PROCESS START: ${input.name}"),
                result = null
            )
        }

        // الإطلاق عبر PatchService (Foreground Service) لتستمر المعالجة بالخلفية
        val ctx = getApplication<android.app.Application>()
        val serviceIntent = Intent(ctx, PatchService::class.java).apply {
            putExtra(PatchService.INPUT_PATH, input.absolutePath)
            putStringArrayListExtra(PatchService.INPUT_FLAGS, ArrayList(s.activeFlags))
            s.caCertificate?.absolutePath?.let { putExtra(PatchService.CA_CERT_PATH, it) }
            if ("-id" in s.activeFlags) s.modulePath?.let { putExtra(PatchService.CUSTOM_ID, it) }
            val batch = ctx.getSharedPreferences("patcher_batch", android.content.Context.MODE_PRIVATE)
                .getString("paths", "")?.split("|||")?.filter { it.isNotBlank() } ?: emptyList()
            if (batch.size > 1) putStringArrayListExtra("batch_paths", ArrayList(batch))
        }
        try {
            ctx.startForegroundService(serviceIntent)
        } catch (e: Exception) {
            appendLog("Service start failed: ${e.message}")
            _state.update { it.copy(isProcessing = false) }
        }
    }

    fun cancelPatching(force: Boolean = false) {
        if (!_state.value.isProcessing) return
        val ctx = getApplication<android.app.Application>()
        _state.update { it.copy(currentStep = if (force) "⏹ جارٍ الإيقاف القسري…" else "⏹ جارٍ إيقاف العملية…") }
        try {
            ctx.startService(Intent(ctx, PatchService::class.java).setAction(PatchService.ACTION_CANCEL))
        } catch (e: Throwable) {
            appendLog("[CANCEL] تعذر إرسال أمر الإيقاف: ${e.message}")
        }
    }

    fun signFileOnly(file: File) {
        viewModelScope.launch {
            _state.update { it.copy(isProcessing = true, currentStep = "✍️ جاري التوقيع السريع...") }
            val result = withContext(Dispatchers.IO) {
                NativeToolPatcher.signFileOnly(file) { msg ->
                    viewModelScope.launch { appendLog(msg) }
                }
            }
            _state.update { current ->
                current.copy(
                    isProcessing = false,
                    currentStep = if (result != null) "✅ تم التوقيع بنجاح" else "❌ فشل التوقيع",
                    result = if (result != null) ResultInfo(true, result, emptyList(), emptyList(), 0, null) else current.result
                )
            }
        }
    }

    /**
     * تُستدعى من BroadcastReceiver عند انتهاء الخدمة
     */
    fun patchFinished(
        success: Boolean,
        outputFile: File?,
        apkName: String,
        error: String? = null,
        elapsedMs: Long = 0L
    ) {
        _state.update {
            it.copy(
                isProcessing = false,
                progress = if (success) 1.0f else it.progress,
                currentStep = if (success) "✅ اكتملت المعالجة" else "❌ فشلت المعالجة",
                logs = it.logs + if (success) "[JAR] PROCESS COMPLETE: output saved" else "[JAR] PROCESS ERROR: $error",
                result = ResultInfo(
                    success = success,
                    outputFile = outputFile,
                    appliedFlags = it.activeFlags.toList(),
                    appliedPatches = it.activeFlags.toList(),
                    elapsedMs = elapsedMs,
                    errorMessage = error
                )
            )
        }
        // تحديث الحالة المحفوظة لضمان عودة الزر لوضعه الطبيعي عند إعادة فتح التطبيق
        savePersistentState(_state.value.currentStep, _state.value.logs)
    }

    private fun createWorkDir(): File {
        return File(_state.value.selectedApk?.parentFile, "patcher_session").also { it.mkdirs() }
    }

    fun humanBytes(size: Long): String {
        if (size <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var n = 0
        var s = size.toDouble()
        while (s > 1024 && n < units.size - 1) {
            s /= 1024
            n++
        }
        return "%.2f %s".format(s, units[n])
    }
}
