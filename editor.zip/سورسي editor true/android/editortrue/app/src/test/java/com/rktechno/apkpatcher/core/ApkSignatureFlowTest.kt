package com.rktechno.apkpatcher.core

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class ApkSignatureFlowTest {
    @Test
    fun unsignedSplitBundleProcessesResourceOnlySplitsAndPreservesMetadata() {
        val work = Files.createTempDirectory("editortrue-unsigned-split").toFile()
        val baseApk = File(work, "base.apk")
        val resourceSplit = File(work, "config.en.apk")
        val bundle = File(work, "fixture.apks")
        val toc = "split metadata must be preserved".toByteArray()
        val manifest = javaClass.getResourceAsStream("/fixture-AndroidManifest.xml")!!.use { it.readBytes() }

        try {
            createUnsignedApk(baseApk, manifest)
            ZipOutputStream(resourceSplit.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("AndroidManifest.xml"))
                zip.write(manifest)
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("resources.arsc"))
                zip.write(byteArrayOf(1, 2, 3, 4))
                zip.closeEntry()
            }
            ZipOutputStream(bundle.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("base.apk"))
                baseApk.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("splits/config.en.apk"))
                resourceSplit.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("toc.pb"))
                zip.write(toc)
                zip.closeEntry()
            }

            val result = SplitBundlePatcher.run(bundle, setOf("-u"), null, null) { }
            assertTrue("unsigned split patch should succeed: ${result.error}", result.success)
            val output = result.outputFile
            assertNotNull(output)
            assertTrue(output!!.isFile && output.length() > 0L)
            assertEquals("apks", output.extension)

            val componentFiles = mutableListOf<File>()
            ZipFile(output).use { zip ->
                assertArrayEquals(toc, zip.getInputStream(zip.getEntry("toc.pb")).use { it.readBytes() })
                val apkEntries = zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.endsWith(".apk", ignoreCase = true) }
                    .toList()
                assertEquals(2, apkEntries.size)
                apkEntries.forEachIndexed { index, entry ->
                    val extracted = File(work, "output_component_$index.apk")
                    zip.getInputStream(entry).use { input ->
                        extracted.outputStream().use { outputStream -> input.copyTo(outputStream) }
                    }
                    componentFiles += extracted
                    assertFalse("${entry.name} should remain unsigned in -u output", ApkSignatureInspector.isApkSignatureValid(extracted))
                    ZipFile(extracted).use { componentZip ->
                        assertNotNull(componentZip.getEntry("AndroidManifest.xml"))
                    }
                }
            }
            assertTrue("resource-only split should be processed and retained", componentFiles.size == 2)
        } finally {
            work.deleteRecursively()
        }
    }

    @Test
    fun unsignedSplitBundleDelegatesEveryApkAndRetainsNonApkEntries() {
        val work = Files.createTempDirectory("editortrue-sign-flow").toFile()
        val scratch = File(work, "scratch")
        val baseApk = File(work, "base.apk")
        val configApk = File(work, "config.apk")
        val bundle = File(work, "fixture.apks")
        val payload = "preserve bundle metadata".toByteArray()
        val manifest = javaClass.getResourceAsStream("/fixture-AndroidManifest.xml")!!.use { it.readBytes() }

        try {
            createUnsignedApk(baseApk, manifest)
            createUnsignedApk(configApk, manifest)
            ZipOutputStream(bundle.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("base.apk"))
                baseApk.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("splits/config.en.apk"))
                configApk.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(payload)
                zip.closeEntry()
            }

            val before = ApkSignatureInspector.inspect(bundle, scratch)
            assertFalse("fixture components should begin unsigned", before.isSigned)
            assertEquals("base.apk", before.unsignedComponent)

            val delegatedComponents = mutableListOf<String>()
            val rebuiltBundle = SplitBundlePatcher.signBundleComponents(bundle, { }) { component, _ ->
                delegatedComponents += component.name
                component
            }
            assertNotNull("the split bundle should be rebuilt", rebuiltBundle)
            assertEquals(2, delegatedComponents.size)
            assertEquals("apks", rebuiltBundle!!.extension)

            val after = ApkSignatureInspector.inspect(rebuiltBundle, scratch)
            assertFalse("the test signer deliberately leaves components unsigned", after.isSigned)
            assertEquals(2, after.componentCount)
            ZipFile(rebuiltBundle).use { zip ->
                assertArrayEquals(payload, zip.getInputStream(zip.getEntry("manifest.json")).use { it.readBytes() })
                assertNotNull(zip.getEntry("base.apk"))
                assertNotNull(zip.getEntry("splits/config.en.apk"))
            }
        } finally {
            work.deleteRecursively()
        }
    }

    private fun createUnsignedApk(file: File, manifest: ByteArray) {
        ZipOutputStream(file.outputStream().buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("AndroidManifest.xml"))
            zip.write(manifest)
            zip.closeEntry()
            zip.putNextEntry(ZipEntry("classes.dex"))
            zip.write(byteArrayOf(0x64, 0x65, 0x78, 0x0A))
            zip.closeEntry()
            zip.putNextEntry(ZipEntry("lib/arm64-v8a/libfixture.so"))
            zip.write(ByteArray(1024) { it.toByte() })
            zip.closeEntry()
        }
    }
}
