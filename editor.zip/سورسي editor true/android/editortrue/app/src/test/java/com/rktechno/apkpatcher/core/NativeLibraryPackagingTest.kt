package com.rktechno.apkpatcher.core

import com.reandroid.apk.ApkModule
import com.reandroid.archive.ByteInputSource
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class NativeLibraryPackagingTest {
    @Test
    fun compressedNativeLibraryIsStoredAndPageAlignedBeforeSigning() {
        val work = Files.createTempDirectory("editortrue-native-test").toFile()
        val source = File(work, "source.apk")
        val normalized = File(work, "normalized.apk")
        val libraryPath = "lib/arm64-v8a/libfixture.so"
        val libraryBytes = ByteArray(23_517) { ((it * 37 + 11) and 0xFF).toByte() }
        val manifest = javaClass.getResourceAsStream("/fixture-AndroidManifest.xml")!!.use { it.readBytes() }

        try {
            ZipOutputStream(source.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("AndroidManifest.xml").apply { time = 0L })
                zip.write(manifest)
                zip.closeEntry()

                zip.putNextEntry(ZipEntry(libraryPath).apply {
                    method = ZipEntry.DEFLATED
                    time = 0L
                    // A prior 4KB alignment field must be replaced, not accumulated.
                    extra = byteArrayOf(0x35, 0xD9.toByte(), 0x02, 0x00, 0x00, 0x10)
                })
                zip.write(libraryBytes)
                zip.closeEntry()

                zip.putNextEntry(ZipEntry("META-INF/OLD.SF"))
                zip.write("stale signature".toByteArray())
                zip.closeEntry()
            }

            NativeToolPatcher.stripOldSignatures(source, normalized)
            NativeToolPatcher.validateNativeLibraryPackaging(normalized)

            ZipFile(normalized).use { zip ->
                val library = zip.getEntry(libraryPath)
                assertEquals("native library must be stored, not compressed", ZipEntry.STORED, library.method)
                assertArrayEquals(libraryBytes, zip.getInputStream(library).use { it.readBytes() })
                assertEquals("old JAR signature must be removed", null, zip.getEntry("META-INF/OLD.SF"))
            }
        } finally {
            work.deleteRecursively()
        }
    }

    @Test
    fun replacedFlutterNativeLibraryBytesSurviveTheAlignedApkWriter() {
        val work = Files.createTempDirectory("editortrue-flutter-writer-test").toFile()
        val source = File(work, "source.apk")
        val output = File(work, "patched.apk")
        val libraryPath = "lib/arm64-v8a/libflutter.so"
        val originalBytes = ByteArray(19_731) { ((it * 13 + 5) and 0xFF).toByte() }
        val patchedBytes = ByteArray(19_731) { ((it * 29 + 17) and 0xFF).toByte() }
        val manifest = javaClass.getResourceAsStream("/fixture-AndroidManifest.xml")!!.use { it.readBytes() }

        try {
            ZipOutputStream(source.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("AndroidManifest.xml"))
                zip.write(manifest)
                zip.closeEntry()
                zip.putNextEntry(ZipEntry(libraryPath))
                zip.write(originalBytes)
                zip.closeEntry()
            }

            val module = ApkModule.loadApkFile(source)
            try {
                module.removeInputSource(libraryPath)
                module.add(ByteInputSource(patchedBytes, libraryPath))
                NativeToolPatcher.writeCleanAlignedApk(module, output) { }
            } finally {
                module.close()
            }

            NativeToolPatcher.validateNativeLibraryPackaging(output)
            ZipFile(output).use { zip ->
                val library = zip.getEntry(libraryPath)
                assertEquals("patched Flutter library must be stored", ZipEntry.STORED, library.method)
                assertArrayEquals(patchedBytes, zip.getInputStream(library).use { it.readBytes() })
            }
        } finally {
            work.deleteRecursively()
        }
    }
}
