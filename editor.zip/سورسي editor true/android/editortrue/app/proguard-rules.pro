# Release shrinking/obfuscation rules for EDITOR TRUE.
# Keep only runtime-discovered entry points; application code remains eligible for R8 obfuscation.

# Android components referenced from the merged manifest.
-keep public class com.rktechno.apkpatcher.PatcherApp { public <init>(); }
-keep public class com.rktechno.apkpatcher.ui.SplashActivity { public <init>(); }
-keep public class com.rktechno.apkpatcher.ui.MainActivity { public <init>(); }
-keep public class com.rktechno.apkpatcher.ui.EditorXActivity { public <init>(); }
-keep public class com.rktechno.apkpatcher.core.PatchService { public <init>(); }

# AppCompat installs a LayoutInflater.Factory2 implementation at runtime.
# Keeping this framework layer avoids AbstractMethodError on Android 13/14
# when R8 full-mode optimizes interface bridge methods.
-keep class androidx.appcompat.** { *; }
-keep class com.google.android.material.** { *; }

# FileProvider metadata and Android framework callbacks.
-keep class androidx.core.content.FileProvider { *; }
-keepclassmembers class * extends android.app.Service { public <methods>; }

# KillerX exposes JNI methods using fixed Java class/method names.
-keep class com.killerx.** { *; }
-keepclasseswithmembers,includedescriptorclasses class * {
    native <methods>;
}

# Kotlin serialization generated serializers are discovered by generated code/reflection.
-keep class **$$serializer { *; }
-keepclassmembers class ** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Preserve source line information for useful crash reports while still obfuscating names.
-keepattributes SourceFile,LineNumberTable,InnerClasses,EnclosingMethod,Exceptions,Signature,*Annotation*
-renamesourcefileattribute SourceFile

# Avoid noisy warnings from optional crypto/JDK classes bundled by dependencies.
-dontwarn javax.annotation.**
-dontwarn com.google.auto.value.**
-dontwarn org.conscrypt.**
-dontwarn sun.misc.**
