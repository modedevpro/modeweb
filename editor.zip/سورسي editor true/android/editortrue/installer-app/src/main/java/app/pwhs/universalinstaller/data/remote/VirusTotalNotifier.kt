package app.pwhs.universalinstaller.data.remote

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.content.Intent
import android.app.PendingIntent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.pwhs.universalinstaller.R

class VirusTotalNotifier(private val context: Context) {

    private val manager = NotificationManagerCompat.from(context)

    init {
        ensureChannel()
    }

    private val activeIds = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()

    fun notifyHashing(fileName: String): Int {
        if (!canPost()) return -1
        val id = nextId()
        val n = baseBuilder()
            .setContentTitle(context.getString(R.string.vt_notif_hashing))
            .setContentText(fileName)
            .setProgress(0, 0, true)
            .setOngoing(false)
            .build()
        post(id, n)
        activeIds.add(id)
        return id
    }

    fun notifyUploadingStart(fileName: String): Int {
        if (!canPost()) return -1
        val id = nextId()
        val n = baseBuilder()
            .setContentTitle(context.getString(R.string.vt_notif_uploading, 0))
            .setContentText(fileName)
            .setProgress(100, 0, false)
            .setOngoing(false)
            .setOnlyAlertOnce(true)
            .build()
        post(id, n)
        activeIds.add(id)
        return id
    }

    fun notifyUploading(id: Int, fileName: String, percent: Int) {
        if (!canPost() || id < 0) return
        val n = baseBuilder()
            .setContentTitle(context.getString(R.string.vt_notif_uploading, percent))
            .setContentText(fileName)
            .setProgress(100, percent, false)
            .setOngoing(false)
            .setOnlyAlertOnce(true)
            .build()
        post(id, n)
        activeIds.add(id)
    }

    fun notifyQueued(id: Int, fileName: String) {
        if (!canPost() || id < 0) return
        val n = baseBuilder()
            .setContentTitle(context.getString(R.string.vt_notif_queued))
            .setContentText(fileName)
            .setProgress(0, 0, true)
            .setOngoing(false)
            .setOnlyAlertOnce(true)
            .build()
        post(id, n)
        activeIds.add(id)
    }

    fun notifyAnalyzing(id: Int, fileName: String) {
        if (!canPost() || id < 0) return
        val n = baseBuilder()
            .setContentTitle(context.getString(R.string.vt_notif_analyzing))
            .setContentText(fileName)
            .setProgress(0, 0, true)
            .setOngoing(false)
            .setOnlyAlertOnce(true)
            .build()
        post(id, n)
        activeIds.add(id)
    }

    fun notifyResult(id: Int, fileName: String, title: String, text: String, sha256: String = "") {
        if (!canPost() || id < 0) return
        activeIds.remove(id)
        val builder = baseBuilder()
            .setContentTitle(title)
            .setContentText("$fileName · $text")
            .setProgress(0, 0, false)
            .setOngoing(false)
            .setAutoCancel(true)
            
        if (sha256.isNotBlank()) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.virustotal.com/gui/file/$sha256/detection"))
            val pendingIntent = PendingIntent.getActivity(context, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            builder.setContentIntent(pendingIntent)
        }

        post(id, builder.build())
    }

    fun cancel(id: Int) {
        if (id < 0) return
        activeIds.remove(id)
        manager.cancel(id)
    }

    fun cancelAll() {
        activeIds.forEach { manager.cancel(it) }
        activeIds.clear()
    }

    private fun baseBuilder(): NotificationCompat.Builder =
        NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.logo_no_gradient)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)

    private fun post(id: Int, notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        manager.notify(id, notification)
    }

    private fun canPost(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return false
        }
        return manager.areNotificationsEnabled()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val sys = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (sys.getNotificationChannel(CHANNEL_ID) != null) return
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.vt_notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.vt_notif_channel_description)
                setShowBadge(false)
            }
            sys.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "virustotal_scan"
        private var nextId = 3000
        @Synchronized
        private fun nextId(): Int = ++nextId
    }
}
