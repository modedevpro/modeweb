package app.pwhs.universalinstaller.presentation.install

import android.net.Uri
import app.pwhs.universalinstaller.domain.model.ApkInfo
import app.pwhs.universalinstaller.domain.model.InstallerProfile
import app.pwhs.universalinstaller.domain.model.SessionData
import app.pwhs.universalinstaller.domain.model.SessionProgress
import java.util.UUID

/**
 * Stages for the dialog install flow, inspired by InstallerX-Revived's multi-stage pattern.
 * The dialog shows different content at each stage, keeping the main screen clean and gọn.
 */
sealed interface DialogStage {
    /** APK is being parsed — show a spinner. */
    data object Loading : DialogStage

    /** Parse complete — show clean info: icon + name + version + warning chips + buttons. */
    data object Prepare : DialogStage

    /** User tapped Menu — show extended options: permissions, VT, OBB, splits, install flags. */
    data object Menu : DialogStage

    /** Install session is in progress — show progress bar. */
    data object Installing : DialogStage

    /** Install succeeded — show open/done buttons. */
    data object Success : DialogStage

    /** Install failed — show error + retry/close buttons. */
    data class Failed(val errorMessage: String = "") : DialogStage

    /**
     * The file could not be read at all: the grant died, it was moved, or the source app's
     * provider refused us. Distinct from [ParseFailed] because the fix is different — nothing
     * about the package is wrong, we just never got its bytes.
     */
    data class ReadFailed(val reason: String = "") : DialogStage

    /**
     * The bytes arrived but are not an installable package — wrong format, truncated download,
     * an archive with no APK inside.
     */
    data class ParseFailed(val reason: String = "") : DialogStage

    /**
     * Installing from unknown sources is not granted, so the install would fail the moment it
     * started. Asks for the permission instead of failing and blaming the package.
     */
    data object PermissionRequired : DialogStage

    /** No dialog should be shown. */
    data object None : DialogStage
}

/**
 * Snapshot of the install target captured at confirmInstall time. Lets the
 * Installing/Success/Failed dialog stages render after pendingApkInfo is cleared.
 */
data class DialogTarget(
    val sessionId: UUID,
    val packageName: String,
    val appName: String,
    val iconPath: String?,
    val apkUri: android.net.Uri? = null,
    val deleteAfterInstall: Boolean = false,
)

sealed interface DownloadState {
    data object Idle : DownloadState
    data class Running(
        val url: String,
        val bytesRead: Long,
        val totalBytes: Long,
        val speedBytesPerSec: Long = 0L,
        val etaSeconds: Long? = null,
    ) : DownloadState {
        val progressPercent: Int?
            get() = if (totalBytes > 0) ((bytesRead * 100L) / totalBytes).toInt().coerceIn(0, 100) else null
    }

    data class Error(val message: String) : DownloadState
}

sealed interface ScanState {
    data object Idle : ScanState
    data object PermissionNeeded : ScanState
    data class Scanning(
        val status: String? = null,
        val foundCount: Int = 0,
        val progress: Float? = null,
    ) : ScanState
    data class Ready(val files: List<FoundPackageFile>) : ScanState
}

data class AttachedObb(
    val uri: android.net.Uri,
    val fileName: String,
    val sizeBytes: Long,
)

/** Single entry in a batch install — one APK parsed + resolved + user-toggleable. */
data class BatchApkEntry(
    val uri: android.net.Uri,
    val fileName: String,
    val apkInfo: ApkInfo,
    /** URIs resolved from ackpine's SplitPackage — what the installer session receives. */
    val splitUris: List<android.net.Uri>,
    val selected: Boolean = true,
    val parseError: String? = null,
    /**
     * Soft warning — e.g. another entry in the batch already targets the same package name.
     * Unlike [parseError], the entry is still installable; the label just flags a likely conflict
     * (downgrade, signature mismatch) so the user can deselect before committing.
     */
    val conflictLabel: String? = null,
)

sealed interface BatchInstallState {
    data object Idle : BatchInstallState
    data class Parsing(val uris: List<android.net.Uri>, val processed: Int, val total: Int) : BatchInstallState
    data class Ready(val entries: List<BatchApkEntry>) : BatchInstallState
}

sealed interface ObbCopyState {
    data object Idle : ObbCopyState
    data class Running(
        val appName: String,
        val packageName: String,
        val bytesCopied: Long,
        val totalBytes: Long,
    ) : ObbCopyState {
        val progressPercent: Int
            get() = if (totalBytes > 0) ((bytesCopied * 100L) / totalBytes).toInt().coerceIn(0, 100) else 0
    }
    data class Done(val appName: String, val fileCount: Int) : ObbCopyState
    data class Error(val appName: String, val message: String) : ObbCopyState
    /** No Shizuku + no stored SAF grant → user needs to pick `Android/obb/<pkg>/`. */
    data class NeedSafGrant(val appName: String, val packageName: String) : ObbCopyState
}

/** Tracks progress of sending an APK to the paired Wear OS watch. */
sealed interface WatchSendState {
    data object Idle : WatchSendState
    data object CheckingWatch : WatchSendState
    data class Sending(
        val progress: Float, // 0.0–1.0
        val bytesSent: Long = 0L,
        val totalBytes: Long = 0L,
        val speedBytesPerSec: Long = 0L,
        val etaSeconds: Long? = null,
    ) : WatchSendState
    data object Success : WatchSendState
    data object NoWatch : WatchSendState
    /** APK does not declare the watch feature; the user decides whether to send it anyway. */
    data class ConfirmNotWatchApp(val apkUri: Uri, val fileName: String) : WatchSendState
    data class Unsupported(val reason: String) : WatchSendState
    data class Error(val message: String) : WatchSendState
}

data class InstallUiState(
    val sessions: List<SessionData> = emptyList(),
    val sessionsProgress: List<SessionProgress> = emptyList(),
    val isLoading: Boolean = false,
    val pendingApkInfo: ApkInfo? = null,
    val downloadState: DownloadState = DownloadState.Idle,
    val scanState: ScanState = ScanState.Idle,
    val obbCopyState: ObbCopyState = ObbCopyState.Idle,
    val attachedObbFiles: List<AttachedObb> = emptyList(),
    val batchState: BatchInstallState = BatchInstallState.Idle,
    val batchDetailUri: android.net.Uri? = null,
    /** Current stage of the dialog install flow. */
    val dialogStage: DialogStage = DialogStage.None,
    /** Whether to merge split APKs from multiple files into a single session. */
    val mergeSplits: Boolean = false,
    val installerProfiles: List<InstallerProfile> = emptyList(),
    val appProfileMapping: Map<String, String> = emptyMap(),
    val syncState: app.pwhs.universalinstaller.presentation.sync.SyncState = app.pwhs.universalinstaller.presentation.sync.SyncState.STOPPED,
    val selectedProfileId: String? = null,
    val allUsers: Boolean = false,
    val selectedUserId: Int? = null,
    val isApk: Boolean = false,
    val dialogDownloadProgress: app.pwhs.core.network.DownloadProgress? = null,
    val watchSendState: WatchSendState = WatchSendState.Idle,
)
