package app.pwhs.universalinstaller.presentation.install

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.provider.Settings
import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.QueryStats
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.compose.LifecycleResumeEffect
import app.pwhs.universalinstaller.R
import app.pwhs.core.util.PermissionMonitor

/**
 * Identifier for each permission tile. Keeps the composable layer ignorant of which Manifest
 * constant / settings-intent is behind each one — that's resolved in [checkGranted] / [grantIntent].
 */
private enum class PermKind { Install, Storage, Notifications, Usage }

private data class PermissionItem(
    val kind: PermKind,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val granted: Boolean,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PermissionCenterSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
) {
    if (!visible) return
    val context = LocalContext.current
    val activity = context as? Activity
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Refresh state whenever the sheet returns to the foreground — the user may have toggled
    // a permission in system settings while we were in the background.
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) {
        tick += 1
        PermissionMonitor.stop() // Stop polling once we're back
        onPauseOrDispose {}
    }

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { tick += 1 }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        tick += 1
        val status = if (granted) app.pwhs.core.telemetry.TelemetryEvents.STATUS_GRANTED else app.pwhs.core.telemetry.TelemetryEvents.STATUS_DENIED
        app.pwhs.core.telemetry.AnalyticsHelper.logPermissionResult(app.pwhs.core.telemetry.TelemetryEvents.PERM_NOTIFICATIONS, status)
        // If denied via runtime dialog AND the system says we shouldn't show rationale anymore,
        // it means user permanently denied (or hit "Don't ask again"). Fall back to settings.
        if (!granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val canStillAsk = activity?.let {
                ActivityCompat.shouldShowRequestPermissionRationale(
                    it, Manifest.permission.POST_NOTIFICATIONS,
                )
            } ?: false
            if (!canStillAsk && activity != null) {
                PermissionMonitor.start(activity) { isNotificationsGranted(context) }
                settingsLauncher.launch(notificationSettingsIntent(context))
            }
        }
    }

    // Strings resolve in composable scope; granted flags re-read every `tick` bump (resume,
    // grant callback) without rebuilding the whole composable tree.
    val installTitle = stringResource(R.string.permission_install_title)
    val installDesc = stringResource(R.string.permission_install_desc)
    val storageTitle = stringResource(R.string.permission_storage_title)
    val storageDesc = stringResource(R.string.permission_storage_desc)
    val notifTitle = stringResource(R.string.permission_notifications_title)
    val notifDesc = stringResource(R.string.permission_notifications_desc)
    val usageTitle = stringResource(R.string.permission_usage_title)
    val usageDesc = stringResource(R.string.permission_usage_desc)

    val items = remember(tick) {
        listOf(
            PermissionItem(
                kind = PermKind.Install,
                title = installTitle,
                description = installDesc,
                icon = Icons.Rounded.InstallMobile,
                granted = isInstallGranted(context),
            ),
            PermissionItem(
                kind = PermKind.Storage,
                title = storageTitle,
                description = storageDesc,
                icon = Icons.Rounded.FolderOpen,
                granted = isAllFilesAccessGranted(context),
            ),
            PermissionItem(
                kind = PermKind.Notifications,
                title = notifTitle,
                description = notifDesc,
                icon = Icons.Rounded.Notifications,
                granted = isNotificationsGranted(context),
            ),
            PermissionItem(
                kind = PermKind.Usage,
                title = usageTitle,
                description = usageDesc,
                icon = Icons.Rounded.QueryStats,
                granted = isUsageAccessGranted(context),
            ),
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.Notifications, // General permission icon representation
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    text = stringResource(R.string.permissions_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.permissions_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
            Spacer(Modifier.height(24.dp))
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(items, key = { it.kind }) { item ->
                    PermissionRow(
                        item = item,
                        onGrant = {
                            val permType = when (item.kind) {
                                PermKind.Install -> app.pwhs.core.telemetry.TelemetryEvents.PERM_INSTALL_UNKNOWN_APPS
                                PermKind.Storage -> app.pwhs.core.telemetry.TelemetryEvents.PERM_ALL_FILES
                                PermKind.Notifications -> app.pwhs.core.telemetry.TelemetryEvents.PERM_NOTIFICATIONS
                                PermKind.Usage -> "usage_stats"
                            }
                            app.pwhs.core.telemetry.AnalyticsHelper.logPermissionRequested(permType, app.pwhs.core.telemetry.TelemetryEvents.SOURCE_FIRST_INSTALL)
                            when (item.kind) {
                                PermKind.Notifications -> {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        val deniedOnce = activity?.let {
                                            ActivityCompat.shouldShowRequestPermissionRationale(
                                                it, Manifest.permission.POST_NOTIFICATIONS,
                                            )
                                        } ?: false
                                        val runtimeDenied = ContextCompat.checkSelfPermission(
                                            context, Manifest.permission.POST_NOTIFICATIONS,
                                        ) != PackageManager.PERMISSION_GRANTED
                                        // Permanently denied: rationale=false AND not granted AND we already asked
                                        // before. Skip the silent runtime dialog and go straight to settings.
                                        if (runtimeDenied && !deniedOnce && hasAskedBeforeNotifPref(context) && activity != null) {
                                            PermissionMonitor.start(activity) {
                                                val granted = isNotificationsGranted(context)
                                                if (granted) app.pwhs.core.telemetry.AnalyticsHelper.logPermissionResult(permType, app.pwhs.core.telemetry.TelemetryEvents.STATUS_GRANTED)
                                                granted
                                            }
                                            settingsLauncher.launch(notificationSettingsIntent(context))
                                        } else {
                                            markAskedNotifPref(context)
                                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                    } else {
                                        val intent = notificationSettingsIntent(context)
                                        if (activity != null) {
                                            PermissionMonitor.start(activity) {
                                                val granted = isNotificationsGranted(context)
                                                if (granted) app.pwhs.core.telemetry.AnalyticsHelper.logPermissionResult(permType, app.pwhs.core.telemetry.TelemetryEvents.STATUS_GRANTED)
                                                granted
                                            }
                                        }
                                        settingsLauncher.launch(intent)
                                    }
                                }
                                else -> {
                                    val intent = grantIntent(context, item.kind)
                                    if (intent != null) {
                                        if (activity != null) {
                                            PermissionMonitor.start(activity) {
                                                val granted = when (item.kind) {
                                                    PermKind.Install -> isInstallGranted(context)
                                                    PermKind.Storage -> isAllFilesAccessGranted(context)
                                                    PermKind.Usage -> isUsageAccessGranted(context)
                                                    PermKind.Notifications -> false
                                                }
                                                if (granted) app.pwhs.core.telemetry.AnalyticsHelper.logPermissionResult(permType, app.pwhs.core.telemetry.TelemetryEvents.STATUS_GRANTED)
                                                granted
                                            }
                                        }
                                        settingsLauncher.launch(intent)
                                    }
                                }
                            }
                        },
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PermissionRow(
    item: PermissionItem,
    onGrant: () -> Unit,
) {
    val containerColor = if (item.granted) {
        MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.5f)
    } else {
        MaterialTheme.colorScheme.surfaceContainer
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = RoundedCornerShape(20.dp),
        color = containerColor,
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (item.granted) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = null,
                            tint = if (item.granted) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = androidx.compose.ui.unit.TextUnit(16f, androidx.compose.ui.unit.TextUnitType.Sp)
                    )
                }
            }
            
            if (!item.granted) {
                Spacer(Modifier.height(16.dp))
                FilledTonalButton(
                    onClick = onGrant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Text(
                        text = stringResource(
                            if (item.kind == PermKind.Notifications &&
                                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                            ) {
                                R.string.permissions_grant
                            } else {
                                R.string.permissions_open_settings
                            }
                        ),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            } else {
                Spacer(Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 64.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.permissions_granted),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

private fun isInstallGranted(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.packageManager.canRequestPackageInstalls()
    } else true
}

private fun isAllFilesAccessGranted(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_EXTERNAL_STORAGE,
        ) == PackageManager.PERMISSION_GRANTED
    }
}

private fun isNotificationsGranted(context: Context): Boolean {
    // areNotificationsEnabled() reflects the channel-level switch — what the user toggles in
    // App notifications settings. Works on every API level and stays consistent whether the
    // grant came via runtime dialog (13+) or the settings toggle.
    return NotificationManagerCompat.from(context).areNotificationsEnabled()
}

private fun notificationSettingsIntent(context: Context): Intent {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
    } else {
        appDetailsIntent(context)
    }
}

private const val PREF_NOTIF = "permission_center_prefs"
private const val KEY_ASKED_NOTIF = "asked_post_notifications"

private fun hasAskedBeforeNotifPref(context: Context): Boolean =
    context.getSharedPreferences(PREF_NOTIF, Context.MODE_PRIVATE)
        .getBoolean(KEY_ASKED_NOTIF, false)

private fun markAskedNotifPref(context: Context) {
    context.getSharedPreferences(PREF_NOTIF, Context.MODE_PRIVATE)
        .edit()
        .putBoolean(KEY_ASKED_NOTIF, true)
        .apply()
}

private fun isUsageAccessGranted(context: Context): Boolean {
    return try {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName,
            )
        } else {
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName,
            )
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }
}

private fun grantIntent(context: Context, kind: PermKind): Intent? {
    return when (kind) {
        PermKind.Install -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                data = "package:${context.packageName}".toUri()
            }
        } else appDetailsIntent(context)
        PermKind.Storage -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = "package:${context.packageName}".toUri()
            }
        } else appDetailsIntent(context)
        PermKind.Usage -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        PermKind.Notifications -> appDetailsIntent(context)
    }
}

private fun appDetailsIntent(context: Context): Intent {
    return Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = "package:${context.packageName}".toUri()
    }
}

