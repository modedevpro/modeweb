package app.pwhs.universalinstaller.presentation.install

import android.content.Context
import android.os.Build
import app.pwhs.core.util.DeviceCompat
import app.pwhs.universalinstaller.R
import ru.solrudev.ackpine.installer.InstallFailure

object InstallErrorHelper {

    private val REQUIRED_SDK_REGEX = Regex(
        """(?:newer sdk version|sdk version)\s*#?(\d+)""",
        RegexOption.IGNORE_CASE
    )

    data class ErrorInfo(
        val title: String,
        val guidance: String,
    )

    /**
     * Appends the MIUI/HyperOS workaround to [info] when we're on Xiaomi hardware and the failure
     * is one this ROM family is known to cause (issue #104).
     *
     * Kept separate from [getErrorInfo] so it can be applied to the live error only — install
     * history stores the plain diagnosis, not a paragraph of advice that would be replayed on
     * every history card forever.
     */
    fun withDeviceHint(context: Context, info: ErrorInfo, failure: InstallFailure): ErrorInfo {
        if (!DeviceCompat.isXiaomi || !isMiuiSuspect(failure)) return info
        return info.copy(
            guidance = "${info.guidance}\n\n${context.getString(R.string.install_error_miui_hint)}",
        )
    }

    /**
     * `Conflict` covers several unrelated `INSTALL_FAILED_*` codes — a version downgrade, a
     * signature mismatch and a plain duplicate all land here. The old single message named the
     * "Replace existing" toggle for all of them, which sent users who hit a downgrade or a
     * signature mismatch to a switch that was already on and couldn't have helped.
     *
     * ackpine passes the platform's status message through verbatim, so the code is in there.
     */
    private fun conflictGuidance(message: String?): Int {
        val raw = message.orEmpty().uppercase()
        return when {
            "VERSION_DOWNGRADE" in raw -> R.string.install_error_conflict_downgrade_guidance
            // The platform reports a signature mismatch as UPDATE_INCOMPATIBLE, and older/OEM
            // builds sometimes spell it out in prose instead.
            "UPDATE_INCOMPATIBLE" in raw || "SIGNATURES DO NOT MATCH" in raw ->
                R.string.install_error_conflict_signature_guidance
            else -> R.string.install_error_conflict_guidance
        }
    }

    private fun isMissingSplit(message: String?): Boolean {
        val raw = message.orEmpty().uppercase()
        return "INSTALL_FAILED_MISSING_SPLIT" in raw || "MISSING_SPLIT" in raw || "MISSING SPLIT" in raw
    }

    fun sdkToAndroidVersion(sdk: Int): String = when (sdk) {
        21 -> "5.0"
        22 -> "5.1"
        23 -> "6.0"
        24 -> "7.0"
        25 -> "7.1"
        26 -> "8.0"
        27 -> "8.1"
        28 -> "9"
        29 -> "10"
        30 -> "11"
        31 -> "12"
        32 -> "12L"
        33 -> "13"
        34 -> "14"
        35 -> "15"
        36 -> "16"
        37 -> "17"
        else -> sdk.toString()
    }

    private fun incompatibleErrorInfo(context: Context, message: String?): ErrorInfo {
        val raw = message.orEmpty().uppercase()
        return when {
            "OLDER_SDK" in raw || "NEWER SDK" in raw -> {
                val match = REQUIRED_SDK_REGEX.find(message.orEmpty())
                val reqSdk = match?.groupValues?.getOrNull(1)?.toIntOrNull()
                val guidance = if (reqSdk != null) {
                    val reqVer = sdkToAndroidVersion(reqSdk)
                    val currentSdk = Build.VERSION.SDK_INT
                    val currentVer = Build.VERSION.RELEASE.takeIf { !it.isNullOrBlank() }
                        ?: sdkToAndroidVersion(currentSdk)
                    context.getString(
                        R.string.install_error_incompatible_sdk_detailed_guidance,
                        reqVer,
                        reqSdk,
                        currentVer,
                        currentSdk
                    )
                } else {
                    context.getString(R.string.install_error_incompatible_sdk_guidance)
                }
                ErrorInfo(
                    title = context.getString(R.string.install_error_incompatible_sdk_title),
                    guidance = guidance,
                )
            }
            "CPU_ABI" in raw || "NO_MATCHING_ABIS" in raw || "NATIVE_LIBRARIES" in raw || "RES=-113" in raw -> {
                val deviceAbis = Build.SUPPORTED_ABIS.joinToString(", ")
                val recommended = if (app.pwhs.universalinstaller.presentation.install.util.AbiCompatibilityHelper.isDevice32BitOnly()) {
                    "32-bit (armeabi-v7a)"
                } else if (app.pwhs.universalinstaller.presentation.install.util.AbiCompatibilityHelper.isDevice64BitOnly()) {
                    "64-bit (arm64-v8a)"
                } else {
                    "Universal"
                }
                ErrorInfo(
                    title = context.getString(R.string.install_error_incompatible_abi_title),
                    guidance = context.getString(
                        R.string.install_error_incompatible_abi_detailed_guidance,
                        "unsupported",
                        deviceAbis,
                        recommended,
                    ),
                )
            }
            "MISSING_FEATURE" in raw || "FEATURE" in raw -> ErrorInfo(
                title = context.getString(R.string.install_error_incompatible_feature_title),
                guidance = context.getString(R.string.install_error_incompatible_feature_guidance),
            )
            else -> ErrorInfo(
                title = context.getString(R.string.install_error_incompatible_title),
                guidance = context.getString(R.string.install_error_incompatible_guidance),
            )
        }
    }

    /**
     * Failure kinds MIUI/HyperOS "optimization" is known to produce when it silently vetoes a
     * third-party install. Which one surfaces depends on the ROM version, so we cover the whole
     * ambiguous set rather than guessing; the well-diagnosed failures (storage, invalid APK,
     * ABI mismatch, package conflict) keep their own guidance untouched.
     *
     * [InstallFailure.Aborted] is in the "suspect" set on purpose: ackpine's `await()` resolves an
     * in-app cancel by throwing [kotlinx.coroutines.CancellationException], so an Aborted result
     * here is always a *system* abort — precisely what MIUI optimization produces.
     */
    fun isFrpMessage(message: String): Boolean {
        val upper = message.uppercase()
        return "SECURE FRP" in upper || ("FRP" in upper && ("INSTALL" in upper || "SECURITY" in upper || "DEVICE" in upper || "CAN'T INSTALL" in upper))
    }

    fun isFrpException(throwable: Throwable?): Boolean {
        var current: Throwable? = throwable
        while (current != null) {
            if (current is SecurityException && isFrpMessage(current.message.orEmpty())) {
                return true
            }
            if (isFrpMessage(current.message.orEmpty())) {
                return true
            }
            current = current.cause
        }
        return false
    }

    fun isFrpFailure(failure: InstallFailure): Boolean {
        if (failure is InstallFailure.Exceptional) {
            if (isFrpException(failure.exception)) return true
        }
        return isFrpMessage(failure.message.orEmpty())
    }

    private fun isMiuiSuspect(failure: InstallFailure): Boolean {
        if (isFrpFailure(failure)) return false
        return when (failure) {
            is InstallFailure.Aborted,
            is InstallFailure.Blocked,
            is InstallFailure.Generic,
            -> true
            is InstallFailure.Conflict,
            is InstallFailure.Incompatible,
            is InstallFailure.Invalid,
            is InstallFailure.Storage,
            is InstallFailure.Timeout,
            is InstallFailure.Exceptional,
            -> false
            else -> true
        }
    }

    fun getErrorInfo(context: Context, failure: InstallFailure): ErrorInfo {
        if (isFrpFailure(failure)) {
            return ErrorInfo(
                title = context.getString(R.string.install_error_security_frp_title),
                guidance = context.getString(R.string.install_error_security_frp_guidance),
            )
        }
        if (isMissingSplit(failure.message)) {
            return ErrorInfo(
                title = context.getString(R.string.install_error_missing_split_title),
                guidance = context.getString(R.string.install_error_missing_split_guidance),
            )
        }
        if (app.pwhs.universalinstaller.presentation.install.util.AbiCompatibilityHelper.isAbiErrorMessage(failure.message)) {
            return incompatibleErrorInfo(context, failure.message)
        }
        return when (failure) {
            is InstallFailure.Aborted -> ErrorInfo(
                title = context.getString(R.string.install_error_cancelled_title),
                guidance = context.getString(R.string.install_error_cancelled_guidance),
            )
            is InstallFailure.Blocked -> ErrorInfo(
                title = context.getString(R.string.install_error_blocked_title),
                guidance = context.getString(R.string.install_error_blocked_guidance),
            )
            is InstallFailure.Conflict -> ErrorInfo(
                title = context.getString(R.string.install_error_conflict_title),
                guidance = context.getString(conflictGuidance(failure.message)),
            )
            is InstallFailure.Incompatible -> incompatibleErrorInfo(context, failure.message)
            is InstallFailure.Invalid -> ErrorInfo(
                title = context.getString(R.string.install_error_invalid_title),
                guidance = context.getString(R.string.install_error_invalid_guidance),
            )
            is InstallFailure.Storage -> ErrorInfo(
                title = context.getString(R.string.install_error_storage_title),
                guidance = context.getString(R.string.install_error_storage_guidance),
            )
            is InstallFailure.Timeout -> ErrorInfo(
                title = context.getString(R.string.install_error_timeout_title),
                guidance = context.getString(R.string.install_error_timeout_guidance),
            )
            is InstallFailure.Exceptional -> ErrorInfo(
                title = context.getString(R.string.install_error_unexpected_title),
                guidance = context.getString(R.string.install_error_unexpected_guidance, failure.message ?: ""),
            )
            is InstallFailure.Generic -> ErrorInfo(
                title = context.getString(R.string.install_error_failed_title),
                guidance = failure.message ?: context.getString(R.string.install_error_unknown_guidance),
            )
            else -> ErrorInfo(
                title = context.getString(R.string.install_error_failed_title),
                guidance = failure.message ?: context.getString(R.string.install_error_unknown_guidance_short),
            )
        }
    }

    fun getUserFriendlyMessage(context: Context, failure: InstallFailure): String {
        val info = getErrorInfo(context, failure)
        return "${info.title}: ${info.guidance}"
    }

    /**
     * Resolves exceptions originating from shell commands (libsu root, custom authorizer) into
     * user-friendly structured [ErrorInfo] instead of surfacing raw terminal dumps.
     */
    fun resolveException(context: Context, message: String?): ErrorInfo {
        if (isFrpMessage(message.orEmpty())) {
            return ErrorInfo(
                title = context.getString(R.string.install_error_security_frp_title),
                guidance = context.getString(R.string.install_error_security_frp_guidance),
            )
        }
        if (isMissingSplit(message)) {
            return ErrorInfo(
                title = context.getString(R.string.install_error_missing_split_title),
                guidance = context.getString(R.string.install_error_missing_split_guidance),
            )
        }
        if (app.pwhs.universalinstaller.presentation.install.util.AbiCompatibilityHelper.isAbiErrorMessage(message)) {
            return incompatibleErrorInfo(context, message)
        }
        val raw = message.orEmpty().uppercase()
        return when {
            "VERSION_DOWNGRADE" in raw -> ErrorInfo(
                title = context.getString(R.string.install_error_conflict_title),
                guidance = context.getString(R.string.install_error_conflict_downgrade_guidance),
            )
            "UPDATE_INCOMPATIBLE" in raw || "SIGNATURES DO NOT MATCH" in raw -> ErrorInfo(
                title = context.getString(R.string.install_error_conflict_title),
                guidance = context.getString(R.string.install_error_conflict_signature_guidance),
            )
            "INSUFFICIENT_STORAGE" in raw -> ErrorInfo(
                title = context.getString(R.string.install_error_storage_title),
                guidance = context.getString(R.string.install_error_storage_guidance),
            )
            else -> ErrorInfo(
                title = context.getString(R.string.install_error_failed_title),
                guidance = message ?: context.getString(R.string.install_error_unknown_guidance),
            )
        }
    }

    /**
     * A stable, non-localised name for a failure kind, for telemetry.
     *
     * Deliberately not `failure::class.simpleName`: R8 renames ackpine's classes, so release
     * builds would report a different — and meaningless — name than debug ones. Never include
     * `failure.message`; it carries package and file names.
     */
    fun failureKey(failure: InstallFailure): String {
        if (isFrpFailure(failure)) {
            return "security_frp"
        }
        if (isMissingSplit(failure.message)) return "missing_split"
        return when (failure) {
            is InstallFailure.Aborted -> "aborted"
            is InstallFailure.Blocked -> "blocked"
            is InstallFailure.Conflict -> "conflict"
            is InstallFailure.Incompatible -> "incompatible"
            is InstallFailure.Invalid -> "invalid"
            is InstallFailure.Storage -> "storage"
            is InstallFailure.Timeout -> "timeout"
            is InstallFailure.Exceptional -> "exceptional"
            is InstallFailure.Generic -> "generic"
            else -> "unknown"
        }
    }

    private val PM_ERROR_CODE_REGEX = Regex("""\b(INSTALL_(?:PARSE_)?FAILED_[A-Z0-9_]+)\b""")

    /**
     * Extracts a standard Android PackageManager error code (e.g. INSTALL_FAILED_VERSION_DOWNGRADE,
     * INSTALL_FAILED_INSUFFICIENT_STORAGE, INSTALL_FAILED_UPDATE_INCOMPATIBLE).
     *
     * Never returns file names or package names to preserve privacy.
     */
    fun extractErrorCode(failure: InstallFailure): String {
        if (isFrpFailure(failure)) {
            return "INSTALL_FAILED_SECURITY_FRP"
        }
        val rawMessage = failure.message.orEmpty()
        if (app.pwhs.universalinstaller.presentation.install.util.AbiCompatibilityHelper.isAbiErrorMessage(rawMessage)) {
            return "INSTALL_FAILED_CPU_ABI_INCOMPATIBLE"
        }
        val match = PM_ERROR_CODE_REGEX.find(rawMessage)
        if (match != null) {
            return match.groupValues[1]
        }
        return when (failure) {
            is InstallFailure.Aborted -> "INSTALL_FAILED_ABORTED"
            is InstallFailure.Storage -> "INSTALL_FAILED_INSUFFICIENT_STORAGE"
            is InstallFailure.Conflict -> {
                val upper = rawMessage.uppercase()
                if ("VERSION_DOWNGRADE" in upper) "INSTALL_FAILED_VERSION_DOWNGRADE"
                else "INSTALL_FAILED_UPDATE_INCOMPATIBLE"
            }
            is InstallFailure.Invalid -> "INSTALL_FAILED_INVALID_APK"
            is InstallFailure.Incompatible -> {
                val upper = rawMessage.uppercase()
                when {
                    "CPU_ABI" in upper || "NO_MATCHING_ABIS" in upper -> "INSTALL_FAILED_CPU_ABI_INCOMPATIBLE"
                    "OLDER_SDK" in upper -> "INSTALL_FAILED_OLDER_SDK"
                    "NEWER_SDK" in upper -> "INSTALL_FAILED_NEWER_SDK"
                    "FEATURE" in upper -> "INSTALL_FAILED_MISSING_FEATURE"
                    else -> "INSTALL_FAILED_INCOMPATIBLE"
                }
            }
            is InstallFailure.Blocked -> "INSTALL_FAILED_USER_RESTRICTED"
            is InstallFailure.Timeout -> "INSTALL_FAILED_VERIFICATION_TIMEOUT"
            is InstallFailure.Exceptional, is InstallFailure.Generic -> "INSTALL_FAILED_INTERNAL_ERROR"
            else -> "INSTALL_FAILED_UNKNOWN"
        }
    }

    /**
     * Classifies a failure into high-level technical categories for GA4 dimension reporting:
     * signature_mismatch, version_downgrade, insufficient_storage, corrupted_package,
     * incompatible_device, permission_denied, os_blocked, system_aborted, verification_timeout,
     * security_frp.
     */
    fun classifyErrorType(failure: InstallFailure, errorCode: String = extractErrorCode(failure)): String {
        if (isFrpFailure(failure) || errorCode == "INSTALL_FAILED_SECURITY_FRP" || errorCode.equals("security_frp", ignoreCase = true)) {
            return "security_frp"
        }
        val upperCode = errorCode.uppercase()
        val rawMessage = failure.message.orEmpty().uppercase()
        return when {
            "SIGNATURE" in upperCode || "UPDATE_INCOMPATIBLE" in upperCode || "CERTIFICATE" in upperCode || "SIGNATURES DO NOT MATCH" in rawMessage ->
                "signature_mismatch"
            "DOWNGRADE" in upperCode || "VERSION_DOWNGRADE" in rawMessage ->
                "version_downgrade"
            "STORAGE" in upperCode || failure is InstallFailure.Storage ->
                "insufficient_storage"
            "PARSE" in upperCode || "INVALID_APK" in upperCode || "BAD_MANIFEST" in upperCode || failure is InstallFailure.Invalid ->
                "corrupted_package"
            "ABI" in upperCode || "SDK" in upperCode || "FEATURE" in upperCode || failure is InstallFailure.Incompatible ->
                "incompatible_device"
            "RESTRICTED" in upperCode || "PERMISSION" in upperCode || failure is InstallFailure.Blocked ->
                "permission_denied"
            "ABORTED" in upperCode || failure is InstallFailure.Aborted ->
                "system_aborted"
            "TIMEOUT" in upperCode || failure is InstallFailure.Timeout ->
                "verification_timeout"
            else -> "os_blocked"
        }
    }
}
