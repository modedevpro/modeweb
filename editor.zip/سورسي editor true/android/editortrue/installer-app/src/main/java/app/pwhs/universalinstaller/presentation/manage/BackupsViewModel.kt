@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package app.pwhs.universalinstaller.presentation.manage

import app.pwhs.core.util.EditorTrueStorage
import app.pwhs.universalinstaller.presentation.manage.util.ManageExtractHelper


import android.app.Application
import android.content.pm.PackageManager
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.pwhs.universalinstaller.presentation.setting.PreferencesKeys
import app.pwhs.core.data.local.dataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class BackupFile(
    val file: File,
    val name: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val isSplitBundle: Boolean,
)


data class InstalledBackupApp(val packageName: String, val appName: String)

data class BackupBatchProgress(
    val completed: Int,
    val total: Int,
    val currentApp: String,
    val finished: Boolean = false,
    val succeeded: Int = 0,
    val failed: Int = 0,
)

data class BackupsUiState(
    val files: List<BackupFile> = emptyList(),
    val totalBytes: Long = 0L,
    val isLoading: Boolean = true,
    val extractorOutputPath: String = "",
    val extractorFilenameTemplate: String = "{name}-{version}",
    /** "apks" (default) or "xapk" — container for apps that have split APKs. */
    val extractorSplitFormat: String = "apks",
    val extractorIncludeObb: Boolean = false,
)

class BackupsViewModel(
    private val application: Application,
) : ViewModel() {

    private val dataStore = application.dataStore
    private val _filesState = MutableStateFlow<List<BackupFile>>(emptyList())
    private val _isLoading = MutableStateFlow(true)
    private val _installedApps = MutableStateFlow<List<InstalledBackupApp>>(emptyList())
    val installedApps: StateFlow<List<InstalledBackupApp>> = _installedApps
    private val _installedAppsLoading = MutableStateFlow(false)
    val installedAppsLoading: StateFlow<Boolean> = _installedAppsLoading
    private val _backupProgress = MutableStateFlow<BackupBatchProgress?>(null)
    val backupProgress: StateFlow<BackupBatchProgress?> = _backupProgress

    private data class ExtractorPrefs(
        val path: String,
        val template: String,
        val splitFormat: String,
        val includeObb: Boolean,
    )

    private val _extractorPrefs = dataStore.data.map { prefs ->
        ExtractorPrefs(
            path = EditorTrueStorage.installerBackups().absolutePath,
            template = prefs[PreferencesKeys.APK_EXTRACTOR_FILENAME_TEMPLATE] ?: "{name}-{version}",
            splitFormat = prefs[PreferencesKeys.APK_EXTRACTOR_SPLIT_FORMAT] ?: "apks",
            includeObb = prefs[PreferencesKeys.APK_EXTRACTOR_INCLUDE_OBB] ?: false,
        )
    }

    val uiState: StateFlow<BackupsUiState> = combine(
        _filesState,
        _isLoading,
        _extractorPrefs,
    ) { files, loading, prefs ->
        BackupsUiState(
            files = files,
            totalBytes = files.sumOf { it.sizeBytes },
            isLoading = loading,
            extractorOutputPath = prefs.path,
            extractorFilenameTemplate = prefs.template,
            extractorSplitFormat = prefs.splitFormat,
            extractorIncludeObb = prefs.includeObb,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BackupsUiState())

    init {
        refresh()
    }

    val backupsDir: File
        get() = EditorTrueStorage.installerBackups()

    fun loadInstalledApps() {
        if (_installedAppsLoading.value || _installedApps.value.isNotEmpty()) return
        viewModelScope.launch {
            _installedAppsLoading.value = true
            _installedApps.value = withContext(Dispatchers.IO) {
                val pm = application.packageManager
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    .map { info ->
                        val label = runCatching { info.loadLabel(pm).toString().trim() }
                            .getOrDefault(info.packageName)
                            .ifBlank { info.packageName }
                        InstalledBackupApp(info.packageName, label)
                    }
                    .distinctBy { it.packageName }
                    .sortedBy { it.appName.lowercase() }
            }
            _installedAppsLoading.value = false
        }
    }

    fun backupSelectedApps(selected: List<InstalledBackupApp>) {
        if (selected.isEmpty() || _backupProgress.value?.finished == false) return
        viewModelScope.launch {
            var succeeded = 0
            var failed = 0
            selected.forEachIndexed { index, app ->
                _backupProgress.value = BackupBatchProgress(
                    completed = index,
                    total = selected.size,
                    currentApp = app.appName,
                    succeeded = succeeded,
                    failed = failed,
                )
                val result = runCatching {
                    ManageExtractHelper.extractApp(
                        context = application,
                        packageName = app.packageName,
                        appName = app.appName,
                        mode = ExtractMode.Backup,
                        outputDir = null,
                    ) { _, _ -> }
                }.getOrNull()
                if (result is ExtractState.Done) succeeded++ else failed++
                _backupProgress.value = BackupBatchProgress(
                    completed = index + 1,
                    total = selected.size,
                    currentApp = app.appName,
                    succeeded = succeeded,
                    failed = failed,
                )
            }
            _backupProgress.value = BackupBatchProgress(
                completed = selected.size,
                total = selected.size,
                currentApp = "",
                finished = true,
                succeeded = succeeded,
                failed = failed,
            )
            refresh()
        }
    }

    fun dismissBackupProgress() {
        _backupProgress.value = null
    }

    fun refresh() {
        viewModelScope.launch {
            _isLoading.value = true
            val files = withContext(Dispatchers.IO) {
                val dir = backupsDir
                if (!dir.exists()) return@withContext emptyList()
                dir.listFiles()
                    ?.filter { it.isFile && it.extension.lowercase() in apkExtensions }
                    ?.sortedByDescending { it.lastModified() }
                    ?.map {
                        BackupFile(
                            file = it,
                            name = it.name,
                            sizeBytes = it.length(),
                            lastModified = it.lastModified(),
                            isSplitBundle = it.extension.lowercase() in splitExtensions,
                        )
                    }
                    ?: emptyList()
            }
            _filesState.value = files
            _isLoading.value = false
        }
    }

    fun setExtractorOutputPath(path: String) {
        viewModelScope.launch {
            if (path.startsWith("content://")) {
                runCatching {
                    application.contentResolver.takePersistableUriPermission(
                        android.net.Uri.parse(path),
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
            }
            dataStore.edit { prefs -> prefs[PreferencesKeys.APK_EXTRACTOR_OUTPUT_PATH] = path }
        }
    }

    fun setExtractorFilenameTemplate(template: String) {
        viewModelScope.launch {
            dataStore.edit { prefs -> prefs[PreferencesKeys.APK_EXTRACTOR_FILENAME_TEMPLATE] = template }
        }
    }

    fun setExtractorSplitFormat(format: String) {
        viewModelScope.launch {
            dataStore.edit { prefs -> prefs[PreferencesKeys.APK_EXTRACTOR_SPLIT_FORMAT] = format }
        }
    }

    fun setExtractorIncludeObb(enabled: Boolean) {
        viewModelScope.launch {
            dataStore.edit { prefs -> prefs[PreferencesKeys.APK_EXTRACTOR_INCLUDE_OBB] = enabled }
        }
    }

    fun delete(backup: BackupFile) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { backup.file.delete() } }
            refresh()
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                _filesState.value.forEach { runCatching { it.file.delete() } }
            }
            refresh()
        }
    }

    private companion object {
        val apkExtensions = setOf("apk", "apks", "xapk", "apkm")
        val splitExtensions = setOf("apks", "xapk", "apkm")
    }
}
