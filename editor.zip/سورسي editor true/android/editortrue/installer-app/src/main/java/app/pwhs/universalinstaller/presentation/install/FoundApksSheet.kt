package app.pwhs.universalinstaller.presentation.install

import android.text.format.Formatter
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderOff
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TriStateCheckbox
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import app.pwhs.universalinstaller.R
import app.pwhs.universalinstaller.presentation.install.components.FoundApkFilter
import app.pwhs.universalinstaller.presentation.install.components.FoundApksFilterRow
import app.pwhs.universalinstaller.presentation.install.components.FoundRow
import app.pwhs.universalinstaller.presentation.install.components.PermissionBody
import app.pwhs.universalinstaller.presentation.install.components.ScanningBody
import app.pwhs.universalinstaller.presentation.install.components.SheetHeader
import app.pwhs.universalinstaller.presentation.install.components.filterFoundFiles
import app.pwhs.core.ui.ApkFileIconData
import app.pwhs.core.util.PermissionMonitor
import coil3.compose.SubcomposeAsyncImage
import coil3.compose.SubcomposeAsyncImageContent
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun FoundApksSheet(
    scanState: ScanState,
    onDismiss: () -> Unit,
    onGrantPermission: () -> Unit,
    onRescan: () -> Unit,
    onPick: (FoundPackageFile) -> Unit,
    onPickMany: (List<FoundPackageFile>) -> Unit,
    onDeleteMany: (List<FoundPackageFile>) -> Unit,
) {
    if (scanState is ScanState.Idle) return
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val isProtected = scanState is ScanState.Scanning || scanState is ScanState.Ready
    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = true,
        confirmValueChange = { targetValue ->
            if (targetValue == SheetValue.Hidden) {
                !isProtected
            } else {
                true
            }
        },
    )

    LifecycleResumeEffect(Unit) {
        PermissionMonitor.stop()
        onPauseOrDispose {}
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    ) {
        // Intentionally no horizontal padding on the outer Column — each body applies its
        // own so the Ready state's bottom bar can span edge-to-edge.
        Column(modifier = Modifier.fillMaxWidth()) {
            SheetHeader(scanState = scanState, onRescan = onRescan, onDismiss = onDismiss)
            Spacer(Modifier.height(16.dp))
            when (scanState) {
                is ScanState.PermissionNeeded -> PermissionBody(
                    onGrant = {
                        if (activity != null) {
                            PermissionMonitor.start(activity) {
                                ApkScanner.hasAllFilesAccess(context)
                            }
                        }
                        onGrantPermission()
                    }
                )
                is ScanState.Scanning -> ScanningBody(scanState)
                is ScanState.Ready -> ResultsBody(
                    files = scanState.files,
                    onPickOne = onPick,
                    onPickMany = onPickMany,
                    onDeleteMany = onDeleteMany,
                )
                ScanState.Idle -> Unit
            }
        }
    }
}


@Composable
private fun ResultsBody(
    files: List<FoundPackageFile>,
    onPickOne: (FoundPackageFile) -> Unit,
    onPickMany: (List<FoundPackageFile>) -> Unit,
    onDeleteMany: (List<FoundPackageFile>) -> Unit,
) {
    val context = LocalContext.current
    if (files.isEmpty()) {
        Text(
            text = stringResource(R.string.find_auto_empty),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 32.dp),
            textAlign = TextAlign.Center,
        )
        return
    }

    // Selection lives inside the sheet — no need to hoist to the VM since it's transient
    // UI state that resets every time the sheet opens.
    var selected by remember(files) { mutableStateOf(setOf<String>()) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var activeFilter by rememberSaveable { mutableStateOf(FoundApkFilter.All) }
    val keyboardController = LocalSoftwareKeyboardController.current

    // Debounce the active filter so each keystroke doesn't re-filter a list that can
    // realistically have 1000+ files. The user keeps typing into `searchQuery`; the
    // expensive `.filter { contains }` only runs against `debouncedQuery`.
    var debouncedQuery by remember { mutableStateOf(searchQuery) }
    LaunchedEffect(searchQuery) {
        if (searchQuery.isBlank()) {
            debouncedQuery = ""
        } else {
            kotlinx.coroutines.delay(300)
            debouncedQuery = searchQuery
        }
    }

    // Filter files based on the debounced query and active filter chip.
    val filteredFiles = remember(files, debouncedQuery, activeFilter) {
        filterFoundFiles(files, debouncedQuery, activeFilter)
    }

    val selectedFiles = files.filter { it.path in selected }
    val selectedBytes = selectedFiles.sumOf { it.sizeBytes.coerceAtLeast(0L) }
    val hasSelection = selected.isNotEmpty()

    androidx.activity.compose.BackHandler(enabled = hasSelection) {
        selected = emptySet()
    }

    // Toggle state considers only visible (filtered) files.
    val filteredSelected = filteredFiles.count { it.path in selected }
    val toggleState = when {
        filteredFiles.isEmpty() -> ToggleableState.Off
        filteredSelected == 0 -> ToggleableState.Off
        filteredSelected == filteredFiles.size -> ToggleableState.On
        else -> ToggleableState.Indeterminate
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // ── Search bar ──────────────────────────────────────
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            placeholder = {
                Text(
                    text = stringResource(R.string.find_auto_search_hint),
                    style = MaterialTheme.typography.bodyMedium,
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            },
            trailingIcon = {
                AnimatedVisibility(
                    visible = searchQuery.isNotEmpty(),
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Rounded.Clear,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
            textStyle = MaterialTheme.typography.bodyMedium,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() }),
        )
        Spacer(Modifier.height(8.dp))

        // ── Filter chips ────────────────────────────────────
        FoundApksFilterRow(
            allFiles = files,
            activeFilter = activeFilter,
            onFilterSelected = { activeFilter = it },
        )
        Spacer(Modifier.height(4.dp))

        // Select-all row: toggles only the currently visible (filtered) items.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TriStateCheckbox(
                state = toggleState,
                onClick = {
                    val visiblePaths = filteredFiles.map { it.path }.toSet()
                    selected = if (toggleState == ToggleableState.On) {
                        selected - visiblePaths
                    } else {
                        selected + visiblePaths
                    }
                },
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = if (searchQuery.isBlank() && activeFilter == FoundApkFilter.All) "${selected.size} / ${files.size}"
                       else "${filteredSelected} / ${filteredFiles.size}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
        Spacer(Modifier.height(4.dp))

        if (filteredFiles.isEmpty() && (searchQuery.isNotBlank() || activeFilter != FoundApkFilter.All)) {
            // No matches — show empty state.
            Text(
                text = if (searchQuery.isNotBlank()) stringResource(R.string.find_auto_no_match, searchQuery)
                       else stringResource(R.string.find_auto_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                textAlign = TextAlign.Center,
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
            ) {
                items(filteredFiles, key = { it.path }) { file ->
                    FoundRow(
                        file = file,
                        selected = file.path in selected,
                        onToggle = {
                            selected = if (file.path in selected) selected - file.path
                                       else selected + file.path
                        },
                    )
                }
            }
        }

        // Edge-to-edge action bar: parent Column has no horizontal padding, so this Surface
        // fills the full sheet width. Inner Row adds its own padding.
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceContainer,
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (hasSelection) {
                            "${selected.size} · ${Formatter.formatShortFileSize(context, selectedBytes)}"
                        } else {
                            stringResource(R.string.find_auto_count, files.size)
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
                FilledTonalIconButton(
                    onClick = { showDeleteDialog = true },
                    enabled = hasSelection,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                    ),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = stringResource(R.string.find_auto_delete),
                    )
                }
                Button(
                    onClick = {
                        when (selected.size) {
                            0 -> Unit
                            1 -> onPickOne(selectedFiles.first())
                            else -> onPickMany(selectedFiles)
                        }
                    },
                    enabled = hasSelection,
                    shape = MaterialTheme.shapes.medium,
                    contentPadding = ButtonDefaults.ButtonWithIconContentPadding,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.InstallMobile,
                        contentDescription = null,
                        modifier = Modifier.size(ButtonDefaults.IconSize),
                    )
                    Spacer(Modifier.width(ButtonDefaults.IconSpacing))
                    Text(
                        text = if (selected.size <= 1) {
                            stringResource(R.string.find_auto_install_single)
                        } else {
                            stringResource(R.string.find_auto_install_selected, selected.size)
                        },
                    )
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = {
                Text(stringResource(R.string.find_auto_delete_title, selectedFiles.size))
            },
            text = {
                Text(stringResource(R.string.find_auto_delete_message))
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    selected = emptySet()
                    onDeleteMany(selectedFiles)
                }) {
                    Text(
                        text = stringResource(R.string.find_auto_delete_confirm),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(stringResource(R.string.universal_installer_cancel))
                }
            },
        )
    }
}

