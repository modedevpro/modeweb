@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package app.pwhs.universalinstaller.presentation.manage

import app.pwhs.core.util.EditorTrueStorage


import android.content.Intent
import android.net.Uri
import android.text.format.DateUtils
import android.text.format.Formatter
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Button
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import app.pwhs.universalinstaller.R
import app.pwhs.universalinstaller.presentation.composable.SettingsSection
import app.pwhs.universalinstaller.presentation.manage.components.BackupsSettingsSheet
import app.pwhs.core.ui.ApkFileIconData
import coil3.compose.SubcomposeAsyncImage
import coil3.compose.SubcomposeAsyncImageContent
import coil3.request.ImageRequest
import org.koin.androidx.compose.koinViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupsScreen(
    modifier: Modifier = Modifier,
    viewModel: BackupsViewModel = koinViewModel(),
    onBack: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var pendingDeleteAll by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<BackupFile?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showInstalledPicker by remember { mutableStateOf(false) }
    var installedSearch by remember { mutableStateOf("") }
    var selectedInstalledPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    val installedApps by viewModel.installedApps.collectAsState()
    val installedAppsLoading by viewModel.installedAppsLoading.collectAsState()
    val backupProgress by viewModel.backupProgress.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val pickerSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Scaffold(
        modifier = modifier,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.screen_title_backups))
                        if (uiState.files.isNotEmpty()) {
                            Text(
                                text = stringResource(
                                    R.string.backups_count_size,
                                    uiState.files.size,
                                    Formatter.formatShortFileSize(context, uiState.totalBytes),
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = stringResource(R.string.universal_installer_cancel),
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        selectedInstalledPackages = emptySet()
                        installedSearch = ""
                        viewModel.loadInstalledApps()
                        showInstalledPicker = true
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Android,
                            contentDescription = stringResource(R.string.backup_choose_installed_apps_action),
                        )
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Extraction Settings",
                        )
                    }
                    IconButton(
                        onClick = {
                            openContainingFolder(
                                context = context,
                                customPath = uiState.extractorOutputPath,
                                fallbackDir = viewModel.backupsDir,
                            )
                        },
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FolderOpen,
                            contentDescription = stringResource(R.string.backup_action_open_folder),
                        )
                    }
                    if (uiState.files.isNotEmpty()) {
                        IconButton(onClick = { pendingDeleteAll = true }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteSweep,
                                contentDescription = stringResource(R.string.backup_action_delete_all),
                            )
                        }
                    }
                },
            )
        },
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center,
                ) { CircularProgressIndicator() }
            }
            uiState.files.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.backups_empty),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(onClick = {
                            selectedInstalledPackages = emptySet()
                            installedSearch = ""
                            viewModel.loadInstalledApps()
                            showInstalledPicker = true
                        }) {
                            Text(stringResource(R.string.backup_choose_installed_apps_action))
                        }
                    }
                }
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(bottom = navBarPadding + 16.dp)
                ) {
                    items(items = uiState.files, key = { it.file.absolutePath }) { backup ->
                        BackupRow(
                            backup = backup,
                            onInstall = { installBackup(context, backup.file) },
                            onShare = { shareBackup(context, backup.file) },
                            onDelete = { pendingDelete = backup },
                        )
                    }
                }
            }
        }
    }

    if (showSettings) {
        BackupsSettingsSheet(
            uiState = uiState,
            sheetState = sheetState,
            onDismiss = { showSettings = false },
            onSetFilenameTemplate = viewModel::setExtractorFilenameTemplate,
            onSetSplitFormat = viewModel::setExtractorSplitFormat,
            onSetIncludeObb = viewModel::setExtractorIncludeObb,
        )
    }

    if (showInstalledPicker) {
        val visibleApps = installedApps.filter { app ->
            installedSearch.isBlank() || app.appName.contains(installedSearch, ignoreCase = true) ||
                app.packageName.contains(installedSearch, ignoreCase = true)
        }
        ModalBottomSheet(
            onDismissRequest = { showInstalledPicker = false },
            sheetState = pickerSheetState,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.82f)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        stringResource(R.string.backup_choose_installed_apps_title),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    TextButton(onClick = {
                        val visiblePackages = visibleApps.map { it.packageName }.toSet()
                        selectedInstalledPackages = if (selectedInstalledPackages.containsAll(visiblePackages)) {
                            selectedInstalledPackages - visiblePackages
                        } else {
                            selectedInstalledPackages + visiblePackages
                        }
                    }) {
                        Text(stringResource(R.string.backup_select_all))
                    }
                }
                OutlinedTextField(
                    value = installedSearch,
                    onValueChange = { installedSearch = it },
                    label = { Text(stringResource(R.string.backup_search_apps)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                when {
                    installedAppsLoading -> Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center,
                    ) { CircularProgressIndicator() }
                    visibleApps.isEmpty() -> Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center,
                    ) { Text(stringResource(R.string.backup_no_apps)) }
                    else -> LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        items(items = visibleApps, key = { it.packageName }) { app ->
                            val checked = app.packageName in selectedInstalledPackages
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedInstalledPackages = if (checked) {
                                            selectedInstalledPackages - app.packageName
                                        } else {
                                            selectedInstalledPackages + app.packageName
                                        }
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { selected ->
                                        selectedInstalledPackages = if (selected) {
                                            selectedInstalledPackages + app.packageName
                                        } else {
                                            selectedInstalledPackages - app.packageName
                                        }
                                    },
                                )
                                Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                                    Text(app.appName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        app.packageName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
                Button(
                    onClick = {
                        val selected = installedApps.filter { it.packageName in selectedInstalledPackages }
                        showInstalledPicker = false
                        viewModel.backupSelectedApps(selected)
                    },
                    enabled = selectedInstalledPackages.isNotEmpty() && !installedAppsLoading,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(stringResource(R.string.backup_start_selected, selectedInstalledPackages.size))
                }
            }
        }
    }

    backupProgress?.let { progress ->
        AlertDialog(
            onDismissRequest = { if (progress.finished) viewModel.dismissBackupProgress() },
            title = { Text(stringResource(R.string.backup_choose_installed_apps_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (!progress.finished) {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                        Text(stringResource(R.string.backup_batch_progress, minOf(progress.completed + 1, progress.total), progress.total, progress.currentApp))
                    } else {
                        Text(stringResource(R.string.backup_batch_result, progress.succeeded, progress.failed))
                    }
                }
            },
            confirmButton = {
                if (progress.finished) TextButton(onClick = viewModel::dismissBackupProgress) {
                    Text(stringResource(R.string.dialog_success_done))
                }
            },
        )
    }

    if (pendingDeleteAll) {
        AlertDialog(
            onDismissRequest = { pendingDeleteAll = false },
            title = { Text(stringResource(R.string.backup_delete_all_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.backup_delete_all_msg,
                        uiState.files.size,
                    ),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAll()
                        pendingDeleteAll = false
                    },
                ) { Text(stringResource(R.string.backup_action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteAll = false }) {
                    Text(stringResource(R.string.universal_installer_cancel))
                }
            },
        )
    }

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.backup_delete_one_title)) },
            text = { Text(target.name) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.delete(target)
                        pendingDelete = null
                    },
                ) { Text(stringResource(R.string.backup_action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text(stringResource(R.string.universal_installer_cancel))
                }
            },
        )
    }
}

@Composable
private fun BackupRow(
    backup: BackupFile,
    onInstall: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    ListItem(
        headlineContent = {
            Text(backup.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        supportingContent = {
            Text(
                text = "${Formatter.formatShortFileSize(context, backup.sizeBytes)} · " +
                    DateUtils.getRelativeTimeSpanString(
                        backup.lastModified,
                        System.currentTimeMillis(),
                        DateUtils.MINUTE_IN_MILLIS,
                    ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
        leadingContent = {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(context)
                    .data(ApkFileIconData(backup.file.absolutePath))
                    .build(),
                contentDescription = backup.name,
                modifier = Modifier.size(40.dp),
                error = {
                    // Parse failed (corrupt APK, missing base.apk in split bundle, etc.) —
                    // fall back to a generic icon that still hints at the file type.
                    Icon(
                        imageVector = if (backup.isSplitBundle) Icons.Rounded.FolderZip
                            else Icons.Rounded.Android,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                },
                success = { SubcomposeAsyncImageContent() },
            )
        },
        trailingContent = {
            androidx.compose.foundation.layout.Row {
                IconButton(onClick = onInstall) {
                    Icon(
                        imageVector = Icons.Rounded.InstallMobile,
                        contentDescription = stringResource(R.string.backup_action_install),
                    )
                }
                IconButton(onClick = onShare) {
                    Icon(
                        imageVector = Icons.Rounded.Share,
                        contentDescription = stringResource(R.string.backup_action_share),
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = stringResource(R.string.backup_action_delete),
                    )
                }
            }
        },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
    )
}

/** Route the backup file back through our own install pipeline (MainActivity intent filter). */
private fun installBackup(context: android.content.Context, file: File) {
    val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.installer.fileprovider",
        file,
    )
    val mime = "application/vnd.android.package-archive"
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        setPackage(context.packageName)
    }
    runCatching { context.startActivity(intent) }
}

private fun shareBackup(context: android.content.Context, file: File) {
    val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.installer.fileprovider",
        file,
    )
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.android.package-archive"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching {
        context.startActivity(Intent.createChooser(intent, null))
    }
}

private fun openContainingFolder(
    context: android.content.Context,
    customPath: String,
    fallbackDir: File,
) {
    if (customPath.startsWith("content://")) {
        val treeUri = Uri.parse(customPath)
        val docUri = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)?.uri ?: treeUri
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(docUri, "vnd.android.document/directory")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (runCatching { context.startActivity(intent) }.isSuccess) return
    }

    val targetDir = if (customPath.isNotBlank() && !customPath.startsWith("content://")) {
        File(customPath)
    } else {
        fallbackDir
    }
    if (!targetDir.exists()) targetDir.mkdirs()

    val absPath = targetDir.absolutePath
    val primaryPrefix = "/storage/emulated/0/"
    val relativePath = if (absPath.startsWith(primaryPrefix)) {
        absPath.removePrefix(primaryPrefix)
    } else {
        EditorTrueStorage.installerBackups().absolutePath.removePrefix(primaryPrefix)
    }

    val safUri = Uri.parse("content://com.android.externalstorage.documents/document/" + Uri.encode("primary:$relativePath"))
    val safRootUri = Uri.parse("content://com.android.externalstorage.documents/root/primary")

    // 1. Try opening the specific directory via DocumentsUI SAF
    val directoryIntent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(safUri, "vnd.android.document/directory")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    if (runCatching { context.startActivity(directoryIntent) }.isSuccess) return

    // 2. Try root documents provider
    val rootIntent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(safRootUri, "vnd.android.document/root")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    if (runCatching { context.startActivity(rootIntent) }.isSuccess) return

    // 3. Fallback: Downloads system browser
    val downloadsIntent = Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    if (runCatching { context.startActivity(downloadsIntent) }.isSuccess) return

    // 4. Fallback: File picker chooser
    val chooserIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
        type = "*/*"
        addCategory(Intent.CATEGORY_OPENABLE)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching {
        context.startActivity(Intent.createChooser(chooserIntent, context.getString(R.string.backup_action_open_folder)))
    }
}
