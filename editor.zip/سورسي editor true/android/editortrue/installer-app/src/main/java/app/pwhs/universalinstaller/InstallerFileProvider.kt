package app.pwhs.universalinstaller

/** Separate authority for Universal Installer file sharing; EditorTrue keeps its own provider. */
class InstallerFileProvider : androidx.core.content.FileProvider()
