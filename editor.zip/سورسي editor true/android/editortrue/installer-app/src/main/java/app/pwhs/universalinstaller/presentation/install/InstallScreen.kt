package app.pwhs.universalinstaller.presentation.install

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import app.pwhs.universalinstaller.presentation.setting.PreferencesKeys
import app.pwhs.universalinstaller.presentation.setting.SecurityLevel
import app.pwhs.core.data.local.dataStore
import app.pwhs.universalinstaller.presentation.install.util.PackageFileFilter
import app.pwhs.universalinstaller.presentation.install.wear.WearApkSender
import app.pwhs.universalinstaller.util.BiometricGate
import kotlinx.coroutines.flow.map
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Watch
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalResources
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.pwhs.universalinstaller.IntentHandoff
import app.pwhs.universalinstaller.R
import app.pwhs.universalinstaller.data.local.InstallHistoryEntity
import app.pwhs.universalinstaller.presentation.composable.InstallerModeBadge
import app.pwhs.universalinstaller.presentation.composable.SessionCard
import app.pwhs.universalinstaller.presentation.install.components.ShizukuPromoBanner
import app.pwhs.universalinstaller.util.extension.getDisplayName
import org.koin.androidx.compose.koinViewModel
import ru.solrudev.ackpine.splits.ApkSplits.validate
import ru.solrudev.ackpine.splits.SplitPackage
import ru.solrudev.ackpine.splits.SplitPackage.Companion.toSplitPackage
import ru.solrudev.ackpine.splits.ZippedApkSplits
import timber.log.Timber

@Composable
fun InstallScreen(
    modifier: Modifier = Modifier,
    viewModel: InstallViewModel = koinViewModel(),
    onMergeSplits: ((Uri) -> Unit)? = null,
) {
    val context = LocalContext.current
    val resource = LocalResources.current
    val uiState by viewModel.uiState.collectAsState()
    val history by viewModel.history.collectAsState()
    val installGateEnabled by remember(context) {
        // Read the Settings toggle as a Flow so a change in Settings applies on the next
        // confirm without restarting the screen.
        context.dataStore.data.map {
            it[PreferencesKeys.BIOMETRIC_LOCK_INSTALL] ?: false
        }
    }.collectAsState(initial = false)

    val showDownloadTab by remember(context) {
        context.dataStore.data.map {
            it[PreferencesKeys.SHOW_DOWNLOAD_TAB] ?: true
        }
    }.collectAsState(initial = true)

    val deleteApkAfterInstall by remember(context) {
        context.dataStore.data.map {
            it[PreferencesKeys.DELETE_APK_AFTER_INSTALL] ?: false
        }
    }.collectAsState(initial = false)
    var keepApk by rememberSaveable { mutableStateOf(false) }

    // Strict is the only level that treats an unscanned file as a risk and lets the Scan button
    // take the primary slot; Normal keeps VirusTotal available without pushing it.
    val strictVirusTotalCheck by remember(context) {
        context.dataStore.data.map {
            SecurityLevel.from(
                stored = it[PreferencesKeys.SECURITY_LEVEL],
                legacyStrict = it[PreferencesKeys.STRICT_VIRUSTOTAL_CHECK] ?: false,
            ) == SecurityLevel.Strict
        }
    }.collectAsState(initial = false)

    // Risk consent gate — populated when the user taps Install on a downgrade or
    // a VirusTotal-flagged APK. We render an AlertDialog over the rest of the screen
    // and only proceed to the biometric gate + confirmInstall after they acknowledge.
    var pendingRisks by remember { mutableStateOf<List<app.pwhs.universalinstaller.presentation.install.dialog.InstallRisk>>(emptyList()) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val securityGate = app.pwhs.universalinstaller.presentation.install.util.rememberInstallSecurityGate(
        context = context,
        onCancel = viewModel::dismissPendingInstall,
    )

    if (pendingRisks.isNotEmpty()) {
        app.pwhs.universalinstaller.presentation.install.dialog.RiskConfirmDialog(
            risks = pendingRisks,
            onConfirm = {
                pendingRisks = emptyList()
                val action = pendingAction
                pendingAction = null
                if (action != null) {
                    securityGate.authenticate(action)
                }
            },
            onCancel = {
                pendingRisks = emptyList()
                pendingAction = null
                viewModel.dismissPendingInstall()
            },
            onPrivilegedUninstall = viewModel::uninstallConflictingApp,
            onExistingAppUninstalled = {
                viewModel.onConflictingAppUninstalled()
                // Both of these only existed because the old copy was installed. Dropping them
                // closes the dialog when nothing else is left to warn about.
                pendingRisks = pendingRisks.filterNot {
                    it is app.pwhs.universalinstaller.presentation.install.dialog.InstallRisk.SignatureMismatch ||
                        it is app.pwhs.universalinstaller.presentation.install.dialog.InstallRisk.Downgrade
                }
            },
        )
    }

    val watchName by viewModel.watchName.collectAsState()
    val isLookingUpWatch by viewModel.isLookingUpWatch.collectAsState()
    val watchApkScanState by viewModel.watchApkScanState.collectAsState()
    // Re-checked on every resume so putting the watch on after opening the app still registers.
    if (WearApkSender.isAvailable) {
        LifecycleResumeEffect(Unit) {
            viewModel.refreshWatch()
            onPauseOrDispose {}
        }
    }

    val pendingOriginalUri = viewModel.pendingOriginalUri
    val canMerge = uiState.pendingApkInfo?.splitEntries?.isNotEmpty() == true && pendingOriginalUri != null
    val onMerge: (() -> Unit)? = if (canMerge) {
        {
            if (pendingOriginalUri != null) {
                if (onMergeSplits != null) {
                    onMergeSplits(pendingOriginalUri)
                } else {
                    (context as? InstallActivity)?.requestMergeExternalFile(pendingOriginalUri)
                }
            }
        }
    } else null

    InstallUi(
        modifier = modifier,
        uiState = uiState,
        history = history,
        showDownloadTab = showDownloadTab,
        onFilePicked = { uri, splitPackage, fileName ->
            viewModel.parseApkInfo(context, uri, splitPackage, fileName)
        },
        onDownloadFromUrl = { url -> viewModel.downloadFromUrl(context, url) },
        onCancelDownload = viewModel::cancelDownload,
        onDismissDownloadError = viewModel::dismissDownloadError,
        onConfirmInstall = {
            // Risk gate FIRST so the user sees what they're acknowledging — biometric
            // prompts that follow then feel like a confirmation of an explicit choice
            // rather than a surprise after fingerprint auth completes.
            val info = uiState.pendingApkInfo
            val risks = if (info != null) {
                app.pwhs.universalinstaller.presentation.install.dialog.detectInstallRisks(info, strictVirusTotalCheck)
            } else emptyList()
            if (risks.isNotEmpty()) {
                pendingRisks = risks
                pendingAction = {
                    val keep = keepApk
                    keepApk = false
                    viewModel.confirmInstall(keepApk = keep)
                }
            } else {
                securityGate.authenticate {
                    val keep = keepApk
                    keepApk = false
                    viewModel.confirmInstall(keepApk = keep)
                }
            }
        },
        onDismissPreview = {
            keepApk = false
            viewModel.dismissPendingInstall()
        },
        onCancel = viewModel::cancelSession,
        onRetry = viewModel::retrySession,
        onDismissSession = viewModel::dismissSession,
        showKeepApkOption = deleteApkAfterInstall,
        keepApk = keepApk,
        onKeepApkChanged = { keepApk = it },
        onUnblock = viewModel::unblockPackage,
        strictSecurity = strictVirusTotalCheck,
        onClearHistory = viewModel::clearHistory,
        onMergeSplits = onMerge,
        onCheckVirusTotal = { viewModel.scanVirusTotal(context) },
        onStartDeviceScan = { viewModel.startDeviceScan(context) },
        onDismissDeviceScan = viewModel::dismissDeviceScan,
        onPickFromScan = { found -> viewModel.pickFromScan(context, found) },
        onPickManyFromScan = { found -> viewModel.pickManyFromScan(context, found) },
        onDeleteScannedFiles = { found -> viewModel.deleteFoundFiles(context, found) },
        onDismissObbCopy = viewModel::dismissObbCopy,
        onAttachObb = { uri -> viewModel.attachObbFile(context, uri) },
        onRemoveObb = { obb -> viewModel.removeAttachedObb(obb.uri) },
        onGrantObbFolder = viewModel::onObbTreeGranted,
        obbTreeHintUri = viewModel::obbTreeHintUri,
        onOpenDownloadHistory = {
            context.startActivity(android.content.Intent(context, app.pwhs.universalinstaller.presentation.download.DownloadHistoryActivity::class.java))
        },
        onBatchPicked = { uris -> viewModel.parseBatch(context, uris) },
        onBatchToggleEntry = viewModel::toggleBatchSelection,
        onBatchToggleAll = viewModel::setBatchAllSelected,
        onBatchConfirm = {
            val ready = uiState.batchState as? BatchInstallState.Ready
            if (ready != null) {
                val picked = ready.entries.filter { it.selected && it.splitUris.isNotEmpty() }
                val risks = picked.flatMap { 
                    app.pwhs.universalinstaller.presentation.install.dialog.detectInstallRisks(it.apkInfo, strictVirusTotalCheck) 
                }.distinct()
                
                if (risks.isNotEmpty()) {
                    pendingRisks = risks
                    pendingAction = viewModel::confirmBatchInstall
                } else {
                    viewModel.confirmBatchInstall()
                }
            }
        },
        onBatchDismiss = viewModel::dismissBatchInstall,
        onSkipBatchParse = viewModel::skipBatchParseAndInstall,
        onSkipParseSingle = viewModel::skipParseAndInstallSingle,
        onToggleSplit = viewModel::toggleSplit,
        onOpenSyncServer = {
            context.startActivity(android.content.Intent(context, app.pwhs.universalinstaller.presentation.sync.SyncActivity::class.java))
        },
        onSetMergeSplits = viewModel::setMergeSplits,
        onOpenBatchDetail = viewModel::openBatchDetail,
        onCloseBatchDetail = viewModel::closeBatchDetail,
        onSaveBatchDetail = viewModel::saveBatchDetail,
        onProfileSelected = { profile ->
            // selectProfile accepts null, so "None" in the batch picker clears the selection.
            viewModel.selectProfile(profile?.id)
        },
        onMappingChanged = viewModel::setAppProfileMapping,
        onToggleAllUsers = viewModel::setAllUsers,
        onSelectUserId = viewModel::setUserId,
        onSendToWatch = { uri, name -> viewModel.sendToWatch(uri, name) },
        onSendFoundToWatch = { found -> viewModel.sendFoundFileToWatch(context, found) },
        onRefreshWatch = viewModel::refreshWatch,
        onScanApksForWatch = viewModel::scanApksForWatch,
        watchName = watchName,
        isLookingUpWatch = isLookingUpWatch,
        watchApkScanState = watchApkScanState,
    )

    val storageWarning by viewModel.storageWarningInfo.collectAsState()
    storageWarning?.let { warning ->
        app.pwhs.universalinstaller.presentation.install.dialog.InsufficientStorageDialog(
            warningInfo = warning,
            onDismiss = viewModel::dismissStorageWarning,
        )
    }

    // Watch send status dialog
    WatchSendDialog(
        state = uiState.watchSendState,
        onDismiss = viewModel::dismissWatchSend,
        onCancel = viewModel::cancelWatchSend,
        onConfirmSend = viewModel::confirmSendToWatch,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InstallUi(
    modifier: Modifier = Modifier,
    uiState: InstallUiState = InstallUiState(),
    history: List<InstallHistoryEntity> = emptyList(),
    showDownloadTab: Boolean = true,
    onMergeSplits: (() -> Unit)? = null,
    onFilePicked: (uri: Uri, splitPackage: SplitPackage.Provider, fileName: String) -> Unit = { _, _, _ -> },
    onDownloadFromUrl: (String) -> Unit = {},
    onCancelDownload: () -> Unit = {},
    onDismissDownloadError: () -> Unit = {},
    onConfirmInstall: () -> Unit = {},
    onDismissPreview: () -> Unit = {},
    onCancel: (java.util.UUID) -> Unit = {},
    onRetry: (java.util.UUID) -> Unit = {},
    onDismissSession: (java.util.UUID) -> Unit = {},
    showKeepApkOption: Boolean = false,
    keepApk: Boolean = false,
    onKeepApkChanged: (Boolean) -> Unit = {},
    onUnblock: (String) -> Unit = {},
    strictSecurity: Boolean = false,
    onClearHistory: () -> Unit = {},
    onCheckVirusTotal: () -> Unit = {},
    onStartDeviceScan: () -> Unit = {},
    onDismissDeviceScan: () -> Unit = {},
    onPickFromScan: (FoundPackageFile) -> Unit = {},
    onPickManyFromScan: (List<FoundPackageFile>) -> Unit = {},
    onDeleteScannedFiles: (List<FoundPackageFile>) -> Unit = {},
    onDismissObbCopy: () -> Unit = {},
    onAttachObb: (Uri) -> Unit = {},
    onRemoveObb: (AttachedObb) -> Unit = {},
    onGrantObbFolder: (Uri?) -> Unit = {},
    obbTreeHintUri: () -> Uri? = { null },
    onOpenDownloadHistory: () -> Unit = {},
    onBatchPicked: (List<Uri>) -> Unit = {},
    onBatchToggleEntry: (Uri) -> Unit = {},
    onBatchToggleAll: (Boolean) -> Unit = {},
    onBatchConfirm: () -> Unit = {},
    onBatchDismiss: () -> Unit = {},
    onSkipBatchParse: () -> Unit = {},
    onSkipParseSingle: () -> Unit = {},
    onToggleSplit: (Int) -> Unit = {},
    onOpenSyncServer: () -> Unit = {},
    onSetMergeSplits: (Boolean) -> Unit = { },
    onProfileSelected: (app.pwhs.universalinstaller.domain.model.InstallerProfile?) -> Unit = {},
    onMappingChanged: (String, String?) -> Unit = { _, _ -> },
    onToggleAllUsers: (Boolean) -> Unit = {},
    onSelectUserId: (Int?) -> Unit = {},
    onOpenBatchDetail: (Uri) -> Unit = {},
    onCloseBatchDetail: () -> Unit = {},
    onSaveBatchDetail: (Uri, List<Uri>) -> Unit = { _, _ -> },
    onSendToWatch: (Uri?, String?) -> Unit = { _, _ -> },
    onSendFoundToWatch: (FoundPackageFile) -> Unit = {},
    onRefreshWatch: () -> Unit = {},
    onScanApksForWatch: (Boolean) -> Unit = {},
    watchName: String? = null,
    isLookingUpWatch: Boolean = false,
    watchApkScanState: ScanState = ScanState.Idle,
) {
    val context = LocalContext.current
    val resource = LocalResources.current
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    // "strict" means validate extension strictly against known package types; "permissive" accepts anything.
    var strictPickerMode by remember { mutableStateOf(true) }

    val onFilesPicked: (List<Uri>) -> Unit = { uris ->
        if (uris.isNotEmpty()) {
            if (uris.size >= 2) {
                uris.forEach { u ->
                    runCatching {
                        context.contentResolver.takePersistableUriPermission(
                            u,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                        )
                    }
                }
                onBatchPicked(uris)
            } else {
                val uri = uris.first()
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) { /* some providers don't support persistable permissions */ }
                val mimeType = context.contentResolver.getType(uri)?.lowercase()
                val displayName = context.contentResolver.getDisplayName(uri)
                val extension = displayName.substringAfterLast('.', "").lowercase()

                if (!PackageFileFilter.isSupportedPackage(context, uri, displayName)) {
                    Toast.makeText(
                        context,
                        resource.getString(R.string.install_unsupported_file),
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Timber.d("Selected file: $uri, MIME type: $mimeType, strict: $strictPickerMode")
                    val isApkMime = mimeType == "application/vnd.android.package-archive"
                    val apks = when {
                        (isApkMime || extension == "apk") -> SingletonApkSequence(
                            uri,
                            context
                        ).toSplitPackage()

                        extension in listOf("apks", "xapk", "apkm", "apk+", "zip") -> ZippedApkSplits.getApksForUri(
                            uri,
                            context
                        )
                            .validate()
                            .toSplitPackage()
                            .filterCompatible(context)

                        else -> {
                            SingletonApkSequence(uri, context).toSplitPackage()
                        }
                    }
                    app.pwhs.core.telemetry.AnalyticsHelper.logFilePicked(extension, 1, app.pwhs.core.telemetry.TelemetryEvents.SOURCE_SYSTEM_FILE_PICKER)
                    onFilePicked(uri, apks, displayName)
                }
            }
        }
    }

    val filePickerLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments(), onFilesPicked)
    val fallbackFilePickerLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents(), onFilesPicked)

    val safeLaunchFilePicker: (Boolean) -> Unit = { strict ->
        strictPickerMode = strict
        val mimes = if (strict) PackageFileFilter.PACKAGE_MIME_TYPES else arrayOf("*/*")
        val launched = runCatching {
            filePickerLauncher.launch(mimes)
        }.isSuccess
        if (!launched) {
            val fallbackLaunched = runCatching {
                fallbackFilePickerLauncher.launch(if (strict) "application/vnd.android.package-archive" else "*/*")
            }.isSuccess
            if (!fallbackLaunched) {
                Toast.makeText(
                    context,
                    context.getString(R.string.error_no_file_picker),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    val onObbsPicked: (List<Uri>) -> Unit = { uris ->
        uris.forEach { onAttachObb(it) }
    }
    val obbPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments(),
        onObbsPicked
    )
    val fallbackObbPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents(),
        onObbsPicked
    )
    val safeLaunchObbPicker = {
        val launched = runCatching {
            obbPickerLauncher.launch(arrayOf("*/*"))
        }.isSuccess
        if (!launched) {
            val fallbackLaunched = runCatching {
                fallbackObbPickerLauncher.launch("*/*")
            }.isSuccess
            if (!fallbackLaunched) {
                Toast.makeText(
                    context,
                    context.getString(R.string.error_no_file_picker),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // SAF folder picker for granting access to /Android/obb/<pkg>/ when Shizuku isn't
    // available. Result is passed straight to the VM which validates the chosen folder
    // matches the target package and persists the grant.
    val obbTreeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> onGrantObbFolder(uri) }

    var showWatchSheet by rememberSaveable { mutableStateOf(false) }

    // No mime filter — "application/vnd.android.package-archive" hides .apks/.xapk/.apkm, which
    // the watch receiver does accept.
    val watchApkPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            showWatchSheet = false
            val displayName = context.contentResolver.getDisplayName(uri)
            onSendToWatch(uri, displayName)
        }
    }

    var selectedTab by rememberSaveable { mutableStateOf(SourceTab.Local) }

    // Consume URIs delivered via ACTION_VIEW (Chrome downloads, file managers, Gmail). We
    // strict-validate the extension here because the manifest filter also accepts
    // `application/octet-stream`, which covers many non-package binaries.
    val pendingViewUri by IntentHandoff.pendingUri.collectAsState()
    LaunchedEffect(pendingViewUri) {
        val uri = pendingViewUri ?: return@LaunchedEffect
        IntentHandoff.consume()
        try {
            val mimeType = context.contentResolver.getType(uri)?.lowercase()
            val displayName = context.contentResolver.getDisplayName(uri)
            val extension = displayName.substringAfterLast('.', "").lowercase()
            val validExtensions = listOf("apk", "apks", "xapk", "apkm", "apk+", "zip")
            val isApkMime = mimeType == "application/vnd.android.package-archive"
            if (!isApkMime && extension !in validExtensions) {
                Toast.makeText(
                    context,
                    resource.getString(R.string.install_unsupported_file),
                    Toast.LENGTH_LONG,
                ).show()
                return@LaunchedEffect
            }
            val apks = when {
                (isApkMime || extension == "apk") -> SingletonApkSequence(uri, context).toSplitPackage()
                extension in listOf("apks", "xapk", "apkm", "apk+", "zip") -> ZippedApkSplits.getApksForUri(uri, context)
                    .validate()
                    .toSplitPackage()
                    .filterCompatible(context)
                else -> SingletonApkSequence(uri, context).toSplitPackage()
            }
            app.pwhs.core.telemetry.AnalyticsHelper.logFilePicked(extension, 1, app.pwhs.core.telemetry.TelemetryEvents.SOURCE_EXTERNAL_INTENT)
            onFilePicked(uri, apks, displayName)
        } catch (e: Exception) {
            Timber.e(e, "Failed to process intent URI: $uri")
            Toast.makeText(
                context,
                resource.getString(R.string.install_unsupported_file),
                Toast.LENGTH_LONG,
            ).show()
        }
    }

    // Batch share (`ACTION_SEND_MULTIPLE`) — hand the URIs to the VM's batch parser.
    val pendingViewUris by IntentHandoff.pendingUris.collectAsState()
    LaunchedEffect(pendingViewUris) {
        val uris = pendingViewUris ?: return@LaunchedEffect
        IntentHandoff.consumeBatch()
        if (uris.size >= 2) onBatchPicked(uris)
    }

    // Plain-text share (browser share sheet → APK download URL). Switch to the Download
    // tab so the user can see the running progress, then kick off the existing
    // download-from-URL flow (which validates the URL and surfaces errors in the UI).
    val pendingDownloadUrl by IntentHandoff.pendingDownloadUrl.collectAsState()
    LaunchedEffect(pendingDownloadUrl) {
        val url = pendingDownloadUrl ?: return@LaunchedEffect
        IntentHandoff.consumeDownloadUrl()
        selectedTab = SourceTab.Download
        onDownloadFromUrl(url)
    }

    val grantPermissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            // Re-check on return — user may or may not have granted.
            onStartDeviceScan()
        }

    // The launcher callback only fires when the user comes back from system Settings via the
    // Back button. PermissionMonitor's REORDER_TO_FRONT / notification paths bypass the
    // launcher entirely, so without this resume-effect the sheet would stay stuck in
    // PermissionNeeded until the user closes and re-opens it. Re-trigger the scan on every
    // resume while the sheet is in PermissionNeeded — `startDeviceScan` itself re-checks the
    // permission and is cheap to call.
    val isAwaitingStoragePermission = uiState.scanState is ScanState.PermissionNeeded
    LifecycleResumeEffect(isAwaitingStoragePermission) {
        if (isAwaitingStoragePermission && ApkScanner.hasAllFilesAccess(context)) {
            onStartDeviceScan()
        }
        onPauseOrDispose {}
    }

    if (showWatchSheet) {
        WatchSendSheet(
            watchName = watchName,
            isLookingUpWatch = isLookingUpWatch,
            pendingApk = uiState.pendingApkInfo,
            scanState = watchApkScanState,
            onRefreshWatch = onRefreshWatch,
            onRescan = { onScanApksForWatch(true) },
            onGrantPermission = {
                runCatching {
                    grantPermissionLauncher.launch(ApkScanner.buildGrantIntent(context))
                }.onFailure {
                    Toast.makeText(
                        context,
                        context.getString(R.string.error_cannot_open_app),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            onSendPending = {
                showWatchSheet = false
                onSendToWatch(null, null)
            },
            onSendFound = { found ->
                showWatchSheet = false
                onSendFoundToWatch(found)
            },
            onPickFile = { watchApkPickerLauncher.launch("*/*") },
            onDismiss = { showWatchSheet = false },
        )
    }

    FoundApksSheet(
        scanState = uiState.scanState,
        onDismiss = onDismissDeviceScan,
        onGrantPermission = {
            runCatching {
                grantPermissionLauncher.launch(ApkScanner.buildGrantIntent(context))
            }.onFailure {
                Toast.makeText(
                    context,
                    context.getString(R.string.error_cannot_open_app),
                    Toast.LENGTH_SHORT
                ).show()
            }
        },
        onRescan = onStartDeviceScan,
        onPick = onPickFromScan,
        onPickMany = onPickManyFromScan,
        onDeleteMany = onDeleteScannedFiles,
    )

    // APK Info Preview Bottom Sheet
    if (uiState.pendingApkInfo != null) {
        val sheetState = rememberModalBottomSheetState(
            skipPartiallyExpanded = true,
            confirmValueChange = { targetValue ->
                targetValue != SheetValue.Hidden
            },
        )
        ModalBottomSheet(
            onDismissRequest = onDismissPreview,
            sheetState = sheetState,
            shape = MaterialTheme.shapes.extraLarge,
        ) {
            ApkInfoContent(
                apkInfo = uiState.pendingApkInfo,
                onInstall = onConfirmInstall,
                onCancel = onDismissPreview,
                onCheckVirusTotal = onCheckVirusTotal,
                showKeepApkOption = showKeepApkOption,
                keepApk = keepApk,
                onKeepApkChanged = onKeepApkChanged,
                attachedObbFiles = uiState.attachedObbFiles,
                onAttachObb = safeLaunchObbPicker,
                onRemoveObb = onRemoveObb,
                onToggleSplit = onToggleSplit,
                profiles = uiState.installerProfiles,
                appProfileMapping = uiState.appProfileMapping,
                allUsers = uiState.allUsers,
                selectedUserId = uiState.selectedUserId,
                onProfileSelected = onProfileSelected,
                onMappingChanged = onMappingChanged,
                onToggleAllUsers = onToggleAllUsers,
                onSelectUserId = onSelectUserId,
                startCompact = true,
                onUnblock = onUnblock,
                strictSecurity = strictSecurity,
                onMergeSplits = onMergeSplits,
            )
        }
    }

    BatchInstallSheet(
        state = uiState.batchState,
        mergeSplits = uiState.mergeSplits,
        profiles = uiState.installerProfiles,
        selectedProfileId = uiState.selectedProfileId,
        onProfileSelected = onProfileSelected,
        onDismiss = onBatchDismiss,
        onToggleEntry = onBatchToggleEntry,
        onToggleAll = onBatchToggleAll,
        onToggleMerge = onSetMergeSplits,
        onConfirm = onBatchConfirm,
        onSkipParse = onSkipBatchParse,
        onDetail = onOpenBatchDetail,
    )
    
    if (uiState.batchDetailUri != null && uiState.batchState is BatchInstallState.Ready) {
        BatchDetailSheet(
            state = uiState.batchState,
            detailUri = uiState.batchDetailUri,
            onDismiss = onCloseBatchDetail,
            onSave = onSaveBatchDetail,
            profiles = uiState.installerProfiles,
            appProfileMapping = uiState.appProfileMapping,
            allUsers = uiState.allUsers,
            selectedUserId = uiState.selectedUserId,
            onProfileSelected = onProfileSelected,
            onMappingChanged = onMappingChanged,
            onToggleAllUsers = onToggleAllUsers,
            onSelectUserId = onSelectUserId,
        )
    }

    var showPermissions by remember { mutableStateOf(false) }
    PermissionCenterSheet(
        visible = showPermissions,
        onDismiss = { showPermissions = false },
    )

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                expandedHeight = 140.dp,
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = stringResource(R.string.fab_install),
                            style = MaterialTheme.typography.headlineMedium,
                        )
                        InstallerModeBadge()
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                },
                actions = {
                    val isSyncRunning = uiState.syncState == app.pwhs.universalinstaller.presentation.sync.SyncState.RUNNING

                    if (WearApkSender.isAvailable) {
                        IconButton(
                            onClick = {
                                showWatchSheet = true
                                onRefreshWatch()
                                onScanApksForWatch(false)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Watch,
                                contentDescription = stringResource(R.string.watch_send_title),
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenSyncServer,
                        modifier = if (isSyncRunning) Modifier.background(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            CircleShape
                        ) else Modifier
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WifiTethering,
                            contentDescription = stringResource(R.string.setting_section_sync),
                            tint = if (isSyncRunning) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showPermissions = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = stringResource(R.string.permissions_menu_cd),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                ),
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "storage") { StorageCard() }
            item(key = "shizuku_promo") { ShizukuPromoBanner() }

            if (uiState.obbCopyState !is ObbCopyState.Idle) {
                item(key = "obb_copy") {
                    ObbCopyCard(
                        state = uiState.obbCopyState,
                        onDismiss = onDismissObbCopy,
                        onGrantFolder = {
                            @Suppress("DEPRECATION")
                            runCatching {
                                obbTreeLauncher.launch(obbTreeHintUri())
                            }.onFailure {
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.error_no_file_picker),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                    )
                }
            }

            item(key = "source_picker") {
                SourcePicker(
                    selectedTab = selectedTab,
                    onTabChange = { selectedTab = it },
                    showDownloadTab = showDownloadTab,
                    isParsing = uiState.isLoading,
                    onSkipParse = if (uiState.isApk) onSkipParseSingle else null,
                    downloadState = uiState.downloadState,
                    onFindAutomatic = onStartDeviceScan,
                    onBrowsePackages = { safeLaunchFilePicker(true) },
                    onBrowseAll = { safeLaunchFilePicker(false) },
                    onStartDownload = onDownloadFromUrl,
                    onCancelDownload = onCancelDownload,
                    onDismissDownloadError = onDismissDownloadError,
                    onOpenDownloadHistory = onOpenDownloadHistory,
                )
            }

            // Active sessions
            if (uiState.sessions.isNotEmpty()) {
                item(key = "sessions_header") {
                    Text(
                        text = stringResource(R.string.install_sessions_header),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                items(
                    items = uiState.sessions,
                    key = { it.id }
                ) { session ->
                    val sessionProgress =
                        uiState.sessionsProgress.find { it.id == session.id }
                    SessionCard(
                        sessionData = session,
                        sessionProgress = sessionProgress,
                        onCancel = { onCancel(session.id) },
                        onRetry = { onRetry(session.id) },
                        onDismiss = { onDismissSession(session.id) },
                        modifier = Modifier.animateItem(),
                    )
                }
            }

            // Install history
            if (history.isNotEmpty()) {
                item(key = "history_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = stringResource(R.string.install_history_header),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        TextButton(onClick = onClearHistory) {
                            Text(stringResource(R.string.install_history_clear), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
                items(
                    items = history,
                    key = { "history_${it.id}" }
                ) { entry ->
                    HistoryCard(
                        entry = entry,
                        modifier = Modifier.animateItem(),
                        onReinstall = { file ->
                            val fileUri = Uri.fromFile(file)
                            val provider = app.pwhs.universalinstaller.presentation.install.util.InstallApkSplitsHelper.buildSplitProvider(
                                context,
                                fileUri,
                                file.extension.lowercase()
                            )
                            app.pwhs.core.telemetry.AnalyticsHelper.logFilePicked(
                                file.extension,
                                1,
                                app.pwhs.core.telemetry.TelemetryEvents.SOURCE_LOCAL_DOWNLOADS
                            )
                            onFilePicked(fileUri, provider, file.name)
                        },
                    )
                }
            }
        }
    }
}
