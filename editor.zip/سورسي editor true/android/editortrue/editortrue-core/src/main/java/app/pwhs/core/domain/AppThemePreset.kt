package app.pwhs.core.domain

enum class AppThemePreset(val label: String) {
    EditorTrue("EDITOR TRUE Gold"),
    Orange("Orange"),
    Blue("Blue"),
    Green("Green"),
    Red("Red"),
    Purple("Purple"),
}
