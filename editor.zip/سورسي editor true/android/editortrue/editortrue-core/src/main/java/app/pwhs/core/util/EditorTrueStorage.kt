package app.pwhs.core.util

import android.os.Environment
import java.io.File

/** Single public storage root shared by EditorTrue and every integrated Universal Installer feature. */
object EditorTrueStorage {
    const val ROOT_DIRECTORY_NAME = "EditorTrue"

    fun root(): File = File(Environment.getExternalStorageDirectory(), ROOT_DIRECTORY_NAME)

    /** Returns a child directory below EditorTrue/ and creates it when possible. */
    fun directory(vararg segments: String): File {
        var result = root()
        segments.forEach { segment ->
            require(segment.isNotBlank() && segment != "." && segment != ".." &&
                !segment.contains('/') && !segment.contains('\\')) {
                "Invalid EditorTrue storage path segment"
            }
            result = File(result, segment)
        }
        if (!result.isDirectory && !result.mkdirs() && !result.isDirectory) {
            throw IllegalStateException("تعذر إنشاء مجلد EditorTrue؛ امنح التطبيق إذن إدارة الملفات من إعدادات Android.")
        }
        return result
    }

    fun modifiedApks(): File = directory("Modified")
    fun installerBackups(): File = directory("UniversalInstaller", "Backups")
    fun installerDownloads(): File = directory("UniversalInstaller", "Downloads")
    fun installerUpdates(): File = directory("UniversalInstaller", "Updates")
    fun installerShared(): File = directory("UniversalInstaller", "Shared")
}
