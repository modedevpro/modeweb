if(NOT TARGET bytehook::bytehook)
add_library(bytehook::bytehook SHARED IMPORTED)
set_target_properties(bytehook::bytehook PROPERTIES
    IMPORTED_LOCATION "/home/ubuntu/.gradle/caches/9.3.1/transforms/1cceff80b3c30e30570a4de0889fe0a2/transformed/jetified-bytehook-1.1.1/prefab/modules/bytehook/libs/android.armeabi-v7a/libbytehook.so"
    INTERFACE_INCLUDE_DIRECTORIES "/home/ubuntu/.gradle/caches/9.3.1/transforms/1cceff80b3c30e30570a4de0889fe0a2/transformed/jetified-bytehook-1.1.1/prefab/modules/bytehook/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

