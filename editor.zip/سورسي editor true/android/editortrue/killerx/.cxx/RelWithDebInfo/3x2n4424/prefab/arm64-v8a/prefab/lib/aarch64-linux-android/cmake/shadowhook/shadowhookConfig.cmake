if(NOT TARGET shadowhook::shadowhook)
add_library(shadowhook::shadowhook SHARED IMPORTED)
set_target_properties(shadowhook::shadowhook PROPERTIES
    IMPORTED_LOCATION "/home/ubuntu/.gradle/caches/9.3.1/transforms/ac6e075de7d2d62ac34168b9c27b31ec/transformed/jetified-shadowhook-1.1.1/prefab/modules/shadowhook/libs/android.arm64-v8a/libshadowhook.so"
    INTERFACE_INCLUDE_DIRECTORIES "/home/ubuntu/.gradle/caches/9.3.1/transforms/ac6e075de7d2d62ac34168b9c27b31ec/transformed/jetified-shadowhook-1.1.1/prefab/modules/shadowhook/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

